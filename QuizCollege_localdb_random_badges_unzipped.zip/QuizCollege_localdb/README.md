# 🎓 QuizCollège - Application Éducative Interactive

Application de quiz complète pour collégiens français (6ème à 3ème) avec **32,400 questions** basées sur les programmes scolaires 2025-2026.

![Quiz Application](attached_assets/stock_images/modern_quiz_app_logo_118ee050.jpg)

## ✨ Fonctionnalités

### 📚 Contenu Éducatif Complet
- **10 matières** : Français, Mathématiques, Géographie, Histoire, Sciences, SVT, Physique-Chimie, Anglais, Italien, Musique
- **162 chapitres** répartis sur 4 niveaux (6ème à 3ème)
- **32,400 questions** (200 par chapitre)
- Questions basées sur les programmes officiels 2025-2026

### 🎮 Système de Quiz
- **20 questions par quiz** avec ordre aléatoire à chaque partie
- Progression sauvegardée automatiquement
- Système de points XP et niveaux
- Badges de récompense (bronze, argent, or)
- Séries de jours consécutifs (streaks)

### 👥 Gestion des Profils
- Création de profils multiples
- Sélection de classe (6ème à 3ème)
- Écran de sélection pour reprendre la progression
- Statistiques détaillées par matière et chapitre

### 🎨 Design Moderne
- Interface responsive et intuitive
- Thème dark/light
- Animations fluides avec Framer Motion
- Composants UI professionnels (Shadcn)
- Palette de couleurs par matière

## 🚀 Stack Technique

### Frontend
- **React 18** avec TypeScript
- **Vite** pour le build
- **Wouter** pour le routing
- **TanStack Query** pour la gestion des données
- **Tailwind CSS** + **Shadcn UI** pour le design
- **Framer Motion** pour les animations

### Backend
- **Express.js** serveur API REST
- **PostgreSQL** (Neon) base de données
- **Drizzle ORM** pour les requêtes SQL
- **Zod** pour la validation

### Base de Données
```
users → profiles (nom, classe, XP, streak)
subjects (10 matières)
chapters (162 chapitres)
questions (32,400 questions)
quiz_results (résultats des quiz)
user_progress (progression par chapitre)
badges + user_badges (système de badges)
```

## 📊 Statistiques

- **10** matières disponibles
- **162** chapitres couvrant tout le programme
- **32,400** questions générées
- **20** questions par quiz
- **200** questions par chapitre

## 🛠️ Installation

1. **Cloner le repository**
```bash
git clone https://github.com/flowfly77/SCHOOLQUIZZ.git
cd SCHOOLQUIZZ
```

2. **Installer les dépendances**
```bash
npm install
```

3. **Configurer la base de données**
```bash
# Synchroniser le schéma
npm run db:push

# Initialiser les matières et chapitres
npx tsx server/run-seed-complete.ts

# Générer les questions (32,400 questions)
npx tsx server/run-generate-massive.ts
```

4. **Lancer l'application**
```bash
npm run dev
```

L'application sera disponible sur `http://localhost:5000`

## 📝 Scripts Disponibles

- `npm run dev` - Lance l'application en mode développement
- `npm run db:push` - Synchronise le schéma de base de données
- `npm run db:studio` - Ouvre Drizzle Studio (interface DB)
- `npx tsx server/run-seed-complete.ts` - Initialise matières et chapitres
- `npx tsx server/run-generate-massive.ts` - Génère 32,400 questions

## 🎯 Programmes Scolaires 2025-2026

L'application couvre l'intégralité des programmes du collège :

### 6ème
- Français, Mathématiques, Géographie, Histoire
- Sciences, Anglais, Italien, Musique

### 5ème  
- Français, Mathématiques, Géographie, Histoire
- SVT, Anglais, Italien, Musique

### 4ème
- Français, Mathématiques, Géographie, Histoire
- SVT, Physique-Chimie, Anglais, Italien, Musique

### 3ème
- Français, Mathématiques, Géographie, Histoire
- SVT, Physique-Chimie, Anglais, Italien, Musique

## 🏗️ Structure du Projet

```
/
├── client/                 # Frontend React
│   ├── src/
│   │   ├── components/    # Composants React
│   │   ├── lib/          # Utilitaires
│   │   └── App.tsx       # Point d'entrée
│   └── index.html
├── server/                # Backend Express
│   ├── db.ts             # Configuration DB
│   ├── routes.ts         # Routes API
│   ├── seed-complete.ts  # Seed matières/chapitres
│   └── generate-massive-questions.ts
├── shared/               # Code partagé
│   └── schema.ts        # Schéma Drizzle
└── attached_assets/     # Assets (logos, images)
```

## 🎨 Palette de Couleurs

### Matières
- **Français** : Rose-rouge (345° 80% 60%)
- **Mathématiques** : Bleu (200° 75% 55%)
- **Histoire-Géo** : Ambre (35° 70% 55%)
- **SVT** : Vert (142° 70% 50%)
- **Physique-Chimie** : Violet (280° 75% 60%)

### Badges
- **Bronze** : 35° 70% 50%
- **Argent** : 0° 0% 75%
- **Or** : 45° 90% 55%

## 🔐 Variables d'Environnement

```env
DATABASE_URL=postgresql://...
SESSION_SECRET=your-secret-key
```

## 📚 Documentation

- [Design Guidelines](design_guidelines.md) - Guide complet du design
- [Replit Documentation](replit.md) - Notes de développement

## 🤝 Contribution

Les contributions sont les bienvenues ! Pour contribuer :

1. Fork le projet
2. Créez une branche (`git checkout -b feature/AmazingFeature`)
3. Commit vos changements (`git commit -m 'Add some AmazingFeature'`)
4. Push vers la branche (`git push origin feature/AmazingFeature`)
5. Ouvrez une Pull Request

## 📄 Licence

Ce projet est sous licence MIT.

## 👨‍💻 Auteur

Développé par flowfly77

---

## 🚀 Pour Pousser sur GitHub (Instructions)

Exécutez ces commandes dans le Shell de Replit :

```bash
# Initialiser git (si pas déjà fait)
git init

# Ajouter tous les fichiers
git add .

# Créer le commit initial
git commit -m "🎉 QuizCollège - Application complète avec 32,400 questions"

# Ajouter le remote GitHub
git remote add origin https://github.com/flowfly77/SCHOOLQUIZZ.git

# Pousser vers GitHub (branche main)
git push -u origin main

# Si la branche main n'existe pas, créez-la d'abord
git branch -M main
git push -u origin main
```

Si vous rencontrez des problèmes d'authentification, utilisez un Personal Access Token :

```bash
git remote set-url origin https://flowfly77:YOUR_TOKEN@github.com/flowfly77/SCHOOLQUIZZ.git
git push -u origin main
```

---

**Fait avec ❤️ pour les collégiens français** 🇫🇷

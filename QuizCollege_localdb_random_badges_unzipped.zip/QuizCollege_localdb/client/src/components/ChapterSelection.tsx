import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { ChevronLeft, BookOpen } from "lucide-react";
import { motion } from "framer-motion";
import { Skeleton } from "@/components/ui/skeleton";
import { Logo } from "./Logo";

interface ChapterSelectionProps {
  subjectId: string;
  subjectName: string;
  grade: string;
  onBack: () => void;
  onSelectChapter: (chapterId: string) => void;
}

interface Chapter {
  id: string;
  subjectId: string;
  grade: string;
  title: string;
  slug: string;
  order: number;
  description?: string;
}

export function ChapterSelection({ 
  subjectId, 
  subjectName, 
  grade, 
  onBack, 
  onSelectChapter 
}: ChapterSelectionProps) {
  const { data: chapters, isLoading } = useQuery<Chapter[]>({
    queryKey: [`/api/chapters?subjectId=${subjectId}&grade=${grade}`],
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <div className="sticky top-0 z-50 bg-card border-b border-border">
          <div className="container mx-auto px-4">
            <div className="flex items-center justify-between py-4">
              <Button variant="ghost" size="icon" disabled>
                <ChevronLeft className="h-5 w-5" />
              </Button>
              <div className="flex items-center justify-center gap-3">
                <Logo className="w-8 h-8" />
                <h1 className="text-2xl font-bold gradient-text-primary">SCHOOLQUIZZ</h1>
              </div>
              <div className="w-10" />
            </div>
          </div>
        </div>

        <div className="container mx-auto px-4 py-8">
          <Skeleton className="h-8 w-64 mb-2" />
          <Skeleton className="h-4 w-48 mb-8" />
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <Skeleton key={i} className="h-32" />
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="sticky top-0 z-50 bg-card border-b border-border">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between py-4">
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={onBack}
              data-testid="button-back-to-dashboard"
            >
              <ChevronLeft className="h-5 w-5" />
            </Button>
            <h1 className="text-2xl font-bold gradient-text-primary">QuizCollège</h1>
            <div className="w-10" />
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
          <div>
            <h2 className="text-3xl font-bold mb-2">{subjectName}</h2>
            <p className="text-muted-foreground">
              Sélectionne un chapitre pour commencer le quiz
            </p>
          </div>

          {chapters && chapters.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {chapters.map((chapter, index) => (
                <motion.div
                  key={chapter.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.05 * index }}
                >
                  <Card 
                    className="hover-elevate active-elevate-2 cursor-pointer transition-all"
                    onClick={() => onSelectChapter(chapter.id)}
                    data-testid={`card-chapter-${chapter.id}`}
                  >
                    <CardHeader>
                      <div className="flex items-start gap-3">
                        <div className="p-2 rounded-lg bg-primary/10">
                          <BookOpen className="h-5 w-5 text-primary" />
                        </div>
                        <div className="flex-1">
                          <CardTitle className="text-lg mb-1">
                            Chapitre {chapter.order}
                          </CardTitle>
                          <CardDescription className="text-sm">
                            {chapter.title}
                          </CardDescription>
                        </div>
                      </div>
                    </CardHeader>
                  </Card>
                </motion.div>
              ))}
            </div>
          ) : (
            <Card className="p-8 text-center">
              <BookOpen className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Aucun chapitre disponible</h3>
              <p className="text-muted-foreground">
                Les chapitres pour {subjectName} en {grade} seront bientôt disponibles.
              </p>
            </Card>
          )}
        </motion.div>
      </div>
    </div>
  );
}

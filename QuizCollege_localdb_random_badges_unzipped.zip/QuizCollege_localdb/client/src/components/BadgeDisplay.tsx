import { Trophy, Lock } from "lucide-react";
import { motion } from "framer-motion";

interface BadgeDisplayProps {
  type: "bronze" | "silver" | "gold";
  title: string;
  description: string;
  unlocked: boolean;
  unlockedDate?: string;
}

export function BadgeDisplay({ type, title, description, unlocked, unlockedDate }: BadgeDisplayProps) {
  const colorClasses = {
    bronze: "bg-badge-bronze text-badge-bronze-foreground",
    silver: "bg-badge-silver text-badge-silver-foreground",
    gold: "bg-badge-gold text-badge-gold-foreground",
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      whileHover={{ scale: unlocked ? 1.05 : 1 }}
      className={`p-6 rounded-2xl border-2 ${
        unlocked
          ? `${colorClasses[type]} border-transparent`
          : "bg-muted/30 border-border text-muted-foreground"
      } transition-all`}
      data-testid={`badge-${type}-${unlocked ? 'unlocked' : 'locked'}`}
    >
      <div className="flex flex-col items-center text-center space-y-3">
        <div className={`w-16 h-16 rounded-full flex items-center justify-center ${
          unlocked ? "bg-white/20" : "bg-muted"
        }`}>
          {unlocked ? (
            <Trophy className="w-8 h-8" />
          ) : (
            <Lock className="w-8 h-8" />
          )}
        </div>

        <div className="space-y-1">
          <h4 className="font-semibold">{title}</h4>
          <p className="text-sm opacity-80">{description}</p>
          {unlocked && unlockedDate && (
            <p className="text-xs opacity-60 pt-1">Débloqué le {unlockedDate}</p>
          )}
        </div>
      </div>
    </motion.div>
  );
}

import { QuizScreen } from "../QuizScreen";

export default function QuizScreenExample() {
  return (
    <QuizScreen 
      subject="Mathématiques" 
      onExit={() => console.log("Quiz exited")}
    />
  );
}

import { BadgeDisplay } from "../BadgeDisplay";

export default function BadgeDisplayExample() {
  return (
    <div className="p-8 bg-background">
      <div className="grid grid-cols-2 gap-4 max-w-2xl">
        <BadgeDisplay
          type="gold"
          title="Champion Quiz"
          description="10 quiz parfaits"
          unlocked={true}
          unlockedDate="12 Oct 2025"
        />
        <BadgeDisplay
          type="silver"
          title="Expert"
          description="Maîtrise une matière"
          unlocked={false}
        />
      </div>
    </div>
  );
}

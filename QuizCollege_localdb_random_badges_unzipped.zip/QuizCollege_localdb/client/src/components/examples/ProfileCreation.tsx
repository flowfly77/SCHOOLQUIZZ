import { ProfileCreation } from "../ProfileCreation";

export default function ProfileCreationExample() {
  return (
    <ProfileCreation 
      onComplete={(name, grade) => console.log("Profile created:", name, grade)} 
    />
  );
}

import { SubjectCard } from "../SubjectCard";
import { Calculator } from "lucide-react";

export default function SubjectCardExample() {
  return (
    <div className="p-8 bg-background">
      <div className="max-w-sm">
        <SubjectCard
          name="Mathématiques"
          icon={Calculator}
          progress={60}
          color="math"
          onClick={() => console.log("Subject clicked")}
        />
      </div>
    </div>
  );
}

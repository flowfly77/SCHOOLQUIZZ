import { QuizQuestion } from "../QuizQuestion";

export default function QuizQuestionExample() {
  return (
    <div className="p-8 bg-background min-h-screen flex items-center">
      <QuizQuestion
        question="Quel est le résultat de 5 × 8 ?"
        options={["35", "40", "45", "50"]}
        correctAnswer={1}
        questionNumber={1}
        totalQuestions={10}
        onAnswer={(isCorrect) => console.log("Answer:", isCorrect)}
      />
    </div>
  );
}

import { Dashboard } from "../Dashboard";
import { ThemeProvider } from "../ThemeProvider";

export default function DashboardExample() {
  return (
    <ThemeProvider>
      <Dashboard 
        userName="Lucas" 
        userGrade="4ème"
        onSubjectClick={(subject) => console.log("Subject clicked:", subject)}
      />
    </ThemeProvider>
  );
}

export function FlagGB({ className = "w-6 h-6" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 60 30" xmlns="http://www.w3.org/2000/svg">
      <clipPath id="a">
        <path d="M0 0v30h60V0z"/>
      </clipPath>
      <clipPath id="b">
        <path d="M30 15h30v15zv15H0zH0V0zV0h30z"/>
      </clipPath>
      <g clipPath="url(#a)">
        <path d="M0 0v30h60V0z" fill="#012169"/>
        <path d="M0 0l60 30m0-30L0 30" stroke="#fff" strokeWidth="6"/>
        <path d="M0 0l60 30m0-30L0 30" clipPath="url(#b)" stroke="#C8102E" strokeWidth="4"/>
        <path d="M30 0v30M0 15h60" stroke="#fff" strokeWidth="10"/>
        <path d="M30 0v30M0 15h60" stroke="#C8102E" strokeWidth="6"/>
      </g>
    </svg>
  );
}

export function FlagIT({ className = "w-6 h-6" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 3 2" xmlns="http://www.w3.org/2000/svg">
      <rect width="1" height="2" fill="#009246"/>
      <rect x="1" width="1" height="2" fill="#fff"/>
      <rect x="2" width="1" height="2" fill="#ce2b37"/>
    </svg>
  );
}

export function Pizza({ className = "w-6 h-6" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M50 10L10 90L90 90L50 10Z" fill="#F59E0B" stroke="#D97706" strokeWidth="2"/>
      <path d="M50 15L15 85L85 85L50 15Z" fill="#FBBF24"/>
      <circle cx="35" cy="55" r="6" fill="#DC2626"/>
      <circle cx="50" cy="50" r="5" fill="#DC2626"/>
      <circle cx="60" cy="65" r="5" fill="#DC2626"/>
      <circle cx="40" cy="70" r="4" fill="#10B981"/>
      <circle cx="55" cy="70" r="4" fill="#10B981"/>
      <ellipse cx="45" cy="40" rx="8" ry="4" fill="#FEF3C7"/>
    </svg>
  );
}

export function Globe({ className = "w-6 h-6" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="50" cy="50" r="40" fill="#3B82F6" stroke="#1D4ED8" strokeWidth="2"/>
      <ellipse cx="50" cy="50" rx="15" ry="40" fill="none" stroke="#60A5FA" strokeWidth="2"/>
      <ellipse cx="50" cy="50" rx="40" ry="15" fill="none" stroke="#60A5FA" strokeWidth="2"/>
      <path d="M20 30Q50 35 80 30" stroke="#60A5FA" strokeWidth="2" fill="none"/>
      <path d="M20 70Q50 65 80 70" stroke="#60A5FA" strokeWidth="2" fill="none"/>
    </svg>
  );
}

export function ScrollIcon({ className = "w-6 h-6" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect x="20" y="15" width="60" height="70" rx="3" fill="#F59E0B" stroke="#D97706" strokeWidth="2"/>
      <rect x="25" y="20" width="50" height="60" fill="#FBBF24"/>
      <line x1="30" y1="30" x2="70" y2="30" stroke="#92400E" strokeWidth="2"/>
      <line x1="30" y1="40" x2="70" y2="40" stroke="#92400E" strokeWidth="2"/>
      <line x1="30" y1="50" x2="70" y2="50" stroke="#92400E" strokeWidth="2"/>
      <line x1="30" y1="60" x2="55" y2="60" stroke="#92400E" strokeWidth="2"/>
    </svg>
  );
}

export function Atom({ className = "w-6 h-6" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="50" cy="50" r="6" fill="#8B5CF6"/>
      <ellipse cx="50" cy="50" rx="35" ry="15" stroke="#8B5CF6" strokeWidth="3" fill="none" transform="rotate(0 50 50)"/>
      <ellipse cx="50" cy="50" rx="35" ry="15" stroke="#A78BFA" strokeWidth="3" fill="none" transform="rotate(60 50 50)"/>
      <ellipse cx="50" cy="50" rx="35" ry="15" stroke="#C4B5FD" strokeWidth="3" fill="none" transform="rotate(120 50 50)"/>
      <circle cx="50" cy="15" r="4" fill="#EC4899"/>
      <circle cx="80" cy="62" r="4" fill="#EC4899"/>
      <circle cx="20" cy="62" r="4" fill="#EC4899"/>
    </svg>
  );
}

export function DNAIcon({ className = "w-6 h-6" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M20 10Q50 30 80 10" stroke="#10B981" strokeWidth="4" fill="none"/>
      <path d="M20 30Q50 10 80 30" stroke="#34D399" strokeWidth="4" fill="none"/>
      <path d="M20 50Q50 70 80 50" stroke="#10B981" strokeWidth="4" fill="none"/>
      <path d="M20 70Q50 50 80 70" stroke="#34D399" strokeWidth="4" fill="none"/>
      <path d="M20 90Q50 110 80 90" stroke="#10B981" strokeWidth="4" fill="none"/>
      <line x1="25" y1="20" x2="75" y2="20" stroke="#6EE7B7" strokeWidth="2"/>
      <line x1="25" y1="40" x2="75" y2="40" stroke="#6EE7B7" strokeWidth="2"/>
      <line x1="25" y1="60" x2="75" y2="60" stroke="#6EE7B7" strokeWidth="2"/>
      <line x1="25" y1="80" x2="75" y2="80" stroke="#6EE7B7" strokeWidth="2"/>
    </svg>
  );
}

export function GearIcon({ className = "w-6 h-6" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="50" cy="50" r="20" fill="#64748B" stroke="#475569" strokeWidth="2"/>
      <circle cx="50" cy="50" r="10" fill="#CBD5E1"/>
      <rect x="45" y="10" width="10" height="15" fill="#64748B" stroke="#475569" strokeWidth="1"/>
      <rect x="45" y="75" width="10" height="15" fill="#64748B" stroke="#475569" strokeWidth="1"/>
      <rect x="10" y="45" width="15" height="10" fill="#64748B" stroke="#475569" strokeWidth="1"/>
      <rect x="75" y="45" width="15" height="10" fill="#64748B" stroke="#475569" strokeWidth="1"/>
    </svg>
  );
}

export function MusicNote({ className = "w-6 h-6" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
      <ellipse cx="25" cy="75" rx="12" ry="8" fill="#A78BFA"/>
      <rect x="23" y="30" width="4" height="45" fill="#8B5CF6"/>
      <ellipse cx="65" cy="85" rx="12" ry="8" fill="#A78BFA"/>
      <rect x="63" y="15" width="4" height="70" fill="#8B5CF6"/>
      <path d="M27 30Q50 25 67 15" stroke="#8B5CF6" strokeWidth="4" fill="none"/>
    </svg>
  );
}

export function FlagES({ className = "w-6 h-6" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 3 2" xmlns="http://www.w3.org/2000/svg">
      <rect width="3" height="2" fill="#AA151B"/>
      <rect y="0.5" width="3" height="1" fill="#F1BF00"/>
    </svg>
  );
}

export function BookColor({ className = "w-6 h-6" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect x="15" y="10" width="60" height="80" rx="4" fill="#EF4444" stroke="#DC2626" strokeWidth="2"/>
      <rect x="20" y="15" width="50" height="70" fill="#FCA5A5"/>
      <path d="M25 30h40M25 40h40M25 50h35M25 60h40M25 70h30" stroke="#DC2626" strokeWidth="2"/>
      <rect x="15" y="10" width="8" height="80" fill="#B91C1C"/>
    </svg>
  );
}

export function CalculatorColor({ className = "w-6 h-6" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect x="10" y="10" width="80" height="80" rx="6" fill="#3B82F6" stroke="#2563EB" strokeWidth="2"/>
      <rect x="15" y="15" width="70" height="25" rx="3" fill="#DBEAFE"/>
      <rect x="15" y="47" width="15" height="12" rx="2" fill="#BFDBFE"/>
      <rect x="35" y="47" width="15" height="12" rx="2" fill="#BFDBFE"/>
      <rect x="55" y="47" width="15" height="12" rx="2" fill="#BFDBFE"/>
      <rect x="75" y="47" width="10" height="38" rx="2" fill="#F59E0B"/>
      <rect x="15" y="64" width="15" height="12" rx="2" fill="#BFDBFE"/>
      <rect x="35" y="64" width="15" height="12" rx="2" fill="#BFDBFE"/>
      <rect x="55" y="64" width="15" height="12" rx="2" fill="#BFDBFE"/>
    </svg>
  );
}

export function MapColor({ className = "w-6 h-6" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect x="10" y="15" width="80" height="70" rx="4" fill="#FEF3C7" stroke="#F59E0B" strokeWidth="2"/>
      <path d="M20 30Q35 25 50 30T80 30" stroke="#D97706" strokeWidth="2" fill="none"/>
      <path d="M20 45Q35 40 50 45T80 45" stroke="#D97706" strokeWidth="2" fill="none"/>
      <path d="M20 60Q35 55 50 60T80 60" stroke="#D97706" strokeWidth="2" fill="none"/>
      <circle cx="50" cy="35" r="12" fill="#EF4444" stroke="#DC2626" strokeWidth="2"/>
      <path d="M50 28v14M46 35h8" stroke="white" strokeWidth="2"/>
      <path d="M30 25L28 35h4zM70 50L68 60h4z" fill="#10B981"/>
    </svg>
  );
}

export function GamepadColor({ className = "w-6 h-6" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect x="10" y="30" width="80" height="40" rx="20" fill="#8B5CF6" stroke="#7C3AED" strokeWidth="2"/>
      <circle cx="30" cy="50" r="8" fill="#A78BFA"/>
      <path d="M30 45v10M25 50h10" stroke="#7C3AED" strokeWidth="2"/>
      <circle cx="65" cy="45" r="5" fill="#EC4899"/>
      <circle cx="75" cy="50" r="5" fill="#F59E0B"/>
      <circle cx="65" cy="55" r="5" fill="#10B981"/>
      <circle cx="55" cy="50" r="5" fill="#3B82F6"/>
    </svg>
  );
}

import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { CheckCircle, XCircle } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

interface CapitaleQuestionProps {
  question: string;
  correctAnswer: string;
  questionNumber: number;
  totalQuestions: number;
  onAnswer: (isCorrect: boolean) => void;
}

export function CapitaleQuestion({
  question,
  correctAnswer,
  questionNumber,
  totalQuestions,
  onAnswer,
}: CapitaleQuestionProps) {
  const [userAnswer, setUserAnswer] = useState("");
  const [showResult, setShowResult] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    inputRef.current?.focus();
  }, [questionNumber]);

  const normalizeString = (str: string) => {
    return str
      .toUpperCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "") // Retirer les accents
      .trim();
  };

  const handleSubmit = () => {
    if (!userAnswer.trim()) return;
    
    const normalizedUserAnswer = normalizeString(userAnswer);
    const normalizedCorrectAnswer = normalizeString(correctAnswer);
    const correct = normalizedUserAnswer === normalizedCorrectAnswer;
    
    setIsCorrect(correct);
    setShowResult(true);
    
    setTimeout(() => {
      onAnswer(correct);
      setUserAnswer("");
      setShowResult(false);
      setIsCorrect(false);
    }, 1500);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !showResult) {
      handleSubmit();
    }
  };

  const answerLetters = correctAnswer.split("");

  return (
    <div className="w-full max-w-3xl mx-auto space-y-6">
      <div className="space-y-2">
        <div className="flex items-center justify-between text-sm text-muted-foreground">
          <span>Question {questionNumber}/{totalQuestions}</span>
          <div className="w-32 bg-muted rounded-full h-2">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${(questionNumber / totalQuestions) * 100}%` }}
              className="h-full bg-primary rounded-full"
            />
          </div>
        </div>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="p-10 md:p-12 rounded-3xl bg-gradient-to-br from-card to-background/50 border-2 border-card-border shadow-xl"
      >
        <h3 className="text-2xl md:text-3xl font-bold mb-8 leading-relaxed">{question}</h3>

        <div className="mb-6">
          <p className="text-sm text-muted-foreground mb-3">
            Tapez votre réponse avec le clavier :
          </p>
          
          <input
            ref={inputRef}
            type="text"
            value={userAnswer}
            onChange={(e) => !showResult && setUserAnswer(e.target.value.toUpperCase())}
            onKeyPress={handleKeyPress}
            disabled={showResult}
            className="w-full p-4 text-center text-2xl font-bold tracking-widest uppercase bg-muted border-2 border-border rounded-xl focus:outline-none focus:ring-2 focus:ring-primary transition-all"
            placeholder="..."
            data-testid="input-capitale-answer"
          />
        </div>

        {/* Affichage des cases pour les lettres */}
        <div className="flex flex-wrap justify-center gap-2 mb-6">
          {answerLetters.map((letter, index) => {
            const userLetter = userAnswer[index] || "";
            const shouldShow = showResult;
            
            return (
              <motion.div
                key={index}
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ delay: index * 0.05 }}
                className={`w-12 h-14 flex items-center justify-center text-xl font-bold border-2 rounded-lg transition-all ${
                  shouldShow
                    ? isCorrect || userLetter === letter
                      ? "border-success bg-success/10 text-success"
                      : "border-destructive bg-destructive/10 text-destructive"
                    : userLetter
                    ? "border-primary bg-primary/5"
                    : "border-border bg-muted"
                }`}
              >
                {shouldShow ? letter : userLetter || (letter === " " ? "·" : "")}
              </motion.div>
            );
          })}
        </div>

        <AnimatePresence>
          {showResult && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className={`p-4 rounded-xl mb-4 flex items-center gap-3 ${
                isCorrect
                  ? "bg-success/10 text-success border-2 border-success"
                  : "bg-destructive/10 text-destructive border-2 border-destructive"
              }`}
            >
              {isCorrect ? (
                <>
                  <CheckCircle className="w-6 h-6" />
                  <span className="font-semibold">Bonne réponse !</span>
                </>
              ) : (
                <>
                  <XCircle className="w-6 h-6" />
                  <span className="font-semibold">
                    Réponse incorrecte. La bonne réponse était : {correctAnswer}
                  </span>
                </>
              )}
            </motion.div>
          )}
        </AnimatePresence>

        <Button
          size="lg"
          className="w-full mt-8 rounded-full text-lg py-6"
          onClick={handleSubmit}
          disabled={!userAnswer.trim() || showResult}
          data-testid="button-submit-capitale"
        >
          {showResult ? "Chargement..." : "Valider ma réponse"}
        </Button>
      </motion.div>
    </div>
  );
}

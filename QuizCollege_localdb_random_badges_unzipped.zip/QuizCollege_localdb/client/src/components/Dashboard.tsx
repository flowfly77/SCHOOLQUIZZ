import { useQuery } from "@tanstack/react-query";
import { 
  Book, Trophy, Target, Award, LogOut, RotateCcw,
  Languages, BookText, Calculator, ScrollText, MapPin, MapPinned, Microscope, 
  FlaskConical, Gamepad2, Music, Wrench, Users
} from "lucide-react";
import { FlagGB, FlagIT, Pizza, Globe, ScrollIcon, Atom, DNAIcon, GearIcon, MusicNote, FlagES, BookColor, CalculatorColor, MapColor, GamepadColor } from "./SubjectIcons";
import { SubjectCard } from "./SubjectCard";
import { StatsCard } from "./StatsCard";
import { BadgeDisplay } from "./BadgeDisplay";
import { ProfileHeader } from "./ProfileHeader";
import { ThemeToggle } from "./ThemeToggle";
import { Logo } from "./Logo";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { motion } from "framer-motion";
import { useState } from "react";
import { queryClient } from "@/lib/queryClient";
import {
  getSubjects,
  getStats,
  resetProfile,
  updateProfileGrade,
} from "@/lib/db";
import { useToast } from "@/hooks/use-toast";

interface DashboardProps {
  profileId: string;
  userName: string;
  userGrade: string;
  onSubjectClick: (subjectId: string, subjectName: string) => void;
  onBackToProfiles: () => void;
  onGradeChange: (newGrade: string) => void;
}

const iconMap: Record<string, any> = {
  Book, Languages, BookText, Calculator, ScrollText, MapPin, MapPinned,
  Microscope, FlaskConical, Gamepad2, Music, Wrench, Users,
  FlagGB, FlagIT, Pizza, Globe, ScrollIcon, Atom, DNAIcon, GearIcon, MusicNote, FlagES,
  BookColor, CalculatorColor, MapColor, GamepadColor
};

import type { SubjectDoc } from '@/lib/db';

interface Subject extends SubjectDoc {}

export function Dashboard({ profileId, userName, userGrade, onSubjectClick, onBackToProfiles, onGradeChange }: DashboardProps) {
  const { toast } = useToast();
  const [isResetting, setIsResetting] = useState(false);
  const [changeGradeDialogOpen, setChangeGradeDialogOpen] = useState(false);
  const [newGrade, setNewGrade] = useState(userGrade);

  // Fetch the subjects for the current grade. Passing the grade ensures that
  // only the relevant subjects are returned from the local database. The
  // query key includes the grade to automatically invalidate when the
  // profile changes class.
  const { data: subjects = [], isLoading: subjectsLoading } = useQuery<Subject[]>({
    queryKey: ["subjects", userGrade],
    queryFn: () => getSubjects(userGrade),
  });

  const { data: stats } = useQuery<{ quizzesCompleted: number; accuracy: number; totalBadges: number; xp: number; streak: number; }>({
    queryKey: ["stats", profileId],
    queryFn: () => getStats(profileId),
  });

  const handleResetStats = async () => {
    setIsResetting(true);
    try {
      await resetProfile(profileId);
      await queryClient.invalidateQueries({ queryKey: ["stats", profileId] });
      await queryClient.invalidateQueries({ queryKey: ["profiles"] });
      toast({
        title: "Statistiques réinitialisées",
        description: "Ton profil a été remis à zéro !",
      });
    } catch (error: any) {
      toast({
        title: "Erreur",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsResetting(false);
    }
  };

  const handleChangeGrade = async () => {
    try {
      await updateProfileGrade(profileId, newGrade);
      await queryClient.invalidateQueries({ queryKey: ["profiles"] });
      await queryClient.invalidateQueries({ queryKey: ["stats", profileId] });
      toast({
        title: "Classe modifiée",
        description: `Ta classe a été changée en ${newGrade}`,
      });
      setChangeGradeDialogOpen(false);
      onGradeChange(newGrade);
    } catch (error: any) {
      toast({
        title: "Erreur",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  //todo: remove mock functionality
  const badges = [
    { type: "gold" as const, title: "Champion Quiz", description: "10 quiz parfaits", unlocked: true, unlockedDate: "12 Oct 2025" },
    { type: "silver" as const, title: "Curieux", description: "Programme complet Collège (de la 6ème à la 3ème)", unlocked: true, unlockedDate: "10 Oct 2025" },
    { type: "bronze" as const, title: "Débutant", description: "Premier quiz terminé", unlocked: true, unlockedDate: "8 Oct 2025" },
    { type: "gold" as const, title: "Expert Maths", description: "100% en maths", unlocked: false },
  ];

  return (
    <div className="min-h-screen bg-background">
      <div className="sticky top-0 z-50 bg-card border-b border-border">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between py-4">
            <div className="flex items-center justify-center gap-3">
              <Logo className="w-8 h-8" />
              <h1 className="text-2xl font-bold gradient-text-primary">SCHOOLQUIZZ</h1>
            </div>
            <ThemeToggle />
          </div>
        </div>
      </div>

      <ProfileHeader 
        name={userName} 
        grade={userGrade} 
        streak={stats?.streak || 0} 
        xp={stats?.xp || 0}
        onChangeGrade={() => setChangeGradeDialogOpen(true)}
        actionButtons={
          <>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="ghost" size="sm" data-testid="button-reset-stats">
                  <RotateCcw className="h-4 w-4" />
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Réinitialiser les statistiques ?</AlertDialogTitle>
                  <AlertDialogDescription>
                    Cette action va remettre à zéro tous tes XP, badges et progression. Cette action est irréversible.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel data-testid="button-cancel-reset">Annuler</AlertDialogCancel>
                  <AlertDialogAction 
                    onClick={handleResetStats} 
                    disabled={isResetting}
                    data-testid="button-confirm-reset"
                  >
                    {isResetting ? "Réinitialisation..." : "Réinitialiser"}
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>

            <Button 
              variant="ghost" 
              size="sm" 
              onClick={onBackToProfiles}
              data-testid="button-back-to-profiles"
            >
              <LogOut className="h-4 w-4" />
            </Button>
          </>
        }
      />

      <div className="container mx-auto px-4 py-8 space-y-12">
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-4"
        >
          <h2 className="text-2xl font-bold">Mes Statistiques</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <StatsCard 
              title="Quiz Complétés" 
              value={stats?.quizzesCompleted || 0} 
              icon={Trophy} 
              description="Quiz terminés" 
            />
            <StatsCard 
              title="Précision" 
              value={`${stats?.accuracy || 0}%`} 
              icon={Target} 
              description="Moyenne générale" 
            />
            <StatsCard 
              title="Badges" 
              value={stats?.totalBadges || 0} 
              icon={Award} 
              description="Sur 15 disponibles" 
            />
          </div>
        </motion.section>

        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="space-y-4"
        >
          <h2 className="text-2xl font-bold">Mes Matières</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {subjectsLoading ? (
              <p className="text-muted-foreground">Chargement des matières...</p>
            ) : subjects.length > 0 ? (
              subjects.map((subject, index) => {
                const IconComponent = iconMap[subject.icon] || Book;
                return (
                  <motion.div
                    key={subject._id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.05 * index }}
                  >
                    <SubjectCard
                      name={subject.name}
                      icon={IconComponent}
                      progress={0}
                      color={subject.color as any}
                      onClick={() => onSubjectClick(subject._id, subject.name)}
                    />
                  </motion.div>
                );
              })
            ) : (
              <p className="text-muted-foreground">Aucune matière disponible</p>
            )}
          </div>
        </motion.section>

        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="space-y-4"
        >
          <h2 className="text-2xl font-bold">Mes Badges</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {badges.map((badge, index) => (
              <BadgeDisplay key={index} {...badge} />
            ))}
          </div>
        </motion.section>
      </div>

      <AlertDialog open={changeGradeDialogOpen} onOpenChange={setChangeGradeDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Changer de classe</AlertDialogTitle>
            <AlertDialogDescription>
              Sélectionnez votre nouvelle classe. Les matières disponibles seront mises à jour.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="py-4">
            <Select value={newGrade} onValueChange={setNewGrade}>
              <SelectTrigger data-testid="select-new-grade">
                <SelectValue placeholder="Choisissez votre classe" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="6ème">6ème</SelectItem>
                <SelectItem value="5ème">5ème</SelectItem>
                <SelectItem value="4ème">4ème</SelectItem>
                <SelectItem value="3ème">3ème</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel data-testid="button-cancel-grade-change">Annuler</AlertDialogCancel>
            <AlertDialogAction onClick={handleChangeGrade} data-testid="button-confirm-grade-change">
              Confirmer
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

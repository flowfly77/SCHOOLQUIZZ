import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Plus, Trophy, Flame, Star, Trash2 } from "lucide-react";
import { Logo } from "./Logo";
import { useState } from "react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { queryClient } from "@/lib/queryClient";
import { getProfiles, deleteProfile as deleteProfileDoc } from "@/lib/db";
import { useToast } from "@/hooks/use-toast";

import type { ProfileDoc } from '@/lib/db';

type Profile = ProfileDoc;

interface ProfileSelectorProps {
  onCreateNew: () => void;
  onSelectProfile: (profileId: string, name: string, grade: string) => void;
}

export default function ProfileSelector({ onCreateNew, onSelectProfile }: ProfileSelectorProps) {
  const { toast } = useToast();
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [profileToDelete, setProfileToDelete] = useState<Profile | null>(null);

  const { data: profiles, isLoading } = useQuery<Profile[]>({
    queryKey: ['profiles'],
    queryFn: getProfiles,
  });

  const deleteProfileMutation = useMutation({
    mutationFn: async (profileId: string) => {
      return deleteProfileDoc(profileId);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['profiles'] });
      toast({
        title: "Profil supprimé",
        description: "Le profil a été supprimé avec succès",
      });
      setDeleteDialogOpen(false);
      setProfileToDelete(null);
    },
    onError: () => {
      toast({
        title: "Erreur",
        description: "Impossible de supprimer le profil",
        variant: "destructive",
      });
    },
  });

  const handleDeleteClick = (e: React.MouseEvent, profile: Profile) => {
    e.stopPropagation();
    setProfileToDelete(profile);
    setDeleteDialogOpen(true);
  };

  const confirmDelete = () => {
    if (profileToDelete) {
      deleteProfileMutation.mutate(profileToDelete._id);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary/10 via-background to-accent/10">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4" data-testid="spinner-loading"></div>
          <p className="text-muted-foreground">Chargement des profils...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/10 via-background to-accent/10 p-8">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-4 mb-4">
            <Logo className="w-12 h-12" />
            <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              SCHOOLQUIZZ
            </h1>
          </div>
          <p className="text-xl text-muted-foreground">Sélectionnez votre profil pour continuer</p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3 mb-8">
          {profiles && profiles.length > 0 ? (
            profiles.map((profile) => (
              <Card 
                key={profile._id}
                className="hover-elevate active-elevate-2 cursor-pointer transition-all h-full" 
                data-testid={`card-profile-${profile._id}`}
                onClick={() => onSelectProfile(profile._id, profile.name, profile.grade)}
              >
                <CardHeader className="text-center">
                  <Avatar className="w-24 h-24 mx-auto mb-4">
                    <AvatarImage src={profile.avatarUrl} alt={profile.name} />
                    <AvatarFallback className="text-2xl bg-primary/20">
                      {profile.name.slice(0, 2).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                    <CardTitle className="text-xl" data-testid={`text-profile-name-${profile._id}`}>{profile.name}</CardTitle>
                  <CardDescription>
                    <Badge variant="outline" className="mt-2" data-testid={`badge-grade-${profile._id}`}> 
                      {profile.grade}
                    </Badge>
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Star className="w-4 h-4 text-primary" />
                      <span className="text-sm font-medium">XP</span>
                    </div>
                    <span className="font-bold text-primary" data-testid={`text-xp-${profile._id}`}>{profile.xp}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Flame className="w-4 h-4 text-orange-500" />
                      <span className="text-sm font-medium">Série</span>
                    </div>
                    <span className="font-bold text-orange-500" data-testid={`text-streak-${profile._id}`}>{profile.streak} jours</span>
                  </div>
                  <div className="flex gap-2 mt-4">
                    <Button className="flex-1" variant="outline" data-testid={`button-select-${profile._id}`}> 
                      Continuer
                    </Button>
                    <Button 
                      size="icon" 
                      variant="outline" 
                      onClick={(e) => handleDeleteClick(e, profile)}
                      data-testid={`button-delete-${profile._id}`}
                      className="text-destructive hover:bg-destructive hover:text-destructive-foreground"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            <div className="col-span-full text-center py-12">
              <Trophy className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
              <p className="text-lg text-muted-foreground mb-4">Aucun profil trouvé</p>
              <p className="text-sm text-muted-foreground">Créez votre premier profil pour commencer !</p>
            </div>
          )}
        </div>

        <Card className="hover-elevate active-elevate-2 cursor-pointer border-dashed border-2" onClick={onCreateNew} data-testid="card-create-profile">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <div className="rounded-full bg-primary/10 p-4 mb-4">
              <Plus className="w-8 h-8 text-primary" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Créer un nouveau profil</h3>
            <p className="text-muted-foreground text-center max-w-sm">
              Ajoutez un nouveau profil pour suivre votre progression séparément
            </p>
          </CardContent>
        </Card>
      </div>

      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmer la suppression</AlertDialogTitle>
            <AlertDialogDescription>
              Êtes-vous sûr de vouloir supprimer le profil de {profileToDelete?.name} ?
              Cette action est irréversible et supprimera toutes les statistiques, résultats et badges associés.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-testid="button-cancel-delete">Annuler</AlertDialogCancel>
            <AlertDialogAction 
              onClick={confirmDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              data-testid="button-confirm-delete"
            >
              Supprimer
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { getQuestions, recordQuizResult } from "@/lib/db";
import { QuizQuestion } from "./QuizQuestion";
import { CapitaleQuestion } from "./CapitaleQuestion";
import { Button } from "@/components/ui/button";
import { X, Trophy, Loader2 } from "lucide-react";
import { motion } from "framer-motion";
import { useToast } from "@/hooks/use-toast";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface QuizScreenProps {
  profileId: string;
  subjectId: string;
  subjectName: string;
  grade: string;
  onExit: () => void;
}

type Question = {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation?: string;
  difficulty: string;
  points: number;
};

export function QuizScreen({ profileId, subjectId, subjectName, grade, onExit }: QuizScreenProps) {
  const { toast } = useToast();
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [showExitDialog, setShowExitDialog] = useState(false);
  const [isComplete, setIsComplete] = useState(false);
  const [startTime] = useState(Date.now());

  // Charge 20 questions aléatoires pour la matière et la classe à partir de la base locale
  const { data: questions, isLoading } = useQuery<Question[]>({
    queryKey: ["questions", subjectId, grade],
    queryFn: () => getQuestions(subjectId, grade, 20),
  });

  const saveResultMutation = useMutation({
    mutationFn: async (result: {
      profileId: string;
      subjectId: string;
      score: number;
      totalQuestions: number;
      timeSpent: number;
    }) => {
      return recordQuizResult(
        result.profileId,
        result.subjectId,
        result.score,
        result.totalQuestions,
        result.timeSpent,
      );
    },
    onSuccess: (data: { xpGained: number }) => {
      // Invalidate stats and profiles caches to reflect updated XP and streak
      queryClient.invalidateQueries({ queryKey: ["stats", profileId] });
      queryClient.invalidateQueries({ queryKey: ["profiles"] });
      toast({
        title: "Quiz terminé !",
        description: `+${data.xpGained} XP gagné !`,
      });
    },
  });

  const handleAnswer = (isCorrect: boolean) => {
    if (isCorrect) {
      setScore(score + 1);
    }

    if (questions && currentQuestion + 1 < questions.length) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      setIsComplete(true);
      
      // Sauvegarder le résultat
      const timeSpent = Math.floor((Date.now() - startTime) / 1000);
      saveResultMutation.mutate({
        profileId,
        subjectId,
        score: isCorrect ? score + 1 : score,
        totalQuestions: questions?.length || 20,
        timeSpent,
      });
    }
  };

  const handleExit = () => {
    setShowExitDialog(true);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center" data-testid="loading-quiz">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-primary mx-auto mb-4" />
          <p className="text-muted-foreground">Préparation du quiz...</p>
        </div>
      </div>
    );
  }

  if (!questions || questions.length === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <div className="text-center">
          <p className="text-xl mb-4">Aucune question disponible pour ce chapitre</p>
          <Button onClick={onExit} data-testid="button-exit-no-questions">Retour au menu</Button>
        </div>
      </div>
    );
  }

  const percentage = Math.round((score / questions.length) * 100);

  if (isComplete) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="max-w-md w-full text-center space-y-6"
        >
          <div className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-gradient-to-br from-primary to-accent mb-4">
            <Trophy className="w-12 h-12 text-white" />
          </div>

          <h2 className="text-3xl font-bold" data-testid="text-quiz-complete">Quiz terminé !</h2>

          <div className="space-y-4">
            <div className="text-6xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent" data-testid="text-score-percentage">
              {percentage}%
            </div>

            <p className="text-lg text-muted-foreground" data-testid="text-score-details">
              {score} sur {questions.length} bonnes réponses
            </p>

            {percentage === 100 && (
              <motion.p
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-lg font-semibold text-primary"
              >
                🎉 Score parfait !
              </motion.p>
            )}
          </div>

          <Button
            onClick={onExit}
            size="lg"
            className="w-full"
            data-testid="button-exit-quiz"
          >
            Retour au menu
          </Button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col p-6">
      <div className="flex justify-between items-center mb-8">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={handleExit}
            data-testid="button-quiz-exit"
          >
            <X className="w-6 h-6" />
          </Button>
          <div>
            <p className="text-sm text-muted-foreground">
              Question {currentQuestion + 1} sur {questions.length}
            </p>
            <div className="w-64 h-2 bg-muted rounded-full mt-1">
              <motion.div
                className="h-full bg-primary rounded-full"
                initial={{ width: 0 }}
                animate={{
                  width: `${((currentQuestion + 1) / questions.length) * 100}%`,
                }}
              />
            </div>
          </div>
        </div>

        <div className="text-right">
          <p className="text-2xl font-bold" data-testid="text-current-score">{score}</p>
          <p className="text-sm text-muted-foreground">Score</p>
        </div>
      </div>

      {/* Afficher le bon composant selon le type de question */}
      {questions[currentQuestion].options[1] === "" ? (
        <CapitaleQuestion
          question={questions[currentQuestion].question}
          correctAnswer={questions[currentQuestion].options[0]}
          questionNumber={currentQuestion + 1}
          totalQuestions={questions.length}
          onAnswer={handleAnswer}
        />
      ) : (
        <QuizQuestion
          question={questions[currentQuestion].question}
          options={questions[currentQuestion].options}
          correctAnswer={questions[currentQuestion].correctAnswer}
          questionNumber={currentQuestion + 1}
          totalQuestions={questions.length}
          onAnswer={handleAnswer}
        />
      )}

      <AlertDialog open={showExitDialog} onOpenChange={setShowExitDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Quitter le quiz ?</AlertDialogTitle>
            <AlertDialogDescription>
              Votre progression ne sera pas sauvegardée si vous quittez maintenant.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-testid="button-cancel-exit">Continuer</AlertDialogCancel>
            <AlertDialogAction onClick={onExit} data-testid="button-confirm-exit">
              Quitter
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

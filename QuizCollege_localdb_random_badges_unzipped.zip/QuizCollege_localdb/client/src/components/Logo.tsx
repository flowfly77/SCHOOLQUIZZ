export function Logo({ className = "w-8 h-8" }: { className?: string }) {
  return (
    <svg 
      className={className} 
      viewBox="0 0 100 100" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
    >
      {/* Graduation cap */}
      <path 
        d="M50 20L10 35L50 50L90 35L50 20Z" 
        fill="url(#grad1)"
        stroke="currentColor" 
        strokeWidth="2"
      />
      <path 
        d="M20 40V55L50 70L80 55V40" 
        fill="url(#grad2)"
        stroke="currentColor" 
        strokeWidth="2"
      />
      {/* Book */}
      <rect 
        x="25" 
        y="60" 
        width="50" 
        height="25" 
        rx="2" 
        fill="url(#grad3)"
        stroke="currentColor" 
        strokeWidth="2"
      />
      <line 
        x1="50" 
        y1="60" 
        x2="50" 
        y2="85" 
        stroke="currentColor" 
        strokeWidth="2"
      />
      
      <defs>
        <linearGradient id="grad1" x1="10" y1="20" x2="90" y2="50">
          <stop offset="0%" stopColor="#8B5CF6" />
          <stop offset="100%" stopColor="#EC4899" />
        </linearGradient>
        <linearGradient id="grad2" x1="20" y1="40" x2="80" y2="70">
          <stop offset="0%" stopColor="#3B82F6" />
          <stop offset="100%" stopColor="#8B5CF6" />
        </linearGradient>
        <linearGradient id="grad3" x1="25" y1="60" x2="75" y2="85">
          <stop offset="0%" stopColor="#F59E0B" />
          <stop offset="100%" stopColor="#EF4444" />
        </linearGradient>
      </defs>
    </svg>
  );
}

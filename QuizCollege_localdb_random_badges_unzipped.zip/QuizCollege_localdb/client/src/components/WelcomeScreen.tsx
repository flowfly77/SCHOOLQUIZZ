import { Button } from "@/components/ui/button";
import { GraduationCap, Trophy, Star, Sparkles } from "lucide-react";
import { motion } from "framer-motion";

interface WelcomeScreenProps {
  onGetStarted: () => void;
}

export function WelcomeScreen({ onGetStarted }: WelcomeScreenProps) {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-primary/10 via-subject-francais/5 to-subject-math/10 -z-10" />
      
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="max-w-4xl w-full text-center space-y-8"
      >
        <div className="space-y-4">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
            className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-gradient-to-br from-primary to-subject-math mb-4"
          >
            <GraduationCap className="w-12 h-12 text-primary-foreground" />
          </motion.div>

          <h1 className="text-4xl md:text-6xl font-bold gradient-text-primary">
            Apprends en t'amusant !
          </h1>
          
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto">
            Teste tes connaissances, progresse à ton rythme et gagne des badges en répondant à des quiz sur toutes tes matières du collège
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-3xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="p-6 rounded-2xl bg-card border border-card-border space-y-3"
          >
            <div className="w-12 h-12 rounded-full bg-subject-francais/10 flex items-center justify-center mx-auto">
              <Star className="w-6 h-6 text-subject-francais" />
            </div>
            <h3 className="font-semibold text-lg">Programme complet Collège</h3>
            <p className="text-sm text-muted-foreground">
              de la 6ème à la 3ème
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="p-6 rounded-2xl bg-card border border-card-border space-y-3"
          >
            <div className="w-12 h-12 rounded-full bg-badge-gold/20 flex items-center justify-center mx-auto">
              <Trophy className="w-6 h-6 text-badge-gold" />
            </div>
            <h3 className="font-semibold text-lg">Badges</h3>
            <p className="text-sm text-muted-foreground">
              Débloque des badges bronze, argent et or
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="p-6 rounded-2xl bg-card border border-card-border space-y-3"
          >
            <div className="w-12 h-12 rounded-full bg-success/10 flex items-center justify-center mx-auto">
              <Sparkles className="w-6 h-6 text-success" />
            </div>
            <h3 className="font-semibold text-lg">Ta Progression</h3>
            <p className="text-sm text-muted-foreground">
              Suis tes progrès et améliore-toi
            </p>
          </motion.div>
        </div>

        <div className="pt-4">
          <Button
            size="lg"
            className="text-lg px-8 rounded-full"
            onClick={onGetStarted}
            data-testid="button-get-started"
          >
            Commencer l'aventure
          </Button>
        </div>
      </motion.div>
    </div>
  );
}

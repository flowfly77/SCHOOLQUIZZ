import { LucideIcon } from "lucide-react";

interface StatsCardProps {
  title: string;
  value: string | number;
  icon: LucideIcon;
  description?: string;
}

export function StatsCard({ title, value, icon: Icon, description }: StatsCardProps) {
  return (
    <div className="p-6 rounded-2xl bg-gradient-to-br from-orange-500/20 to-yellow-500/20 border border-orange-500/30 space-y-3" data-testid={`stats-${title.toLowerCase()}`}>
      <div className="flex items-center justify-between">
        <div className="p-3 rounded-xl bg-gradient-to-br from-orange-500 to-yellow-500">
          <Icon className="w-5 h-5 text-white" />
        </div>
      </div>
      <div>
        <div className="text-3xl font-bold">{value}</div>
        <div className="text-sm text-muted-foreground mt-1">{title}</div>
        {description && (
          <div className="text-xs text-muted-foreground mt-2">{description}</div>
        )}
      </div>
    </div>
  );
}

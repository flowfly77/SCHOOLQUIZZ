import { motion } from "framer-motion";

interface SubjectCardProps {
  name: string;
  icon: any;
  progress: number;
  color: string;
  onClick?: () => void;
}

export function SubjectCard({ name, icon: Icon, color, onClick }: SubjectCardProps) {
  return (
    <motion.button
      whileHover={{ y: -4 }}
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      className={`relative p-6 rounded-2xl border-2 ${color} text-left w-full group`}
      data-testid={`card-subject-${name.toLowerCase()}`}
    >
      <div className="flex items-center gap-4">
        <div className="w-16 h-16 flex items-center justify-center flex-shrink-0 rounded-xl bg-white/20 dark:bg-white/20 backdrop-blur-sm">
          <Icon className="w-10 h-10" />
        </div>
        <div className="flex-1">
          <h3 className="text-xl font-bold text-gray-900 dark:text-white">{name}</h3>
        </div>
      </div>
    </motion.button>
  );
}

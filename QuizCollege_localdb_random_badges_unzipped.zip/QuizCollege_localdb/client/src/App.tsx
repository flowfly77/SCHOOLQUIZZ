import { useState } from "react";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/ThemeProvider";
import { WelcomeScreen } from "@/components/WelcomeScreen";
import { ProfileCreation } from "@/components/ProfileCreation";
import ProfileSelector from "@/components/ProfileSelector";
import { Dashboard } from "@/components/Dashboard";
import { QuizScreen } from "@/components/QuizScreen";

type AppState = "welcome" | "profile-select" | "profile-create" | "dashboard" | "quiz";

function App() {
  const [appState, setAppState] = useState<AppState>("welcome");
  const [currentProfileId, setCurrentProfileId] = useState("");
  const [userName, setUserName] = useState("");
  const [userGrade, setUserGrade] = useState("");
  const [selectedSubjectId, setSelectedSubjectId] = useState("");
  const [selectedSubjectName, setSelectedSubjectName] = useState("");

  const handleGetStarted = () => {
    setAppState("profile-select");
  };

  const handleCreateNewProfile = () => {
    setAppState("profile-create");
  };

  const handleSelectProfile = (profileId: string, name: string, grade: string) => {
    setCurrentProfileId(profileId);
    setUserName(name);
    setUserGrade(grade);
    setAppState("dashboard");
  };

  const handleProfileComplete = (profileId: string, name: string, grade: string) => {
    setCurrentProfileId(profileId);
    setUserName(name);
    setUserGrade(grade);
    setAppState("dashboard");
  };

  const handleSubjectClick = (subjectId: string, subjectName: string) => {
    setSelectedSubjectId(subjectId);
    setSelectedSubjectName(subjectName);
    setAppState("quiz");
  };

  const handleBackToDashboard = () => {
    setAppState("dashboard");
  };

  const handleBackToProfiles = () => {
    setCurrentProfileId("");
    setUserName("");
    setUserGrade("");
    // Invalidate the profiles cache to refresh the list when returning
    queryClient.invalidateQueries({ queryKey: ["profiles"] });
    setAppState("profile-select");
  };

  const handleGradeChange = (newGrade: string) => {
    setUserGrade(newGrade);
  };


  const handleQuizExit = () => {
    setAppState("dashboard");
  };

  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <TooltipProvider>
          {appState === "welcome" && (
            <WelcomeScreen onGetStarted={handleGetStarted} />
          )}
          
          {appState === "profile-select" && (
            <ProfileSelector 
              onCreateNew={handleCreateNewProfile}
              onSelectProfile={handleSelectProfile}
            />
          )}
          
          {appState === "profile-create" && (
            <ProfileCreation onComplete={handleProfileComplete} />
          )}
          
          {appState === "dashboard" && (
            <Dashboard
              profileId={currentProfileId}
              userName={userName}
              userGrade={userGrade}
              onSubjectClick={handleSubjectClick}
              onBackToProfiles={handleBackToProfiles}
              onGradeChange={handleGradeChange}
            />
          )}
          
          {appState === "quiz" && (
            <QuizScreen
              profileId={currentProfileId}
              subjectId={selectedSubjectId}
              subjectName={selectedSubjectName}
              grade={userGrade}
              onExit={handleQuizExit}
            />
          )}
          
          <Toaster />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;

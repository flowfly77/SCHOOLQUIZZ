/*
 * Simple local database layer for QuizCollège using browser storage.
 *
 * This module replaces the PouchDB implementation used on Replit with
 * a lightweight system based on the Web Storage API (localStorage).
 * It stores all data (profiles, subjects, questions, quiz results) as a
 * single JSON object under a constant key. Because localStorage only
 * supports strings, we serialise and parse the object on every read and
 * write. For small datasets (a few dozen profiles and a handful of
 * questions) this is sufficient and has the advantage of working
 * seamlessly on desktop browsers, Android (via Capacitor) and iOS Safari.
 *
 * Note: localStorage has a per‑domain size limit (around 5 MB in most
 * browsers). If you plan to import large question banks (tens of
 * thousands of records), consider using a more robust offline database
 * such as IndexedDB via a library like Dexie.js, or a cloud service with
 * offline support. For the purposes of this educational app, the current
 * approach should suffice.
 */

// Types --------------------------------------------------------------------

export interface BaseDoc {
  _id: string;
  type: string;
}

export interface ProfileDoc extends BaseDoc {
  type: 'profile';
  name: string;
  grade: string;
  avatarUrl?: string;
  xp: number;
  streak: number;
  lastQuizAt?: string;
}

export interface SubjectDoc extends BaseDoc {
  type: 'subject';
  /**
   * Display name of the subject. This is shown in the dashboard.
   */
  name: string;
  /**
   * Short identifier used for routing or data lookups. Slugs should be unique
   * across all subjects.
   */
  slug: string;
  /**
   * Hex colour used to decorate the subject card. Any valid CSS colour is
   * accepted.
   */
  color: string;
  /**
   * Name of the icon to display. These correspond to icons exported from
   * `lucide-react` or our custom SubjectIcons component. If an unknown icon
   * is provided the card may not render correctly.
   */
  icon: string;
  /**
   * Short description shown on the subject card.
   */
  description?: string;
  /**
   * List of class levels (6ème, 5ème, 4ème, 3ème) for which this subject is
   * available. When filtering subjects for a given profile the grade must
   * appear in this array. Use 'all' to make a subject available for all
   * grades.
   */
  grades: string[];
}

export interface QuestionDoc extends BaseDoc {
  type: 'question';
  subjectId: string;
  grade: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation?: string;
  difficulty: string;
  points: number;
}

export interface QuizResultDoc extends BaseDoc {
  type: 'quizResult';
  profileId: string;
  subjectId: string;
  score: number;
  totalQuestions: number;
  timeSpent: number;
  completedAt: string;
}

export interface Stats {
  quizzesCompleted: number;
  accuracy: number;
  totalBadges: number;
  xp: number;
  streak: number;
}

// Internal storage structure --------------------------------------------------

interface DataStorage {
  profiles: Record<string, ProfileDoc>;
  subjects: Record<string, SubjectDoc>;
  questions: Record<string, QuestionDoc>;
  quizResults: Record<string, QuizResultDoc>;
}

const STORAGE_KEY = 'quizcollege_data';

/**
 * Load the persisted data from localStorage. If no data exists yet,
 * initialise it with empty collections. Returns a mutable object.
 */
function loadData(): DataStorage {
  const raw = localStorage.getItem(STORAGE_KEY);
  if (raw) {
    try {
      return JSON.parse(raw) as DataStorage;
    } catch (err) {
      console.error('Failed to parse stored data:', err);
    }
  }
  return { profiles: {}, subjects: {}, questions: {}, quizResults: {} };
}

/**
 * Persist the provided data back to localStorage.
 */
function saveData(data: DataStorage): void {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}

/**
 * Generate a unique identifier with a given prefix. Uses
 * `crypto.randomUUID()` when available (supported in modern browsers and
 * Node.js v19+). Falls back to a simple random string if necessary.
 */
function generateId(prefix: string): string {
  let rand: string;
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    rand = crypto.randomUUID();
  } else {
    rand = Math.random().toString(36).substring(2) + Date.now().toString(36);
  }
  return `${prefix}_${rand}`;
}

// Seed initial data ---------------------------------------------------------

/**
 * Check if the database has any subjects. If not, seed it with a small set
 * of subjects and questions. This function is idempotent.
 */
function seedInitialData(): void {
  const data = loadData();
  const hasSubjects = Object.keys(data.subjects).length > 0;
  if (hasSubjects) return;

  // Define all subjects across the different classes. Each subject declares
  // which grades it applies to via the `grades` array. When filtering
  // subjects for a profile, only those whose grades include the profile’s
  // class (e.g. "6ème") will be shown. The order of subjects in this array
  // defines the display order in the dashboard; the world capitals and
  // culture pop quizzes appear at the end as requested.
  const subjects: SubjectDoc[] = [
    {
      _id: 'subject_francais',
      type: 'subject',
      name: 'Français',
      slug: 'francais',
      color: '#e74c3c',
      icon: 'Book',
      description: 'Questions de grammaire, orthographe et littérature.',
      grades: ['6ème','5ème','4ème','3ème'],
    },
    {
      _id: 'subject_anglais',
      type: 'subject',
      name: 'Anglais',
      slug: 'anglais',
      color: '#2980b9',
      icon: 'FlagGB',
      description: 'Vocabulaires, phrases et culture anglophone.',
      grades: ['6ème','5ème','4ème','3ème'],
    },
    {
      _id: 'subject_histoire',
      type: 'subject',
      name: 'Histoire',
      slug: 'histoire',
      color: '#8e44ad',
      icon: 'ScrollText',
      description: 'Repères historiques et grandes périodes.',
      grades: ['6ème','5ème','4ème','3ème'],
    },
    {
      _id: 'subject_geographie',
      type: 'subject',
      name: 'Géographie',
      slug: 'geographie',
      color: '#16a085',
      icon: 'MapPin',
      description: 'Cartographie et compréhension des territoires.',
      grades: ['6ème','5ème','4ème','3ème'],
    },
    {
      _id: 'subject_math',
      type: 'subject',
      name: 'Mathématiques',
      slug: 'mathematiques',
      color: '#3498db',
      icon: 'Calculator',
      description: 'Problèmes de calcul, géométrie et logique.',
      grades: ['6ème','5ème','4ème','3ème'],
    },
    {
      _id: 'subject_sciences',
      type: 'subject',
      name: 'Sciences',
      slug: 'sciences',
      color: '#27ae60',
      icon: 'Microscope',
      description: 'Biologie et premières notions de physique et chimie.',
      grades: ['6ème'],
    },
    {
      _id: 'subject_physique',
      type: 'subject',
      name: 'Physique‑Chimie',
      slug: 'physique-chimie',
      color: '#9b59b6',
      icon: 'FlaskConical',
      description: 'Électricité, états de la matière et réactions.',
      grades: ['5ème','4ème','3ème'],
    },
    {
      _id: 'subject_svt',
      type: 'subject',
      name: 'SVT',
      slug: 'svt',
      color: '#2ecc71',
      icon: 'DNAIcon',
      description: 'Sciences de la vie et de la Terre : corps humain, biodiversité.',
      grades: ['5ème','4ème','3ème'],
    },
    {
      _id: 'subject_technologie',
      type: 'subject',
      name: 'Technologie',
      slug: 'technologie',
      color: '#e67e22',
      icon: 'Wrench',
      description: 'Découverte des objets techniques et de la programmation.',
      grades: ['5ème','4ème','3ème'],
    },
    {
      _id: 'subject_eps',
      type: 'subject',
      name: 'EPS',
      slug: 'eps',
      color: '#f39c12',
      icon: 'Gamepad2',
      description: 'Éducation physique et sportive.',
      grades: ['6ème','5ème','4ème','3ème'],
    },
    {
      _id: 'subject_art',
      type: 'subject',
      name: 'Arts Plastiques',
      slug: 'arts',
      color: '#d35400',
      icon: 'BookText',
      description: 'Création artistique et exploration des techniques.',
      grades: ['6ème','5ème','4ème','3ème'],
    },
    {
      _id: 'subject_musique',
      type: 'subject',
      name: 'Musique',
      slug: 'musique',
      color: '#95a5a6',
      icon: 'Music',
      description: 'Pratique musicale et écoute active.',
      grades: ['6ème','5ème','4ème','3ème'],
    },
    {
      _id: 'subject_italien',
      type: 'subject',
      name: 'Italien',
      slug: 'italien',
      color: '#e84393',
      icon: 'FlagIT',
      description: 'Langue vivante : vocabulaire et culture italienne.',
      grades: ['6ème','5ème','4ème','3ème'],
    },
    {
      _id: 'subject_espagnol',
      type: 'subject',
      name: 'Espagnol',
      slug: 'espagnol',
      color: '#e74c3c',
      icon: 'FlagES',
      description: 'Langue vivante : vocabulaire et culture hispanique.',
      grades: ['5ème','4ème','3ème'],
    },
    {
      _id: 'subject_emc',
      type: 'subject',
      name: 'EMC',
      slug: 'emc',
      color: '#34495e',
      icon: 'ScrollIcon',
      description: 'Enseignement moral et civique.',
      grades: ['6ème','5ème','4ème','3ème'],
    },
    {
      _id: 'subject_capitales',
      type: 'subject',
      name: 'Capitales du monde',
      slug: 'capitales',
      color: '#1abc9c',
      icon: 'Globe',
      description: 'Quiz sur les capitales des pays du monde.',
      grades: ['6ème','5ème','4ème','3ème'],
    },
    {
      _id: 'subject_culturepop',
      type: 'subject',
      name: 'Culture Pop',
      slug: 'culturepop',
      color: '#9b59b6',
      icon: 'Gamepad2',
      description: 'Questions de culture générale et pop culture.',
      grades: ['6ème','5ème','4ème','3ème'],
    },
  ];

  const questions: QuestionDoc[] = [
    // Français – 6ème
    { _id: 'question_fr_6_1', type: 'question', subjectId: 'subject_francais', grade: '6ème', question: 'Quel est le verbe dans la phrase « Le chat noir dort » ?', options: ['dort', 'chat', 'noir', 'le'], correctAnswer: 0, difficulty: 'facile', points: 10 },
    { _id: 'question_fr_6_2', type: 'question', subjectId: 'subject_francais', grade: '6ème', question: 'Dans quel genre est « une histoire » ?', options: ['masculin', 'féminin', 'neutre', 'pluriel'], correctAnswer: 1, difficulty: 'facile', points: 10 },
    { _id: 'question_fr_6_3', type: 'question', subjectId: 'subject_francais', grade: '6ème', question: 'Quelle est la classe grammaticale du mot « rapidement » ?', options: ['nom', 'verbe', 'adjectif', 'adverbe'], correctAnswer: 3, difficulty: 'facile', points: 10 },
    { _id: 'question_fr_6_4', type: 'question', subjectId: 'subject_francais', grade: '6ème', question: 'Qu\'est‑ce qu\'un adjectif ?', options: ['Un mot qui qualifie un nom', 'Un verbe', 'Un adverbe', 'Un pronom'], correctAnswer: 0, difficulty: 'facile', points: 10 },
    { _id: 'question_fr_6_5', type: 'question', subjectId: 'subject_francais', grade: '6ème', question: 'Quel est le pluriel de « cheval » ?', options: ['chevaux', 'chevales', 'chevals', 'chevueux'], correctAnswer: 0, difficulty: 'facile', points: 10 },

    // Français – 5ème
    { _id: 'question_fr_5_1', type: 'question', subjectId: 'subject_francais', grade: '5ème', question: 'Dans quel temps est conjugué le verbe « mangeais » ?', options: ['présent', 'futur simple', 'imparfait', 'passé simple'], correctAnswer: 2, difficulty: 'moyen', points: 10 },
    { _id: 'question_fr_5_2', type: 'question', subjectId: 'subject_francais', grade: '5ème', question: 'Quel est le féminin de « acteur » ?', options: ['actrice', 'acteuse', 'acteur', 'acteure'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_fr_5_3', type: 'question', subjectId: 'subject_francais', grade: '5ème', question: 'Quelle figure de style compare deux éléments avec « comme » ?', options: ['métaphore', 'comparaison', 'personnification', 'hyperbole'], correctAnswer: 1, difficulty: 'moyen', points: 10 },
    { _id: 'question_fr_5_4', type: 'question', subjectId: 'subject_francais', grade: '5ème', question: 'Dans la phrase « Je suis allé au marché », quel est le sujet ?', options: ['je', 'suis', 'allé', 'marché'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_fr_5_5', type: 'question', subjectId: 'subject_francais', grade: '5ème', question: 'Que signifie le mot « synonyme » ?', options: ['mot de sens opposé', 'mot de sens proche', 'mot inventé', 'mot compliqué'], correctAnswer: 1, difficulty: 'moyen', points: 10 },

    // Français – 4ème
    { _id: 'question_fr_4_1', type: 'question', subjectId: 'subject_francais', grade: '4ème', question: 'Qu\'appelle‑t‑on un complément circonstanciel de temps ?', options: ['Un mot qui décrit quand se passe l\'action', 'Un sujet de phrase', 'Un verbe', 'Un adjectif'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_fr_4_2', type: 'question', subjectId: 'subject_francais', grade: '4ème', question: 'Quel type de texte raconte une histoire fictive ?', options: ['récit', 'argumentatif', 'explicatif', 'descriptif'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_fr_4_3', type: 'question', subjectId: 'subject_francais', grade: '4ème', question: 'Qui est l\'auteur des « Misérables » ?', options: ['Victor Hugo', 'Molière', 'Émile Zola', 'Gustave Flaubert'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_fr_4_4', type: 'question', subjectId: 'subject_francais', grade: '4ème', question: 'Qu\'est‑ce qu\'une proposition subordonnée ?', options: ['Une partie de phrase dépendant d\'une principale', 'Une phrase indépendante', 'Une exclamation', 'Un adjectif'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_fr_4_5', type: 'question', subjectId: 'subject_francais', grade: '4ème', question: 'Quelle est la valeur du pronom relatif « qui » ?', options: ['sujet', 'complément', 'adjoint', 'article'], correctAnswer: 0, difficulty: 'moyen', points: 10 },

    // Français – 3ème
    { _id: 'question_fr_3_1', type: 'question', subjectId: 'subject_francais', grade: '3ème', question: 'Qu\'est‑ce qu\'une proposition subordonnée relative ?', options: ['Une proposition qui complète un nom et commence par un pronom relatif', 'Une proposition principale', 'Une phrase exclamative', 'Un complément d\'objet'], correctAnswer: 0, difficulty: 'difficile', points: 10 },
    { _id: 'question_fr_3_2', type: 'question', subjectId: 'subject_francais', grade: '3ème', question: 'Avec quel auxiliaire le participe passé s\'accorde‑t‑il en genre et en nombre ?', options: ['avoir', 'être', 'faire', 'pouvoir'], correctAnswer: 1, difficulty: 'difficile', points: 10 },
    { _id: 'question_fr_3_3', type: 'question', subjectId: 'subject_francais', grade: '3ème', question: 'Quel mouvement littéraire du XIXe siècle prône l\'expression des émotions et de l\'individualité ?', options: ['réalisme', 'romantisme', 'naturalisme', 'symbolisme'], correctAnswer: 1, difficulty: 'difficile', points: 10 },
    { _id: 'question_fr_3_4', type: 'question', subjectId: 'subject_francais', grade: '3ème', question: 'Quelle est la fonction du complément d\'objet direct ?', options: ['compléter le verbe sans préposition', 'compléter le sujet', 'exprimer le temps', 'qualifier un nom'], correctAnswer: 0, difficulty: 'difficile', points: 10 },
    { _id: 'question_fr_3_5', type: 'question', subjectId: 'subject_francais', grade: '3ème', question: 'Quel est l\'infinitif du verbe conjugué « ils vinrent » ?', options: ['venir', 'voir', 'vendre', 'vivre'], correctAnswer: 0, difficulty: 'difficile', points: 10 },

    // Anglais – 6ème
    { _id: 'question_en_6_1', type: 'question', subjectId: 'subject_anglais', grade: '6ème', question: 'Comment dit‑on « bonjour » en anglais ?', options: ['hello', 'hola', 'bonjour', 'ciao'], correctAnswer: 0, difficulty: 'facile', points: 10 },
    { _id: 'question_en_6_2', type: 'question', subjectId: 'subject_anglais', grade: '6ème', question: 'Quel est le pluriel de « bus » ?', options: ['bus', 'buss', 'buses', 'busses'], correctAnswer: 2, difficulty: 'facile', points: 10 },
    { _id: 'question_en_6_3', type: 'question', subjectId: 'subject_anglais', grade: '6ème', question: 'Quelle est la couleur « blue » en français ?', options: ['rouge', 'bleu', 'vert', 'jaune'], correctAnswer: 1, difficulty: 'facile', points: 10 },
    { _id: 'question_en_6_4', type: 'question', subjectId: 'subject_anglais', grade: '6ème', question: 'Comment dit‑on « chat » en anglais ?', options: ['dog', 'cat', 'mouse', 'rabbit'], correctAnswer: 1, difficulty: 'facile', points: 10 },
    { _id: 'question_en_6_5', type: 'question', subjectId: 'subject_anglais', grade: '6ème', question: 'Quel est le verbe « être » à la première personne du singulier ?', options: ['am', 'is', 'are', 'be'], correctAnswer: 0, difficulty: 'facile', points: 10 },

    // Anglais – 5ème
    { _id: 'question_en_5_1', type: 'question', subjectId: 'subject_anglais', grade: '5ème', question: 'Quelle est la forme correcte : « She is eat » ou « She is eating » ?', options: ['She is eat', 'She is eating', 'She eat', 'She eating'], correctAnswer: 1, difficulty: 'moyen', points: 10 },
    { _id: 'question_en_5_2', type: 'question', subjectId: 'subject_anglais', grade: '5ème', question: 'Comment dit‑on « j\'ai 12 ans » en anglais ?', options: ['I have 12 years', 'I am 12 years old', 'I have 12', 'I am 12'], correctAnswer: 1, difficulty: 'moyen', points: 10 },
    { _id: 'question_en_5_3', type: 'question', subjectId: 'subject_anglais', grade: '5ème', question: 'Quel est le prétérit du verbe « go » ?', options: ['goed', 'went', 'gone', 'go'], correctAnswer: 1, difficulty: 'moyen', points: 10 },
    { _id: 'question_en_5_4', type: 'question', subjectId: 'subject_anglais', grade: '5ème', question: 'Comment dit‑on « merci » en anglais ?', options: ['thanks', 'please', 'hello', 'goodbye'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_en_5_5', type: 'question', subjectId: 'subject_anglais', grade: '5ème', question: 'Quelle est la forme négative de « He plays football » ?', options: ['He don\'t play football', 'He doesn\'t play football', 'He isn\'t play football', 'He didn\'t plays football'], correctAnswer: 1, difficulty: 'moyen', points: 10 },

    // Anglais – 4ème
    { _id: 'question_en_4_1', type: 'question', subjectId: 'subject_anglais', grade: '4ème', question: 'Quelle est la traduction de « Il a déjà fini » ?', options: ['He has already finished', 'He already finished', 'He has finish', 'He finished already'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_en_4_2', type: 'question', subjectId: 'subject_anglais', grade: '4ème', question: 'Quel auxiliaire utilise‑t‑on pour former le futur simple en anglais ?', options: ['do', 'will', 'have', 'shall'], correctAnswer: 1, difficulty: 'moyen', points: 10 },
    { _id: 'question_en_4_3', type: 'question', subjectId: 'subject_anglais', grade: '4ème', question: 'Quel est le comparatif de « good » ?', options: ['gooder', 'more good', 'better', 'best'], correctAnswer: 2, difficulty: 'moyen', points: 10 },
    { _id: 'question_en_4_4', type: 'question', subjectId: 'subject_anglais', grade: '4ème', question: 'Comment dit‑on « nous sommes allés » en anglais ?', options: ['we have go', 'we went', 'we gone', 'we go'], correctAnswer: 1, difficulty: 'moyen', points: 10 },
    { _id: 'question_en_4_5', type: 'question', subjectId: 'subject_anglais', grade: '4ème', question: 'À quoi sert l\'expression « used to » en anglais ?', options: ['pour parler d\'une habitude passée', 'pour parler du futur', 'pour parler du présent', 'pour parler d\'une capacité'], correctAnswer: 0, difficulty: 'moyen', points: 10 },

    // Anglais – 3ème
    { _id: 'question_en_3_1', type: 'question', subjectId: 'subject_anglais', grade: '3ème', question: 'Que signifie l\'expression « used to » ?', options: ['avoir l\'habitude de dans le passé', 'devoir', 'vouloir', 'pouvoir'], correctAnswer: 0, difficulty: 'difficile', points: 10 },
    { _id: 'question_en_3_2', type: 'question', subjectId: 'subject_anglais', grade: '3ème', question: 'Quelle est la forme passive de « They build a school » ?', options: ['A school is built by them', 'They are built a school', 'A school built', 'The school is build'], correctAnswer: 0, difficulty: 'difficile', points: 10 },
    { _id: 'question_en_3_3', type: 'question', subjectId: 'subject_anglais', grade: '3ème', question: 'Que veut dire « environmental sustainability » ?', options: ['pollution', 'développement durable', 'énergie fossile', 'déforestation'], correctAnswer: 1, difficulty: 'difficile', points: 10 },
    { _id: 'question_en_3_4', type: 'question', subjectId: 'subject_anglais', grade: '3ème', question: 'Quel est le past participle du verbe « see » ?', options: ['saw', 'seen', 'see', 'sees'], correctAnswer: 1, difficulty: 'difficile', points: 10 },
    { _id: 'question_en_3_5', type: 'question', subjectId: 'subject_anglais', grade: '3ème', question: 'Comment dit‑on « Je ne suis pas d\'accord » en anglais ?', options: ['I don\'t agree', 'I am not agree', 'I not agree', 'I disagree not'], correctAnswer: 0, difficulty: 'difficile', points: 10 },

    // Histoire – 6ème
    { _id: 'question_hist_6_1', type: 'question', subjectId: 'subject_histoire', grade: '6ème', question: 'Quelle période correspond à la Préhistoire ?', options: ['Avant l\'invention de l\'écriture', 'Période romaine', 'Moyen Âge', 'Renaissance'], correctAnswer: 0, difficulty: 'facile', points: 10 },
    { _id: 'question_hist_6_2', type: 'question', subjectId: 'subject_histoire', grade: '6ème', question: 'Quel peuple a construit les pyramides d\'Égypte ?', options: ['Les Romains', 'Les Égyptiens', 'Les Grecs', 'Les Perses'], correctAnswer: 1, difficulty: 'facile', points: 10 },
    { _id: 'question_hist_6_3', type: 'question', subjectId: 'subject_histoire', grade: '6ème', question: 'Quel empereur romain a conquis la Gaule ?', options: ['Auguste', 'Jules César', 'Néron', 'Trajan'], correctAnswer: 1, difficulty: 'facile', points: 10 },
    { _id: 'question_hist_6_4', type: 'question', subjectId: 'subject_histoire', grade: '6ème', question: 'Où se situent les premières civilisations agricoles ?', options: ['Afrique du Sud', 'Mésopotamie', 'Europe', 'Amérique'], correctAnswer: 1, difficulty: 'facile', points: 10 },
    { _id: 'question_hist_6_5', type: 'question', subjectId: 'subject_histoire', grade: '6ème', question: 'Quel fleuve traverse la ville de Rome ?', options: ['Danube', 'Rhin', 'Tigre', 'Tibre'], correctAnswer: 3, difficulty: 'facile', points: 10 },

    // Histoire – 5ème
    { _id: 'question_hist_5_1', type: 'question', subjectId: 'subject_histoire', grade: '5ème', question: 'Quelle bataille met fin à la guerre de Cent Ans ?', options: ['Azincourt', 'Castillon', 'Poitiers', 'Orléans'], correctAnswer: 1, difficulty: 'moyen', points: 10 },
    { _id: 'question_hist_5_2', type: 'question', subjectId: 'subject_histoire', grade: '5ème', question: 'Qui était Jeanne d\'Arc ?', options: ['Une reine', 'Une héroïne qui a aidé Charles VII', 'Une exploratrice', 'Une sainte italienne'], correctAnswer: 1, difficulty: 'moyen', points: 10 },
    { _id: 'question_hist_5_3', type: 'question', subjectId: 'subject_histoire', grade: '5ème', question: 'Quel était l\'objectif des grandes découvertes du XVe siècle ?', options: ['Trouver de nouvelles routes maritimes', 'Construire des pyramides', 'Fonder des universités', 'Découvrir la photographie'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_hist_5_4', type: 'question', subjectId: 'subject_histoire', grade: '5ème', question: 'À quel siècle correspond la Renaissance ?', options: ['XIe siècle', 'XVe‑XVIe siècles', 'XVIIIe siècle', 'XIXe siècle'], correctAnswer: 1, difficulty: 'moyen', points: 10 },
    { _id: 'question_hist_5_5', type: 'question', subjectId: 'subject_histoire', grade: '5ème', question: 'Quel roi de France a instauré l\'édit de Nantes ?', options: ['Henri IV', 'Louis XIV', 'François Ier', 'Charlemagne'], correctAnswer: 0, difficulty: 'moyen', points: 10 },

    // Histoire – 4ème
    { _id: 'question_hist_4_1', type: 'question', subjectId: 'subject_histoire', grade: '4ème', question: 'En quelle année la Révolution française commence‑t‑elle ?', options: ['1789', '1792', '1815', '1776'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_hist_4_2', type: 'question', subjectId: 'subject_histoire', grade: '4ème', question: 'Quel document affirme les droits fondamentaux en 1789 ?', options: ['Code civil', 'Déclaration des droits de l\'homme et du citoyen', 'Constitution de 1791', 'Serment du Jeu de paume'], correctAnswer: 1, difficulty: 'moyen', points: 10 },
    { _id: 'question_hist_4_3', type: 'question', subjectId: 'subject_histoire', grade: '4ème', question: 'Qui est Napoléon Bonaparte ?', options: ['Un roi d\'Italie', 'Un scientifique', 'Un général puis empereur de France', 'Un philosophe grec'], correctAnswer: 2, difficulty: 'moyen', points: 10 },
    { _id: 'question_hist_4_4', type: 'question', subjectId: 'subject_histoire', grade: '4ème', question: 'Quel est l\'événement principal du 14 juillet 1789 ?', options: ['Prise de la Bastille', 'Déclaration d\'indépendance', 'Sacre de Napoléon', 'Guerre de Sécession'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_hist_4_5', type: 'question', subjectId: 'subject_histoire', grade: '4ème', question: 'Qu\'est‑ce que l\'abolition de l\'esclavage ?', options: ['La suppression de l\'esclavage', 'La mise en place de la traite négrière', 'Un accord commercial', 'Un nouveau code du travail'], correctAnswer: 0, difficulty: 'moyen', points: 10 },

    // Histoire – 3ème
    { _id: 'question_hist_3_1', type: 'question', subjectId: 'subject_histoire', grade: '3ème', question: 'Quel événement déclenche la Première Guerre mondiale ?', options: ['L\'assassinat de François‑Ferdinand', 'La Révolution russe', 'La naissance de Napoléon', 'La chute du mur de Berlin'], correctAnswer: 0, difficulty: 'difficile', points: 10 },
    { _id: 'question_hist_3_2', type: 'question', subjectId: 'subject_histoire', grade: '3ème', question: 'Quels pays composent les Alliés durant la Seconde Guerre mondiale ?', options: ['Allemagne, Italie, Japon', 'France, Royaume‑Uni, URSS, États‑Unis', 'Espagne, Suisse, Portugal', 'Canada, Australie, Inde'], correctAnswer: 1, difficulty: 'difficile', points: 10 },
    { _id: 'question_hist_3_3', type: 'question', subjectId: 'subject_histoire', grade: '3ème', question: 'Quel traité met fin à la Première Guerre mondiale ?', options: ['Traité de Versailles', 'Traité de Rome', 'Traité de Tordesillas', 'Pacte de Varsovie'], correctAnswer: 0, difficulty: 'difficile', points: 10 },
    { _id: 'question_hist_3_4', type: 'question', subjectId: 'subject_histoire', grade: '3ème', question: 'Qu\'est‑ce que le régime de Vichy ?', options: ['Un gouvernement français collaborant avec l\'Allemagne nazie', 'Un film', 'Une chanson', 'Une ville d\'Italie'], correctAnswer: 0, difficulty: 'difficile', points: 10 },
    { _id: 'question_hist_3_5', type: 'question', subjectId: 'subject_histoire', grade: '3ème', question: 'Qui était Charles de Gaulle ?', options: ['Un général et homme d\'État français', 'Un peintre', 'Un roi d\'Espagne', 'Un mathématicien'], correctAnswer: 0, difficulty: 'difficile', points: 10 },

    // Géographie – 6ème
    { _id: 'question_geo_6_1', type: 'question', subjectId: 'subject_geographie', grade: '6ème', question: 'Combien y a‑t‑il de continents sur Terre ?', options: ['5', '6', '7', '8'], correctAnswer: 2, difficulty: 'facile', points: 10 },
    { _id: 'question_geo_6_2', type: 'question', subjectId: 'subject_geographie', grade: '6ème', question: 'Quel est le plus grand océan ?', options: ['Atlantique', 'Indien', 'Pacifique', 'Arctique'], correctAnswer: 2, difficulty: 'facile', points: 10 },
    { _id: 'question_geo_6_3', type: 'question', subjectId: 'subject_geographie', grade: '6ème', question: 'Quelle est la capitale de la France ?', options: ['Paris', 'Lyon', 'Marseille', 'Bordeaux'], correctAnswer: 0, difficulty: 'facile', points: 10 },
    { _id: 'question_geo_6_4', type: 'question', subjectId: 'subject_geographie', grade: '6ème', question: 'Quel est le désert le plus étendu du monde ?', options: ['Gobi', 'Sahara', 'Kalahari', 'Atacama'], correctAnswer: 1, difficulty: 'facile', points: 10 },
    { _id: 'question_geo_6_5', type: 'question', subjectId: 'subject_geographie', grade: '6ème', question: 'Quelle chaîne de montagnes sépare la France de l\'Espagne ?', options: ['Alpes', 'Pyrénées', 'Andes', 'Rocheuses'], correctAnswer: 1, difficulty: 'facile', points: 10 },

    // Géographie – 5ème
    { _id: 'question_geo_5_1', type: 'question', subjectId: 'subject_geographie', grade: '5ème', question: 'Quel fleuve traverse Paris ?', options: ['Loire', 'Rhône', 'Seine', 'Rhin'], correctAnswer: 2, difficulty: 'moyen', points: 10 },
    { _id: 'question_geo_5_2', type: 'question', subjectId: 'subject_geographie', grade: '5ème', question: 'Qu\'est‑ce qu\'une métropole ?', options: ['Une petite ville', 'Une grande agglomération influente', 'Une île', 'Un fleuve'], correctAnswer: 1, difficulty: 'moyen', points: 10 },
    { _id: 'question_geo_5_3', type: 'question', subjectId: 'subject_geographie', grade: '5ème', question: 'Quel pays est le plus peuplé d\'Europe ?', options: ['France', 'Allemagne', 'Russie', 'Italie'], correctAnswer: 2, difficulty: 'moyen', points: 10 },
    { _id: 'question_geo_5_4', type: 'question', subjectId: 'subject_geographie', grade: '5ème', question: 'Quelle est la capitale de l\'Allemagne ?', options: ['Berlin', 'Munich', 'Hambourg', 'Francfort'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_geo_5_5', type: 'question', subjectId: 'subject_geographie', grade: '5ème', question: 'Quel relief couvre la majeure partie de la Suisse ?', options: ['Montagnes', 'Plaines', 'Déserts', 'Collines'], correctAnswer: 0, difficulty: 'moyen', points: 10 },

    // Géographie – 4ème
    { _id: 'question_geo_4_1', type: 'question', subjectId: 'subject_geographie', grade: '4ème', question: 'Qu\'est‑ce qu\'une ville mondiale ?', options: ['Une ville qui influence le monde entier', 'Une ville moyenne', 'Une capitale de province', 'Un village'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_geo_4_2', type: 'question', subjectId: 'subject_geographie', grade: '4ème', question: 'Quels pays composent les BRICS ?', options: ['Brésil, Russie, Inde, Chine et Afrique du Sud', 'États‑Unis, Canada, Allemagne, Japon', 'Argentine, Chili, Pérou, Colombie', 'Nigeria, Kenya, Égypte, Afrique du Sud'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_geo_4_3', type: 'question', subjectId: 'subject_geographie', grade: '4ème', question: 'Qu\'est‑ce que l\'urbanisation ?', options: ['L\'augmentation de la population en ville', 'La désertification', 'La pollution', 'L\'agriculture'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_geo_4_4', type: 'question', subjectId: 'subject_geographie', grade: '4ème', question: 'Quelle mer borde l\'Italie à l\'est ?', options: ['Mer Noire', 'Mer Adriatique', 'Mer Baltique', 'Mer du Nord'], correctAnswer: 1, difficulty: 'moyen', points: 10 },
    { _id: 'question_geo_4_5', type: 'question', subjectId: 'subject_geographie', grade: '4ème', question: 'Quel fleuve se jette dans la mer Méditerranée à Alexandrie ?', options: ['Nil', 'Niger', 'Congo', 'Zambèze'], correctAnswer: 0, difficulty: 'moyen', points: 10 },

    // Géographie – 3ème
    { _id: 'question_geo_3_1', type: 'question', subjectId: 'subject_geographie', grade: '3ème', question: 'Qu\'est‑ce que l\'effet de serre ?', options: ['Phénomène de réchauffement dû aux gaz dans l\'atmosphère', 'Une serre de jardin', 'Un nuage toxique', 'Une explosion solaire'], correctAnswer: 0, difficulty: 'difficile', points: 10 },
    { _id: 'question_geo_3_2', type: 'question', subjectId: 'subject_geographie', grade: '3ème', question: 'Quel gaz est principalement responsable du réchauffement climatique ?', options: ['Oxygène', 'Azote', 'Dioxyde de carbone', 'Hélium'], correctAnswer: 2, difficulty: 'difficile', points: 10 },
    { _id: 'question_geo_3_3', type: 'question', subjectId: 'subject_geographie', grade: '3ème', question: 'Quel est l\'objectif du développement durable ?', options: ['Répondre aux besoins du présent sans compromettre l\'avenir', 'Augmenter la consommation', 'Développer les armes', 'Construire des gratte‑ciel'], correctAnswer: 0, difficulty: 'difficile', points: 10 },
    { _id: 'question_geo_3_4', type: 'question', subjectId: 'subject_geographie', grade: '3ème', question: 'Quelle est la capitale du Brésil ?', options: ['Rio de Janeiro', 'São Paulo', 'Brasília', 'Salvador'], correctAnswer: 2, difficulty: 'difficile', points: 10 },
    { _id: 'question_geo_3_5', type: 'question', subjectId: 'subject_geographie', grade: '3ème', question: 'Quelle région du monde est la plus touchée par la déforestation ?', options: ['Amazonie', 'Sibérie', 'Europe', 'Antarctique'], correctAnswer: 0, difficulty: 'difficile', points: 10 },

    // Mathématiques – 6ème
    { _id: 'question_math_6_1', type: 'question', subjectId: 'subject_math', grade: '6ème', question: 'Combien font 7 + 5 ?', options: ['10', '11', '12', '13'], correctAnswer: 2, difficulty: 'facile', points: 10 },
    { _id: 'question_math_6_2', type: 'question', subjectId: 'subject_math', grade: '6ème', question: 'Quel est le périmètre d\'un carré de côté 3 cm ?', options: ['6 cm', '9 cm', '12 cm', '15 cm'], correctAnswer: 2, difficulty: 'facile', points: 10 },
    { _id: 'question_math_6_3', type: 'question', subjectId: 'subject_math', grade: '6ème', question: 'Quel est le résultat de 3 × 4 ?', options: ['6', '9', '12', '16'], correctAnswer: 2, difficulty: 'facile', points: 10 },
    { _id: 'question_math_6_4', type: 'question', subjectId: 'subject_math', grade: '6ème', question: 'Quel est le nombre opposé de 5 ?', options: ['5', '‑5', '0', '10'], correctAnswer: 1, difficulty: 'facile', points: 10 },
    { _id: 'question_math_6_5', type: 'question', subjectId: 'subject_math', grade: '6ème', question: 'Quel est le résultat de 8 ÷ 2 ?', options: ['2', '4', '6', '8'], correctAnswer: 1, difficulty: 'facile', points: 10 },
    { _id: 'question_math_6_6', type: 'question', subjectId: 'subject_math', grade: '6ème', question: 'Combien vaut 2³ ?', options: ['6', '8', '9', '12'], correctAnswer: 1, difficulty: 'facile', points: 10 },

    // Mathématiques – 5ème
    { _id: 'question_math_5_1', type: 'question', subjectId: 'subject_math', grade: '5ème', question: 'Combien font 3/4 + 1/4 ?', options: ['1/2', '1', '3/4', '2'], correctAnswer: 1, difficulty: 'moyen', points: 10 },
    { _id: 'question_math_5_2', type: 'question', subjectId: 'subject_math', grade: '5ème', question: 'Quelle est l\'aire d\'un rectangle de longueur 5 cm et largeur 2 cm ?', options: ['10 cm²', '7 cm²', '3 cm²', '12 cm²'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_math_5_3', type: 'question', subjectId: 'subject_math', grade: '5ème', question: 'Qu\'est‑ce qu\'un angle droit ?', options: ['45°', '90°', '180°', '360°'], correctAnswer: 1, difficulty: 'moyen', points: 10 },
    { _id: 'question_math_5_4', type: 'question', subjectId: 'subject_math', grade: '5ème', question: 'Quelle est l\'écriture décimale de 1/2 ?', options: ['0,5', '0,2', '0,25', '0,75'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_math_5_5', type: 'question', subjectId: 'subject_math', grade: '5ème', question: 'Quel est le périmètre d\'un cercle de rayon 1 cm ?', options: ['2π cm', 'π cm', '3 cm', '1 cm'], correctAnswer: 0, difficulty: 'moyen', points: 10 },

    // Mathématiques – 4ème
    { _id: 'question_math_4_1', type: 'question', subjectId: 'subject_math', grade: '4ème', question: 'Résoudre l\'équation 2x + 5 = 11.', options: ['2', '3', '4', '6'], correctAnswer: 1, difficulty: 'moyen', points: 10 },
    { _id: 'question_math_4_2', type: 'question', subjectId: 'subject_math', grade: '4ème', question: 'Qu\'est‑ce qu\'une racine carrée ?', options: ['Nombre dont le carré donne le nombre initial', 'Un nombre fraction', 'Un nombre négatif', 'Un exposant'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_math_4_3', type: 'question', subjectId: 'subject_math', grade: '4ème', question: 'Quelle est la formule de l\'aire d\'un disque ?', options: ['πr²', '2πr', 'πd', 'r²'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_math_4_4', type: 'question', subjectId: 'subject_math', grade: '4ème', question: 'Qu\'est‑ce qu\'une proportion ?', options: ['Égalité entre deux rapports', 'Une addition', 'Une soustraction', 'Une multiplication'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_math_4_5', type: 'question', subjectId: 'subject_math', grade: '4ème', question: 'Quel est le résultat de 9² ?', options: ['81', '18', '27', '72'], correctAnswer: 0, difficulty: 'moyen', points: 10 },

    // Mathématiques – 3ème
    { _id: 'question_math_3_1', type: 'question', subjectId: 'subject_math', grade: '3ème', question: 'Dans un triangle rectangle, que dit le théorème de Pythagore ?', options: ['La somme des carrés des côtés de l\'angle droit est égale au carré de l\'hypoténuse', 'Le produit des côtés est égal à la somme des angles', 'La somme des côtés est égale à la somme des angles', 'Le cercle circonscrit a un diamètre double'], correctAnswer: 0, difficulty: 'difficile', points: 10 },
    { _id: 'question_math_3_2', type: 'question', subjectId: 'subject_math', grade: '3ème', question: 'Quelle est la valeur de (‑3) × (‑4) ?', options: ['‑12', '12', '‑7', '7'], correctAnswer: 1, difficulty: 'difficile', points: 10 },
    { _id: 'question_math_3_3', type: 'question', subjectId: 'subject_math', grade: '3ème', question: 'Que vaut 2^4 (2 puissance 4) ?', options: ['6', '8', '12', '16'], correctAnswer: 3, difficulty: 'difficile', points: 10 },
    { _id: 'question_math_3_4', type: 'question', subjectId: 'subject_math', grade: '3ème', question: 'Qu\'est‑ce qu\'une fonction linéaire ?', options: ['Fonction de la forme f(x) = ax + b', 'Une fonction trigonométrique', 'Une équation quadratique', 'Une suite'], correctAnswer: 0, difficulty: 'difficile', points: 10 },
    { _id: 'question_math_3_5', type: 'question', subjectId: 'subject_math', grade: '3ème', question: 'Comment calcule‑t‑on le volume d\'un cylindre ?', options: ['πr²h', '2πr', '4/3πr³', '2r + h'], correctAnswer: 0, difficulty: 'difficile', points: 10 },

    // Sciences – 6ème (SVT is separate for older classes)
    { _id: 'question_sc_6_1', type: 'question', subjectId: 'subject_sciences', grade: '6ème', question: 'Quel organe pompe le sang dans le corps humain ?', options: ['Le foie', 'Le cœur', 'Le poumon', 'L\'estomac'], correctAnswer: 1, difficulty: 'facile', points: 10 },
    { _id: 'question_sc_6_2', type: 'question', subjectId: 'subject_sciences', grade: '6ème', question: 'Quel gaz respirons‑nous principalement ?', options: ['Azote', 'Oxygène', 'Dioxyde de carbone', 'Hydrogène'], correctAnswer: 1, difficulty: 'facile', points: 10 },
    { _id: 'question_sc_6_3', type: 'question', subjectId: 'subject_sciences', grade: '6ème', question: 'Quelle planète est la plus proche du Soleil ?', options: ['Vénus', 'Mars', 'Mercure', 'Terre'], correctAnswer: 2, difficulty: 'facile', points: 10 },

    // Physique‑Chimie – 5ème
    { _id: 'question_pc_5_1', type: 'question', subjectId: 'subject_physique', grade: '5ème', question: 'Quelle est la formule chimique de l\'eau ?', options: ['CO₂', 'H₂O', 'O₂', 'H₂'], correctAnswer: 1, difficulty: 'moyen', points: 10 },
    { _id: 'question_pc_5_2', type: 'question', subjectId: 'subject_physique', grade: '5ème', question: 'Comment appelle‑t‑on le passage de l\'état liquide à gazeux ?', options: ['Fusion', 'Condensation', 'Vaporisation', 'Solidification'], correctAnswer: 2, difficulty: 'moyen', points: 10 },
    { _id: 'question_pc_5_3', type: 'question', subjectId: 'subject_physique', grade: '5ème', question: 'Quel est le symbole de l\'unité de masse ?', options: ['m', 'kg', 's', 'L'], correctAnswer: 1, difficulty: 'moyen', points: 10 },
    { _id: 'question_pc_5_4', type: 'question', subjectId: 'subject_physique', grade: '5ème', question: 'Quel est l\'état de l\'eau à ‑10 °C ?', options: ['Solide', 'Liquide', 'Gazeux', 'Plasma'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_pc_5_5', type: 'question', subjectId: 'subject_physique', grade: '5ème', question: 'Quelle est la source principale d\'énergie de la Terre ?', options: ['Le Soleil', 'Le vent', 'Les volcans', 'Les marées'], correctAnswer: 0, difficulty: 'moyen', points: 10 },

    // Physique‑Chimie – 4ème
    { _id: 'question_pc_4_1', type: 'question', subjectId: 'subject_physique', grade: '4ème', question: 'Quel est l\'élément le plus abondant dans l\'univers ?', options: ['Hydrogène', 'Oxygène', 'Fer', 'Carbone'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_pc_4_2', type: 'question', subjectId: 'subject_physique', grade: '4ème', question: 'Comment appelle‑t‑on le courant électrique qui circule toujours dans le même sens ?', options: ['Courant alternatif', 'Courant continu', 'Résistance', 'Tension'], correctAnswer: 1, difficulty: 'moyen', points: 10 },
    { _id: 'question_pc_4_3', type: 'question', subjectId: 'subject_physique', grade: '4ème', question: 'Quelle est la loi d\'Ohm ?', options: ['U = R × I', 'E = mc²', 'F = ma', 'P = UI'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_pc_4_4', type: 'question', subjectId: 'subject_physique', grade: '4ème', question: 'Quel est le symbole chimique du sodium ?', options: ['S', 'So', 'Na', 'Sa'], correctAnswer: 2, difficulty: 'moyen', points: 10 },
    { _id: 'question_pc_4_5', type: 'question', subjectId: 'subject_physique', grade: '4ème', question: 'Qu\'est‑ce qu\'une molécule ?', options: ['Association d\'atomes', 'Un atome isolé', 'Un électron', 'Une particule subatomique'], correctAnswer: 0, difficulty: 'moyen', points: 10 },

    // Physique‑Chimie – 3ème
    { _id: 'question_pc_3_1', type: 'question', subjectId: 'subject_physique', grade: '3ème', question: 'Quelle est la formule chimique du dioxyde de carbone ?', options: ['CO₂', 'O₂', 'H₂O', 'CH₄'], correctAnswer: 0, difficulty: 'difficile', points: 10 },
    { _id: 'question_pc_3_2', type: 'question', subjectId: 'subject_physique', grade: '3ème', question: 'Comment calcule‑t‑on la vitesse ?', options: ['distance × temps', 'distance / temps', 'temps / distance', 'distance + temps'], correctAnswer: 1, difficulty: 'difficile', points: 10 },
    { _id: 'question_pc_3_3', type: 'question', subjectId: 'subject_physique', grade: '3ème', question: 'Qu\'est‑ce qu\'une réaction chimique exothermique ?', options: ['Réaction qui libère de la chaleur', 'Réaction qui absorbe de la chaleur', 'Réaction qui produit du froid', 'Une réaction impossible'], correctAnswer: 0, difficulty: 'difficile', points: 10 },
    { _id: 'question_pc_3_4', type: 'question', subjectId: 'subject_physique', grade: '3ème', question: 'Quel instrument mesure l\'intensité du courant ?', options: ['Volt‑mètre', 'Thermomètre', 'Ampèremètre', 'Baromètre'], correctAnswer: 2, difficulty: 'difficile', points: 10 },
    { _id: 'question_pc_3_5', type: 'question', subjectId: 'subject_physique', grade: '3ème', question: 'Quelle est la vitesse approximative de la lumière dans le vide ?', options: ['3 × 10^8 m/s', '3 × 10^6 m/s', '3 × 10^5 km/s', '3000 m/s'], correctAnswer: 0, difficulty: 'difficile', points: 10 },

    // SVT – 5ème
    { _id: 'question_svt_5_1', type: 'question', subjectId: 'subject_svt', grade: '5ème', question: 'Quel organe contrôle l\'ensemble du corps humain ?', options: ['Cœur', 'Foie', 'Cerveau', 'Estomac'], correctAnswer: 2, difficulty: 'moyen', points: 10 },
    { _id: 'question_svt_5_2', type: 'question', subjectId: 'subject_svt', grade: '5ème', question: 'Qu\'est‑ce qu\'un écosystème ?', options: ['Ensemble d\'organismes et leur environnement', 'Un seul animal', 'Une plante', 'Un minéral'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_svt_5_3', type: 'question', subjectId: 'subject_svt', grade: '5ème', question: 'Quel est le rôle des racines d\'une plante ?', options: ['Absorber l\'eau et les nutriments', 'Effectuer la photosynthèse', 'Protéger des prédateurs', 'Produire des fruits'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_svt_5_4', type: 'question', subjectId: 'subject_svt', grade: '5ème', question: 'Qu\'est‑ce que la chaîne alimentaire ?', options: ['Succession de niveaux trophiques', 'Une liste d\'aliments', 'Un régime alimentaire', 'La digestion'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_svt_5_5', type: 'question', subjectId: 'subject_svt', grade: '5ème', question: 'Quel est le principal gaz produit par la respiration ?', options: ['O₂', 'N₂', 'CO₂', 'H₂'], correctAnswer: 2, difficulty: 'moyen', points: 10 },

    // SVT – 4ème
    { _id: 'question_svt_4_1', type: 'question', subjectId: 'subject_svt', grade: '4ème', question: 'Comment s\'appelle l\'union de l\'ovule et du spermatozoïde ?', options: ['Fécondation', 'Germination', 'Photosynthèse', 'Métamorphose'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_svt_4_2', type: 'question', subjectId: 'subject_svt', grade: '4ème', question: 'Qu\'est‑ce qu\'une cellule ?', options: ['Unité de base du vivant', 'Un organe', 'Un microbe', 'Une particule chimique'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_svt_4_3', type: 'question', subjectId: 'subject_svt', grade: '4ème', question: 'Qu\'est‑ce que la biodiversité ?', options: ['Diversité des espèces vivantes', 'Une base de données', 'Un animal', 'Une zone protégée'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_svt_4_4', type: 'question', subjectId: 'subject_svt', grade: '4ème', question: 'Quel organe assure la circulation du sang ?', options: ['Cerveau', 'Cœur', 'Poumons', 'Foie'], correctAnswer: 1, difficulty: 'moyen', points: 10 },
    { _id: 'question_svt_4_5', type: 'question', subjectId: 'subject_svt', grade: '4ème', question: 'Comment appelle‑t‑on la transformation d\'une chenille en papillon ?', options: ['Métamorphose', 'Germination', 'Photosynthèse', 'Division'], correctAnswer: 0, difficulty: 'moyen', points: 10 },

    // SVT – 3ème
    { _id: 'question_svt_3_1', type: 'question', subjectId: 'subject_svt', grade: '3ème', question: 'Qu\'est‑ce qu\'un gène ?', options: ['Unité d\'information génétique', 'Un virus', 'Un organe', 'Un minéral'], correctAnswer: 0, difficulty: 'difficile', points: 10 },
    { _id: 'question_svt_3_2', type: 'question', subjectId: 'subject_svt', grade: '3ème', question: 'Comment appelle‑t‑on la division cellulaire qui produit deux cellules identiques ?', options: ['Meiose', 'Mitose', 'Fusion', 'Clonage'], correctAnswer: 1, difficulty: 'difficile', points: 10 },
    { _id: 'question_svt_3_3', type: 'question', subjectId: 'subject_svt', grade: '3ème', question: 'Quel gaz rejettent les plantes lors de la photosynthèse ?', options: ['Oxygène', 'Dioxyde de carbone', 'Azote', 'Méthane'], correctAnswer: 0, difficulty: 'difficile', points: 10 },
    { _id: 'question_svt_3_4', type: 'question', subjectId: 'subject_svt', grade: '3ème', question: 'Qu\'est‑ce qu\'une mutation ?', options: ['Modification de l\'ADN', 'Une respiration', 'Un mouvement musculaire', 'Une réaction chimique'], correctAnswer: 0, difficulty: 'difficile', points: 10 },
    { _id: 'question_svt_3_5', type: 'question', subjectId: 'subject_svt', grade: '3ème', question: 'Qu\'est‑ce qu\'un chromosome ?', options: ['Structure contenant de l\'ADN', 'Une cellule', 'Un noyau', 'Un virus'], correctAnswer: 0, difficulty: 'difficile', points: 10 },

    // Technologie – 5ème
    { _id: 'question_tech_5_1', type: 'question', subjectId: 'subject_technologie', grade: '5ème', question: 'Qu\'est‑ce qu\'un algorithme ?', options: ['Suite d\'instructions pour résoudre un problème', 'Une machine', 'Un programme d\'ordinateur', 'Un bug'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_tech_5_2', type: 'question', subjectId: 'subject_technologie', grade: '5ème', question: 'Quel composant est le cerveau d\'un ordinateur ?', options: ['Disque dur', 'Carte graphique', 'Processeur', 'Écran'], correctAnswer: 2, difficulty: 'moyen', points: 10 },
    { _id: 'question_tech_5_3', type: 'question', subjectId: 'subject_technologie', grade: '5ème', question: 'Qu\'est‑ce qu\'une imprimante 3D ?', options: ['Une machine qui imprime en relief des objets', 'Une imprimante à jet d\'encre', 'Un scanner 3D', 'Un programme'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_tech_5_4', type: 'question', subjectId: 'subject_technologie', grade: '5ème', question: 'Quel langage est principalement utilisé pour créer des pages web ?', options: ['Java', 'Python', 'HTML', 'C++'], correctAnswer: 2, difficulty: 'moyen', points: 10 },
    { _id: 'question_tech_5_5', type: 'question', subjectId: 'subject_technologie', grade: '5ème', question: 'Qu\'est‑ce que la robotique ?', options: ['Science des robots', 'Étude des étoiles', 'Une matière littéraire', 'Un sport'], correctAnswer: 0, difficulty: 'moyen', points: 10 },

    // Technologie – 4ème
    { _id: 'question_tech_4_1', type: 'question', subjectId: 'subject_technologie', grade: '4ème', question: 'Qu\'est‑ce qu\'un réseau informatique ?', options: ['Ensemble d\'ordinateurs connectés', 'Un site internet', 'Un jeu vidéo', 'Une clé USB'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_tech_4_2', type: 'question', subjectId: 'subject_technologie', grade: '4ème', question: 'Citer un composant d\'une carte électronique :', options: ['Résistance', 'Papier', 'Verre', 'Bois'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_tech_4_3', type: 'question', subjectId: 'subject_technologie', grade: '4ème', question: 'Qu\'est‑ce qu\'une base de données ?', options: ['Ensemble structuré d\'informations', 'Un tableau', 'Un algorithme', 'Un moteur de recherche'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_tech_4_4', type: 'question', subjectId: 'subject_technologie', grade: '4ème', question: 'Quel est le rôle d\'un système d\'exploitation ?', options: ['Gérer les ressources matérielles', 'Prendre des photos', 'Éditer des vidéos', 'Laver la vaisselle'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_tech_4_5', type: 'question', subjectId: 'subject_technologie', grade: '4ème', question: 'Qu\'est‑ce qu\'une boucle dans un programme ?', options: ['Une répétition d\'instructions', 'Une condition', 'Une variable', 'Un commentaire'], correctAnswer: 0, difficulty: 'moyen', points: 10 },

    // Technologie – 3ème
    { _id: 'question_tech_3_1', type: 'question', subjectId: 'subject_technologie', grade: '3ème', question: 'Qu\'est‑ce que l\'intelligence artificielle ?', options: ['Discipline qui crée des programmes capables d\'imiter l\'intelligence humaine', 'Une intelligence extraterrestre', 'Une application de messagerie', 'Une console de jeux'], correctAnswer: 0, difficulty: 'difficile', points: 10 },
    { _id: 'question_tech_3_2', type: 'question', subjectId: 'subject_technologie', grade: '3ème', question: 'Quel est l\'objectif du prototypage ?', options: ['Tester et améliorer un concept', 'Finir un produit final', 'Mettre en production', 'Vendre un produit'], correctAnswer: 0, difficulty: 'difficile', points: 10 },
    { _id: 'question_tech_3_3', type: 'question', subjectId: 'subject_technologie', grade: '3ème', question: 'Qu\'est‑ce qu\'un circuit imprimé ?', options: ['Plaque supportant les composants électroniques', 'Un écran', 'Une imprimante', 'Une batterie'], correctAnswer: 0, difficulty: 'difficile', points: 10 },
    { _id: 'question_tech_3_4', type: 'question', subjectId: 'subject_technologie', grade: '3ème', question: 'Qu\'est‑ce que le codage binaire ?', options: ['Représentation de l\'information avec 0 et 1', 'Une langue de programmation', 'Un jeu', 'Un bug'], correctAnswer: 0, difficulty: 'difficile', points: 10 },
    { _id: 'question_tech_3_5', type: 'question', subjectId: 'subject_technologie', grade: '3ème', question: 'Qui est Tim Berners‑Lee ?', options: ['Inventeur du World Wide Web', 'Créateur de Facebook', 'Acteur', 'Chanteur'], correctAnswer: 0, difficulty: 'difficile', points: 10 },

    // EPS – 6ème
    { _id: 'question_eps_6_1', type: 'question', subjectId: 'subject_eps', grade: '6ème', question: 'Combien de minutes par jour faut‑il pratiquer une activité physique ?', options: ['10', '30', '60', '120'], correctAnswer: 1, difficulty: 'facile', points: 10 },
    { _id: 'question_eps_6_2', type: 'question', subjectId: 'subject_eps', grade: '6ème', question: 'Quel muscle est sollicité lors des flexions des jambes (squats) ?', options: ['Biceps', 'Quadriceps', 'Triceps', 'Abdominaux'], correctAnswer: 1, difficulty: 'facile', points: 10 },
    { _id: 'question_eps_6_3', type: 'question', subjectId: 'subject_eps', grade: '6ème', question: 'Quelle est la différence entre vitesse et endurance ?', options: ['La vitesse est la capacité à se déplacer rapidement sur une courte distance, l\'endurance est la capacité à maintenir un effort dans la durée', 'La vitesse est la capacité à maintenir un effort, l\'endurance est la rapidité', 'Ce sont la même chose', 'L\'endurance est la force'], correctAnswer: 0, difficulty: 'facile', points: 10 },
    { _id: 'question_eps_6_4', type: 'question', subjectId: 'subject_eps', grade: '6ème', question: 'Quel sport se pratique avec un ballon ovale ?', options: ['Rugby', 'Football', 'Basket‑ball', 'Handball'], correctAnswer: 0, difficulty: 'facile', points: 10 },
    { _id: 'question_eps_6_5', type: 'question', subjectId: 'subject_eps', grade: '6ème', question: 'Quel est l\'objectif principal de l\'étirement après l\'exercice ?', options: ['Améliorer la vitesse', 'Éviter les blessures et réduire les courbatures', 'Augmenter la masse musculaire', 'Gagner du poids'], correctAnswer: 1, difficulty: 'facile', points: 10 },

    // EPS – 5ème
    { _id: 'question_eps_5_1', type: 'question', subjectId: 'subject_eps', grade: '5ème', question: 'Combien de joueurs dans une équipe de basket ?', options: ['5', '6', '7', '11'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_eps_5_2', type: 'question', subjectId: 'subject_eps', grade: '5ème', question: 'Quelle qualité développe le saut en longueur ?', options: ['Endurance', 'Force', 'Puissance et détente', 'Souplesse'], correctAnswer: 2, difficulty: 'moyen', points: 10 },
    { _id: 'question_eps_5_3', type: 'question', subjectId: 'subject_eps', grade: '5ème', question: 'Quel sport utilise une raquette et un volant ?', options: ['Badminton', 'Tennis', 'Tennis de table', 'Squash'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_eps_5_4', type: 'question', subjectId: 'subject_eps', grade: '5ème', question: 'À quel sport correspond la Coupe du monde FIFA ?', options: ['Football', 'Rugby', 'Basket', 'Athlétisme'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_eps_5_5', type: 'question', subjectId: 'subject_eps', grade: '5ème', question: 'Qu\'est‑ce qu\'un marathon ?', options: ['Course de 42,195 km', 'Course de 100 m', 'Match de football', 'Discours'], correctAnswer: 0, difficulty: 'moyen', points: 10 },

    // EPS – 4ème
    { _id: 'question_eps_4_1', type: 'question', subjectId: 'subject_eps', grade: '4ème', question: 'Quel est le rôle de l\'échauffement ?', options: ['Préparer muscles et articulations à l\'effort', 'Fatiguer le corps', 'Gagner un match', 'Dormir'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_eps_4_2', type: 'question', subjectId: 'subject_eps', grade: '4ème', question: 'Combien de joueurs dans une équipe de handball ?', options: ['5', '7', '9', '11'], correctAnswer: 1, difficulty: 'moyen', points: 10 },
    { _id: 'question_eps_4_3', type: 'question', subjectId: 'subject_eps', grade: '4ème', question: 'Quelle est la technique de respiration lors de la course d\'endurance ?', options: ['Respiration régulière et profonde', 'Retenir son souffle', 'Souffler fort uniquement', 'Respirer par la bouche seulement'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_eps_4_4', type: 'question', subjectId: 'subject_eps', grade: '4ème', question: 'Quel appareil mesure le rythme cardiaque ?', options: ['Thermomètre', 'Baromètre', 'Cardiofréquencemètre', 'Altimètre'], correctAnswer: 2, difficulty: 'moyen', points: 10 },
    { _id: 'question_eps_4_5', type: 'question', subjectId: 'subject_eps', grade: '4ème', question: 'Quel sport est une discipline olympique ?', options: ['Escrime', 'Course de sacs', 'Corde à sauter', 'Cerf‑volant'], correctAnswer: 0, difficulty: 'moyen', points: 10 },

    // EPS – 3ème
    { _id: 'question_eps_3_1', type: 'question', subjectId: 'subject_eps', grade: '3ème', question: 'Combien de temps dure un match de football officiel ?', options: ['60', '90', '120', '45'], correctAnswer: 1, difficulty: 'difficile', points: 10 },
    { _id: 'question_eps_3_2', type: 'question', subjectId: 'subject_eps', grade: '3ème', question: 'Quel est l\'objectif de l\'entraînement en fractionné ?', options: ['Améliorer l\'endurance et la vitesse', 'Apprendre à nager', 'Renforcer les poignets', 'Faire un dessin'], correctAnswer: 0, difficulty: 'difficile', points: 10 },
    { _id: 'question_eps_3_3', type: 'question', subjectId: 'subject_eps', grade: '3ème', question: 'Quelle est la différence entre souplesse et force ?', options: ['La souplesse est la capacité à réaliser de grands mouvements, la force est la capacité à exercer une tension', 'La souplesse est la force', 'La force est l\'endurance', 'Aucune'], correctAnswer: 0, difficulty: 'difficile', points: 10 },
    { _id: 'question_eps_3_4', type: 'question', subjectId: 'subject_eps', grade: '3ème', question: 'Quel sport est pratiqué avec une pagaie sur une planche ?', options: ['Surf', 'Paddle', 'Aviron', 'Volley'], correctAnswer: 1, difficulty: 'difficile', points: 10 },
    { _id: 'question_eps_3_5', type: 'question', subjectId: 'subject_eps', grade: '3ème', question: 'Quel type d\'entraînement combine exercices de cardio et de musculation dans un temps limité ?', options: ['Yoga', 'CrossFit', 'Relaxation', 'Pilates'], correctAnswer: 1, difficulty: 'difficile', points: 10 },

    // Arts plastiques – 6ème
    { _id: 'question_art_6_1', type: 'question', subjectId: 'subject_art', grade: '6ème', question: 'Quel est l\'outil principal pour dessiner au crayon ?', options: ['Crayon', 'Pinceau', 'Feutre', 'Stylo'], correctAnswer: 0, difficulty: 'facile', points: 10 },
    { _id: 'question_art_6_2', type: 'question', subjectId: 'subject_art', grade: '6ème', question: 'Qu\'est‑ce qu\'un autoportrait ?', options: ['Un portrait de soi‑même', 'Un paysage', 'Une peinture de fleurs', 'Un dessin d\'un animal'], correctAnswer: 0, difficulty: 'facile', points: 10 },
    { _id: 'question_art_6_3', type: 'question', subjectId: 'subject_art', grade: '6ème', question: 'Quelle couleur obtient‑on en mélangeant du bleu et du jaune ?', options: ['Rouge', 'Vert', 'Orange', 'Violet'], correctAnswer: 1, difficulty: 'facile', points: 10 },
    { _id: 'question_art_6_4', type: 'question', subjectId: 'subject_art', grade: '6ème', question: 'Qu\'est‑ce qu\'une nature morte ?', options: ['Peinture représentant des objets inanimés', 'Peinture de scène vivante', 'Sculpture en marbre', 'Photographie'], correctAnswer: 0, difficulty: 'facile', points: 10 },
    { _id: 'question_art_6_5', type: 'question', subjectId: 'subject_art', grade: '6ème', question: 'Quelle technique consiste à découper et assembler des éléments ?', options: ['Collage', 'Fresque', 'Sculpture', 'Gravure'], correctAnswer: 0, difficulty: 'facile', points: 10 },

    // Arts plastiques – 5ème
    { _id: 'question_art_5_1', type: 'question', subjectId: 'subject_art', grade: '5ème', question: 'Qu\'est‑ce qu\'une perspective en dessin ?', options: ['Représentation de la profondeur sur une surface plane', 'Technique de collage', 'Type de sculpture', 'Peinture abstraite'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_art_5_2', type: 'question', subjectId: 'subject_art', grade: '5ème', question: 'Quel artiste a peint la Joconde ?', options: ['Vincent van Gogh', 'Pablo Picasso', 'Léonard de Vinci', 'Claude Monet'], correctAnswer: 2, difficulty: 'moyen', points: 10 },
    { _id: 'question_art_5_3', type: 'question', subjectId: 'subject_art', grade: '5ème', question: 'Qu\'est‑ce qu\'un collage ?', options: ['Assemblage d\'éléments collés', 'Technique de peinture à l\'eau', 'Sculpture en pierre', 'Dessin en relief'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_art_5_4', type: 'question', subjectId: 'subject_art', grade: '5ème', question: 'Quel mouvement artistique utilise des touches de couleur juxtaposées ?', options: ['Impressionnisme', 'Cubisme', 'Surréalisme', 'Fauvisme'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_art_5_5', type: 'question', subjectId: 'subject_art', grade: '5ème', question: 'Quelle technique de peinture utilise des pigments mélangés à de l\'eau sur du plâtre frais ?', options: ['Fresque', 'Gouache', 'Aquarelle', 'Tempera'], correctAnswer: 0, difficulty: 'moyen', points: 10 },

    // Arts plastiques – 4ème
    { _id: 'question_art_4_1', type: 'question', subjectId: 'subject_art', grade: '4ème', question: 'Qu\'est‑ce que le cubisme ?', options: ['Mouvement artistique qui représente les formes géométriquement', 'Une technique de gravure', 'Un style baroque', 'Un style gothique'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_art_4_2', type: 'question', subjectId: 'subject_art', grade: '4ème', question: 'Quel outil est utilisé pour sculpter le bois ?', options: ['Ciseau à bois', 'Pinceau', 'Stylo', 'Crayon'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_art_4_3', type: 'question', subjectId: 'subject_art', grade: '4ème', question: 'Qu\'est‑ce qu\'une aquarelle ?', options: ['Peinture diluée à l\'eau', 'Sculpture', 'Collage', 'Crayon'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_art_4_4', type: 'question', subjectId: 'subject_art', grade: '4ème', question: 'Qui est l\'artiste espagnol connu pour sa période bleue et rose ?', options: ['Salvador Dalí', 'Pablo Picasso', 'Diego Velázquez', 'Joan Miró'], correctAnswer: 1, difficulty: 'moyen', points: 10 },
    { _id: 'question_art_4_5', type: 'question', subjectId: 'subject_art', grade: '4ème', question: 'Quelle est la technique de peinture qui utilise des points de couleur pure ?', options: ['Pointillisme', 'Surréalisme', 'Cubisme', 'Expressionnisme'], correctAnswer: 0, difficulty: 'moyen', points: 10 },

    // Arts plastiques – 3ème
    { _id: 'question_art_3_1', type: 'question', subjectId: 'subject_art', grade: '3ème', question: 'Qu\'est‑ce qu\'un trompe‑l\'œil ?', options: ['Technique artistique créant une illusion réaliste', 'Sculpture en bronze', 'Danse traditionnelle', 'Style de musique'], correctAnswer: 0, difficulty: 'difficile', points: 10 },
    { _id: 'question_art_3_2', type: 'question', subjectId: 'subject_art', grade: '3ème', question: 'Quel mouvement artistique des années 1960 utilise des images de la culture populaire ?', options: ['Pop art', 'Baroque', 'Renaissance', 'Impressionnisme'], correctAnswer: 0, difficulty: 'difficile', points: 10 },
    { _id: 'question_art_3_3', type: 'question', subjectId: 'subject_art', grade: '3ème', question: 'Qu\'est‑ce qu\'une installation artistique ?', options: ['Œuvre d\'art aménagée dans un espace', 'Peinture sur toile', 'Musique', 'Danse'], correctAnswer: 0, difficulty: 'difficile', points: 10 },
    { _id: 'question_art_3_4', type: 'question', subjectId: 'subject_art', grade: '3ème', question: 'Qui est le peintre des « Nymphéas » ?', options: ['Claude Monet', 'Paul Cézanne', 'Édouard Manet', 'Henri Matisse'], correctAnswer: 0, difficulty: 'difficile', points: 10 },
    { _id: 'question_art_3_5', type: 'question', subjectId: 'subject_art', grade: '3ème', question: 'Qu\'est‑ce que l\'expressionnisme ?', options: ['Mouvement artistique privilégiant l\'expression des sentiments', 'Une technique de mosaïque', 'Un style de sculpture', 'Un rythme musical'], correctAnswer: 0, difficulty: 'difficile', points: 10 },

    // Musique – 6ème
    { _id: 'question_music_6_1', type: 'question', subjectId: 'subject_musique', grade: '6ème', question: 'Combien y a‑t‑il de notes dans la gamme diatonique ?', options: ['5', '6', '7', '8'], correctAnswer: 2, difficulty: 'facile', points: 10 },
    { _id: 'question_music_6_2', type: 'question', subjectId: 'subject_musique', grade: '6ème', question: 'Quel instrument est à cordes frottées ?', options: ['Piano', 'Violon', 'Flûte', 'Trompette'], correctAnswer: 1, difficulty: 'facile', points: 10 },
    { _id: 'question_music_6_3', type: 'question', subjectId: 'subject_musique', grade: '6ème', question: 'Qu\'est‑ce qu\'un tempo ?', options: ['Hauteur d\'une note', 'Vitesse d\'une musique', 'Intensité du son', 'Instrument de percussion'], correctAnswer: 1, difficulty: 'facile', points: 10 },
    { _id: 'question_music_6_4', type: 'question', subjectId: 'subject_musique', grade: '6ème', question: 'Quel est l\'instrument de percussion composé de peaux tendues ?', options: ['Guitare', 'Tambour', 'Clarinette', 'Harpe'], correctAnswer: 1, difficulty: 'facile', points: 10 },
    { _id: 'question_music_6_5', type: 'question', subjectId: 'subject_musique', grade: '6ème', question: 'Quel est le symbole qui indique la durée d\'une note ?', options: ['Clé de sol', 'Barre de mesure', 'Figure de note', 'Accord'], correctAnswer: 2, difficulty: 'facile', points: 10 },

    // Musique – 5ème
    { _id: 'question_music_5_1', type: 'question', subjectId: 'subject_musique', grade: '5ème', question: 'Quel compositeur a écrit « La Flûte enchantée » ?', options: ['Wolfgang Amadeus Mozart', 'Ludwig van Beethoven', 'Johann Sebastian Bach', 'Joseph Haydn'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_music_5_2', type: 'question', subjectId: 'subject_musique', grade: '5ème', question: 'Qu\'est‑ce qu\'un refrain ?', options: ['Partie d\'une chanson qui se répète', 'Instrument à cordes', 'Sorte de danse', 'Style de musique'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_music_5_3', type: 'question', subjectId: 'subject_musique', grade: '5ème', question: 'Quel instrument à vent est composé d\'un bec et d\'anches ?', options: ['Clarinette', 'Trompette', 'Violon', 'Piano'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_music_5_4', type: 'question', subjectId: 'subject_musique', grade: '5ème', question: 'Quel musicien est surnommé « Le Roi de la pop » ?', options: ['Michael Jackson', 'Elvis Presley', 'Prince', 'Justin Bieber'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_music_5_5', type: 'question', subjectId: 'subject_musique', grade: '5ème', question: 'Qu\'est‑ce qu\'une partition ?', options: ['Une feuille de musique contenant les notes', 'Un instrument', 'Une scène de théâtre', 'Un micro'], correctAnswer: 0, difficulty: 'moyen', points: 10 },

    // Musique – 4ème
    { _id: 'question_music_4_1', type: 'question', subjectId: 'subject_musique', grade: '4ème', question: 'Quel est le nombre de cordes d\'une guitare classique ?', options: ['4', '5', '6', '7'], correctAnswer: 2, difficulty: 'moyen', points: 10 },
    { _id: 'question_music_4_2', type: 'question', subjectId: 'subject_musique', grade: '4ème', question: 'Qu\'est‑ce qu\'un orchestre symphonique ?', options: ['Un ensemble de musiciens jouant différentes familles d\'instruments', 'Un duo de guitares', 'Un groupe de rock', 'Un chœur d\'enfants'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_music_4_3', type: 'question', subjectId: 'subject_musique', grade: '4ème', question: 'Qui est l\'auteur du « Boléro » ?', options: ['Claude Debussy', 'Maurice Ravel', 'Gabriel Fauré', 'Erik Satie'], correctAnswer: 1, difficulty: 'moyen', points: 10 },
    { _id: 'question_music_4_4', type: 'question', subjectId: 'subject_musique', grade: '4ème', question: 'Qu\'est‑ce qu\'une clé de sol ?', options: ['Symbole indiquant l\'emplacement des notes sur la portée', 'Un instrument de musique', 'Un style musical', 'Un refrain'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_music_4_5', type: 'question', subjectId: 'subject_musique', grade: '4ème', question: 'Quel instrument à vent est en métal et utilise des pistons ?', options: ['Trombone', 'Trompette', 'Clarinette', 'Flûte'], correctAnswer: 1, difficulty: 'moyen', points: 10 },

    // Musique – 3ème
    { _id: 'question_music_3_1', type: 'question', subjectId: 'subject_musique', grade: '3ème', question: 'Qu\'est‑ce que le jazz ?', options: ['Style musical né à la Nouvelle‑Orléans', 'Une danse classique', 'Un instrument à cordes', 'Une forme de peinture'], correctAnswer: 0, difficulty: 'difficile', points: 10 },
    { _id: 'question_music_3_2', type: 'question', subjectId: 'subject_musique', grade: '3ème', question: 'Quel mouvement musical a émergé à New York dans les années 1970‑80 et inclut le rap et le breakdance ?', options: ['Hip‑hop', 'Punk', 'Disco', 'Country'], correctAnswer: 0, difficulty: 'difficile', points: 10 },
    { _id: 'question_music_3_3', type: 'question', subjectId: 'subject_musique', grade: '3ème', question: 'Quel instrument est emblématique du blues ?', options: ['Harmonica', 'Piano', 'Harpe', 'Violon'], correctAnswer: 0, difficulty: 'difficile', points: 10 },
    { _id: 'question_music_3_4', type: 'question', subjectId: 'subject_musique', grade: '3ème', question: 'Quel compositeur est connu pour ses symphonies « Pathétique » et « Manfred » ?', options: ['Tchaïkovski', 'Mozart', 'Beethoven', 'Chopin'], correctAnswer: 0, difficulty: 'difficile', points: 10 },
    { _id: 'question_music_3_5', type: 'question', subjectId: 'subject_musique', grade: '3ème', question: 'Qu\'est‑ce qu\'un métronome ?', options: ['Appareil qui indique la cadence', 'Instrument à vent', 'Type de guitare', 'Instrument à percussion'], correctAnswer: 0, difficulty: 'difficile', points: 10 },

    // Italien – 6ème
    { _id: 'question_it_6_1', type: 'question', subjectId: 'subject_italien', grade: '6ème', question: 'Comment dit‑on « Bonjour » en italien ?', options: ['Hola', 'Bonjour', 'Ciao', 'Hello'], correctAnswer: 2, difficulty: 'facile', points: 10 },
    { _id: 'question_it_6_2', type: 'question', subjectId: 'subject_italien', grade: '6ème', question: 'Quelle est la capitale de l\'Italie ?', options: ['Milan', 'Rome', 'Naples', 'Florence'], correctAnswer: 1, difficulty: 'facile', points: 10 },
    { _id: 'question_it_6_3', type: 'question', subjectId: 'subject_italien', grade: '6ème', question: 'Quel est le mot italien pour « merci » ?', options: ['Grazie', 'Prego', 'Ciao', 'Arrivederci'], correctAnswer: 0, difficulty: 'facile', points: 10 },
    { _id: 'question_it_6_4', type: 'question', subjectId: 'subject_italien', grade: '6ème', question: 'Comment dit‑on « au revoir » en italien ?', options: ['Arrivederci', 'Adiós', 'Goodbye', 'Salut'], correctAnswer: 0, difficulty: 'facile', points: 10 },
    { _id: 'question_it_6_5', type: 'question', subjectId: 'subject_italien', grade: '6ème', question: 'Quel chiffre correspond à « tre » en italien ?', options: ['un', 'deux', 'trois', 'quatre'], correctAnswer: 2, difficulty: 'facile', points: 10 },

    // Italien – 5ème
    { _id: 'question_it_5_1', type: 'question', subjectId: 'subject_italien', grade: '5ème', question: 'Quel est l\'article défini masculin singulier en italien ?', options: ['il', 'la', 'i', 'gli'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_it_5_2', type: 'question', subjectId: 'subject_italien', grade: '5ème', question: 'Comment conjugue‑t‑on « essere » à la première personne du singulier ?', options: ['sei', 'sono', 'è', 'siamo'], correctAnswer: 1, difficulty: 'moyen', points: 10 },
    { _id: 'question_it_5_3', type: 'question', subjectId: 'subject_italien', grade: '5ème', question: 'Quel fruit est appelé « mela » en italien ?', options: ['orange', 'pomme', 'poire', 'banane'], correctAnswer: 1, difficulty: 'moyen', points: 10 },
    { _id: 'question_it_5_4', type: 'question', subjectId: 'subject_italien', grade: '5ème', question: 'Quel est le mot italien pour « pain » ?', options: ['pane', 'pasta', 'carne', 'pesce'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_it_5_5', type: 'question', subjectId: 'subject_italien', grade: '5ème', question: 'Comment dit‑on « bonsoir » en italien ?', options: ['buongiorno', 'buonasera', 'buonanotte', 'grazie'], correctAnswer: 1, difficulty: 'moyen', points: 10 },

    // Italien – 4ème
    { _id: 'question_it_4_1', type: 'question', subjectId: 'subject_italien', grade: '4ème', question: 'Comment dit‑on « j\'aime » en italien ?', options: ['mi piace', 'ti piace', 'gli piace', 'ci piace'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_it_4_2', type: 'question', subjectId: 'subject_italien', grade: '4ème', question: 'Quel est l\'équivalent italien de « nous » ?', options: ['voi', 'loro', 'noi', 'tu'], correctAnswer: 2, difficulty: 'moyen', points: 10 },
    { _id: 'question_it_4_3', type: 'question', subjectId: 'subject_italien', grade: '4ème', question: 'Quel est le participe passé du verbe « andare » ?', options: ['andato', 'andata', 'andiamo', 'andate'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_it_4_4', type: 'question', subjectId: 'subject_italien', grade: '4ème', question: 'Comment dit‑on « livre » en italien ?', options: ['libro', 'penna', 'tavolo', 'finestra'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_it_4_5', type: 'question', subjectId: 'subject_italien', grade: '4ème', question: 'Quel est le mot italien pour « fille » ?', options: ['ragazzo', 'ragazza', 'uomo', 'donna'], correctAnswer: 1, difficulty: 'moyen', points: 10 },

    // Italien – 3ème
    { _id: 'question_it_3_1', type: 'question', subjectId: 'subject_italien', grade: '3ème', question: 'Quelle région italienne est connue pour la pizza ?', options: ['Toscane', 'Lombardie', 'Sicile', 'Campanie'], correctAnswer: 3, difficulty: 'difficile', points: 10 },
    { _id: 'question_it_3_2', type: 'question', subjectId: 'subject_italien', grade: '3ème', question: 'Qui est le compositeur de l\'opéra « La Traviata » ?', options: ['Giacomo Puccini', 'Giuseppe Verdi', 'Gioachino Rossini', 'Antonio Vivaldi'], correctAnswer: 1, difficulty: 'difficile', points: 10 },
    { _id: 'question_it_3_3', type: 'question', subjectId: 'subject_italien', grade: '3ème', question: 'Que signifie « arrivederci » ?', options: ['Au revoir', 'Merci', 'Bonjour', 'S\'il vous plaît'], correctAnswer: 0, difficulty: 'difficile', points: 10 },
    { _id: 'question_it_3_4', type: 'question', subjectId: 'subject_italien', grade: '3ème', question: 'Comment dit‑on « je voudrais » en italien ?', options: ['vorrei', 'voglio', 'vorrai', 'vorrete'], correctAnswer: 0, difficulty: 'difficile', points: 10 },
    { _id: 'question_it_3_5', type: 'question', subjectId: 'subject_italien', grade: '3ème', question: 'Quel est le mot italien pour « vélo » ?', options: ['macchina', 'treno', 'bicicletta', 'motocicletta'], correctAnswer: 2, difficulty: 'difficile', points: 10 },

    // Espagnol – 5ème
    { _id: 'question_es_5_1', type: 'question', subjectId: 'subject_espagnol', grade: '5ème', question: 'Comment dit‑on « bonjour » en espagnol ?', options: ['Hola', 'Bonjour', 'Hello', 'Ciao'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_es_5_2', type: 'question', subjectId: 'subject_espagnol', grade: '5ème', question: 'Quel est le mot espagnol pour « chat » ?', options: ['perro', 'caballo', 'gato', 'vaca'], correctAnswer: 2, difficulty: 'moyen', points: 10 },
    { _id: 'question_es_5_3', type: 'question', subjectId: 'subject_espagnol', grade: '5ème', question: 'Quelle est la capitale de l\'Espagne ?', options: ['Barcelone', 'Madrid', 'Séville', 'Valence'], correctAnswer: 1, difficulty: 'moyen', points: 10 },
    { _id: 'question_es_5_4', type: 'question', subjectId: 'subject_espagnol', grade: '5ème', question: 'Comment dit‑on « merci » en espagnol ?', options: ['gracias', 'hola', 'adiós', 'por favor'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_es_5_5', type: 'question', subjectId: 'subject_espagnol', grade: '5ème', question: 'Quel est l\'article défini féminin singulier en espagnol ?', options: ['el', 'la', 'los', 'las'], correctAnswer: 1, difficulty: 'moyen', points: 10 },

    // Espagnol – 4ème
    { _id: 'question_es_4_1', type: 'question', subjectId: 'subject_espagnol', grade: '4ème', question: 'Quelle est la conjugaison de « ser » à la 3ème personne du singulier ?', options: ['eres', 'es', 'somos', 'sois'], correctAnswer: 1, difficulty: 'moyen', points: 10 },
    { _id: 'question_es_4_2', type: 'question', subjectId: 'subject_espagnol', grade: '4ème', question: 'Comment dit‑on « merci beaucoup » en espagnol ?', options: ['muchas gracias', 'muy gracias', 'gracias mucho', 'gracias muy'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_es_4_3', type: 'question', subjectId: 'subject_espagnol', grade: '4ème', question: 'Quel est l\'article défini pluriel féminin ?', options: ['los', 'las', 'la', 'el'], correctAnswer: 1, difficulty: 'moyen', points: 10 },
    { _id: 'question_es_4_4', type: 'question', subjectId: 'subject_espagnol', grade: '4ème', question: 'Comment dit‑on « j\'aime » en espagnol ?', options: ['me gusta', 'te gusta', 'nos gusta', 'les gusta'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_es_4_5', type: 'question', subjectId: 'subject_espagnol', grade: '4ème', question: 'Quel pays hispanophone d\'Amérique du Sud a pour capitale Lima ?', options: ['Chili', 'Pérou', 'Colombie', 'Uruguay'], correctAnswer: 1, difficulty: 'moyen', points: 10 },

    // Espagnol – 3ème
    { _id: 'question_es_3_1', type: 'question', subjectId: 'subject_espagnol', grade: '3ème', question: 'Comment demande‑t‑on « Où est la bibliothèque ? » en espagnol ?', options: ['¿Dónde está la biblioteca?', '¿Dónde es la biblioteca?', '¿Dónde estan la biblioteca?', '¿Dónde esta el biblioteca?'], correctAnswer: 0, difficulty: 'difficile', points: 10 },
    { _id: 'question_es_3_2', type: 'question', subjectId: 'subject_espagnol', grade: '3ème', question: 'Qu\'est‑ce que la paella ?', options: ['Plat traditionnel espagnol', 'Instrument de musique', 'Danse', 'Ville'], correctAnswer: 0, difficulty: 'difficile', points: 10 },
    { _id: 'question_es_3_3', type: 'question', subjectId: 'subject_espagnol', grade: '3ème', question: 'Qui a peint « Guernica » ?', options: ['Salvador Dalí', 'Diego Rivera', 'Pablo Picasso', 'Frida Kahlo'], correctAnswer: 2, difficulty: 'difficile', points: 10 },
    { _id: 'question_es_3_4', type: 'question', subjectId: 'subject_espagnol', grade: '3ème', question: 'Comment dit‑on « je veux aller à la plage » en espagnol ?', options: ['quiero ir a la playa', 'quiero ir a la montaña', 'quiero ir al cine', 'quiero ir a casa'], correctAnswer: 0, difficulty: 'difficile', points: 10 },
    { _id: 'question_es_3_5', type: 'question', subjectId: 'subject_espagnol', grade: '3ème', question: 'Quelle est la capitale de l\'Argentine ?', options: ['Santiago', 'Lima', 'Buenos Aires', 'Montevideo'], correctAnswer: 2, difficulty: 'difficile', points: 10 },

    // EMC – 6ème
    { _id: 'question_emc_6_1', type: 'question', subjectId: 'subject_emc', grade: '6ème', question: 'Qu\'est‑ce qu\'une règle de vie ?', options: ['Norme pour vivre ensemble', 'Une loi scientifique', 'Une recette de cuisine', 'Une chanson'], correctAnswer: 0, difficulty: 'facile', points: 10 },
    { _id: 'question_emc_6_2', type: 'question', subjectId: 'subject_emc', grade: '6ème', question: 'Que signifie le mot « respect » ?', options: ['Considération pour les autres', 'Insubordination', 'Colère', 'Indifférence'], correctAnswer: 0, difficulty: 'facile', points: 10 },
    { _id: 'question_emc_6_3', type: 'question', subjectId: 'subject_emc', grade: '6ème', question: 'Quelle est la devise de la République française ?', options: ['Liberté, Égalité, Fraternité', 'Travail, Famille, Patrie', 'Paix, Amour, Liberté', 'Force, Honneur, Patrie'], correctAnswer: 0, difficulty: 'facile', points: 10 },
    { _id: 'question_emc_6_4', type: 'question', subjectId: 'subject_emc', grade: '6ème', question: 'Qu\'est‑ce qu\'une démocratie ?', options: ['Régime politique où le pouvoir appartient au peuple', 'Monarchie', 'Dictature', 'Oligarchie'], correctAnswer: 0, difficulty: 'facile', points: 10 },
    { _id: 'question_emc_6_5', type: 'question', subjectId: 'subject_emc', grade: '6ème', question: 'Quel symbole représente la République française ?', options: ['Marianne', 'La reine', 'Le roi', 'Jeanne d\'Arc'], correctAnswer: 0, difficulty: 'facile', points: 10 },

    // EMC – 5ème
    { _id: 'question_emc_5_1', type: 'question', subjectId: 'subject_emc', grade: '5ème', question: 'Qu\'est‑ce qu\'un droit ?', options: ['Une règle qui donne des libertés', 'Une obligation', 'Une punition', 'Une monnaie'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_emc_5_2', type: 'question', subjectId: 'subject_emc', grade: '5ème', question: 'Qu\'est‑ce que la laïcité ?', options: ['Principe de séparation des religions et de l\'État', 'Une religion', 'Un parti politique', 'Une fête'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_emc_5_3', type: 'question', subjectId: 'subject_emc', grade: '5ème', question: 'Quel est le rôle de la justice ?', options: ['Appliquer les lois et sanctionner', 'Faire des lois', 'Écrire des romans', 'Organiser des concerts'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_emc_5_4', type: 'question', subjectId: 'subject_emc', grade: '5ème', question: 'Qu\'est‑ce que le harcèlement scolaire ?', options: ['Violence répétée envers un élève', 'Une compétition sportive', 'Un jeu de société', 'Une activité artistique'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_emc_5_5', type: 'question', subjectId: 'subject_emc', grade: '5ème', question: 'À quoi sert une association ?', options: ['Regrouper des personnes autour d\'un projet', 'Faire du commerce', 'Faire campagne politique', 'Vendre des produits'], correctAnswer: 0, difficulty: 'moyen', points: 10 },

    // EMC – 4ème
    { _id: 'question_emc_4_1', type: 'question', subjectId: 'subject_emc', grade: '4ème', question: 'Qu\'est‑ce qu\'un citoyen ?', options: ['Personne qui a des droits et des devoirs dans son pays', 'Une personne sans nationalité', 'Un voyageur', 'Un mineur'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_emc_4_2', type: 'question', subjectId: 'subject_emc', grade: '4ème', question: 'Qu\'est‑ce que la solidarité ?', options: ['Aide réciproque entre personnes', 'Solitude', 'Combat', 'Opposition'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_emc_4_3', type: 'question', subjectId: 'subject_emc', grade: '4ème', question: 'Quels sont les symboles de la République française ?', options: ['Drapeau tricolore, La Marseillaise, Marianne', 'L\'euro et le drapeau européen', 'Le coq et la baguette', 'Les châteaux de la Loire'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_emc_4_4', type: 'question', subjectId: 'subject_emc', grade: '4ème', question: 'Qu\'est‑ce que la liberté d\'expression ?', options: ['Droit de s\'exprimer librement dans le respect des autres', 'Obligation de se taire', 'Insulter autrui', 'Faire la publicité'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_emc_4_5', type: 'question', subjectId: 'subject_emc', grade: '4ème', question: 'Quel organisme veille aux droits de l\'Homme en France ?', options: ['Défenseur des droits', 'Conseil de classe', 'Ministère de la santé', 'Ligue 1'], correctAnswer: 0, difficulty: 'moyen', points: 10 },

    // EMC – 3ème
    { _id: 'question_emc_3_1', type: 'question', subjectId: 'subject_emc', grade: '3ème', question: 'Qu\'est‑ce que le suffrage universel ?', options: ['Droit de vote pour tous les citoyens majeurs', 'Élection du président par le parlement', 'Droit de vote réservé aux hommes', 'Vote par téléphone'], correctAnswer: 0, difficulty: 'difficile', points: 10 },
    { _id: 'question_emc_3_2', type: 'question', subjectId: 'subject_emc', grade: '3ème', question: 'Qu\'est‑ce qu\'une constitution ?', options: ['Texte qui définit l\'organisation des pouvoirs', 'Recueil de lois sur l\'école', 'Guide culinaire', 'Bible'], correctAnswer: 0, difficulty: 'difficile', points: 10 },
    { _id: 'question_emc_3_3', type: 'question', subjectId: 'subject_emc', grade: '3ème', question: 'Quels sont les trois pouvoirs selon la séparation des pouvoirs ?', options: ['Législatif, exécutif, judiciaire', 'Militaire, médiatique, religieux', 'Administratif, diplomatique, financier', 'Économique, social, culturel'], correctAnswer: 0, difficulty: 'difficile', points: 10 },
    { _id: 'question_emc_3_4', type: 'question', subjectId: 'subject_emc', grade: '3ème', question: 'Qu\'est‑ce qu\'un référendum ?', options: ['Consultation directe du peuple', 'Nomination d\'un ministre', 'Fête nationale', 'Approbation par le parlement'], correctAnswer: 0, difficulty: 'difficile', points: 10 },
    { _id: 'question_emc_3_5', type: 'question', subjectId: 'subject_emc', grade: '3ème', question: 'Qui a le pouvoir de promulguer les lois en France ?', options: ['Le Président de la République', 'Le Premier ministre', 'Le Sénat', 'Le Conseil constitutionnel'], correctAnswer: 0, difficulty: 'difficile', points: 10 },

    // Capitales du monde – toutes classes (20 questions, grade‑specific IDs)
    // Chaque question est dupliquée pour chaque niveau (6ème à 3ème)
    { _id: 'question_cap_6_1', type: 'question', subjectId: 'subject_capitales', grade: '6ème', question: 'Quelle est la capitale du Canada ?', options: ['Toronto', 'Vancouver', 'Ottawa', 'Montréal'], correctAnswer: 2, difficulty: 'facile', points: 10 },
    { _id: 'question_cap_6_2', type: 'question', subjectId: 'subject_capitales', grade: '6ème', question: 'Quelle est la capitale du Japon ?', options: ['Kyoto', 'Tokyo', 'Osaka', 'Sapporo'], correctAnswer: 1, difficulty: 'facile', points: 10 },
    { _id: 'question_cap_6_3', type: 'question', subjectId: 'subject_capitales', grade: '6ème', question: 'Quelle est la capitale de l\'Australie ?', options: ['Sydney', 'Melbourne', 'Canberra', 'Brisbane'], correctAnswer: 2, difficulty: 'facile', points: 10 },
    { _id: 'question_cap_6_4', type: 'question', subjectId: 'subject_capitales', grade: '6ème', question: 'Quelle est la capitale du Brésil ?', options: ['Rio de Janeiro', 'São Paulo', 'Brasília', 'Salvador'], correctAnswer: 2, difficulty: 'facile', points: 10 },
    { _id: 'question_cap_6_5', type: 'question', subjectId: 'subject_capitales', grade: '6ème', question: 'Quelle est la capitale du Maroc ?', options: ['Marrakech', 'Casablanca', 'Rabat', 'Tanger'], correctAnswer: 2, difficulty: 'facile', points: 10 },
    { _id: 'question_cap_6_6', type: 'question', subjectId: 'subject_capitales', grade: '6ème', question: 'Quelle est la capitale de l\'Inde ?', options: ['Mumbai', 'Kolkata', 'New Delhi', 'Chennai'], correctAnswer: 2, difficulty: 'facile', points: 10 },
    { _id: 'question_cap_6_7', type: 'question', subjectId: 'subject_capitales', grade: '6ème', question: 'Quelle est la capitale de la Russie ?', options: ['Saint‑Pétersbourg', 'Moscou', 'Kazan', 'Vladivostok'], correctAnswer: 1, difficulty: 'facile', points: 10 },
    { _id: 'question_cap_6_8', type: 'question', subjectId: 'subject_capitales', grade: '6ème', question: 'Quelle est la capitale de l\'Afrique du Sud ?', options: ['Le Cap', 'Johannesburg', 'Pretoria', 'Durban'], correctAnswer: 2, difficulty: 'facile', points: 10 },
    { _id: 'question_cap_6_9', type: 'question', subjectId: 'subject_capitales', grade: '6ème', question: 'Quelle est la capitale du Mexique ?', options: ['Guadalajara', 'Monterrey', 'Mexico', 'Cancún'], correctAnswer: 2, difficulty: 'facile', points: 10 },
    { _id: 'question_cap_6_10', type: 'question', subjectId: 'subject_capitales', grade: '6ème', question: 'Quelle est la capitale de la Chine ?', options: ['Shanghai', 'Hong Kong', 'Pékin', 'Canton'], correctAnswer: 2, difficulty: 'facile', points: 10 },
    { _id: 'question_cap_6_11', type: 'question', subjectId: 'subject_capitales', grade: '6ème', question: 'Quelle est la capitale des États‑Unis ?', options: ['New York', 'Los Angeles', 'Washington', 'Chicago'], correctAnswer: 2, difficulty: 'facile', points: 10 },
    { _id: 'question_cap_6_12', type: 'question', subjectId: 'subject_capitales', grade: '6ème', question: 'Quelle est la capitale de la Turquie ?', options: ['Istanbul', 'Ankara', 'Izmir', 'Antalya'], correctAnswer: 1, difficulty: 'facile', points: 10 },
    { _id: 'question_cap_6_13', type: 'question', subjectId: 'subject_capitales', grade: '6ème', question: 'Quelle est la capitale de la Grèce ?', options: ['Thessalonique', 'Athènes', 'Patras', 'Rhodes'], correctAnswer: 1, difficulty: 'facile', points: 10 },
    { _id: 'question_cap_6_14', type: 'question', subjectId: 'subject_capitales', grade: '6ème', question: 'Quelle est la capitale de l\'Allemagne ?', options: ['Munich', 'Hambourg', 'Berlin', 'Francfort'], correctAnswer: 2, difficulty: 'facile', points: 10 },
    { _id: 'question_cap_6_15', type: 'question', subjectId: 'subject_capitales', grade: '6ème', question: 'Quelle est la capitale de l\'Égypte ?', options: ['Alexandrie', 'Le Caire', 'Gizeh', 'Louxor'], correctAnswer: 1, difficulty: 'facile', points: 10 },
    { _id: 'question_cap_6_16', type: 'question', subjectId: 'subject_capitales', grade: '6ème', question: 'Quelle est la capitale de l\'Italie ?', options: ['Milan', 'Venise', 'Rome', 'Naples'], correctAnswer: 2, difficulty: 'facile', points: 10 },
    { _id: 'question_cap_6_17', type: 'question', subjectId: 'subject_capitales', grade: '6ème', question: 'Quelle est la capitale de l\'Argentine ?', options: ['Buenos Aires', 'Santiago', 'Montevideo', 'Bogotá'], correctAnswer: 0, difficulty: 'facile', points: 10 },
    { _id: 'question_cap_6_18', type: 'question', subjectId: 'subject_capitales', grade: '6ème', question: 'Quelle est la capitale du Nigéria ?', options: ['Lagos', 'Abuja', 'Kano', 'Port Harcourt'], correctAnswer: 1, difficulty: 'facile', points: 10 },
    { _id: 'question_cap_6_19', type: 'question', subjectId: 'subject_capitales', grade: '6ème', question: 'Quelle est la capitale de l\'Arabie Saoudite ?', options: ['Djeddah', 'Riyad', 'La Mecque', 'Dammam'], correctAnswer: 1, difficulty: 'facile', points: 10 },
    { _id: 'question_cap_6_20', type: 'question', subjectId: 'subject_capitales', grade: '6ème', question: 'Quelle est la capitale du Pérou ?', options: ['Lima', 'Cusco', 'Arequipa', 'Trujillo'], correctAnswer: 0, difficulty: 'facile', points: 10 },
    // Copy of capital questions for 5ème, 4ème and 3ème (same content but different grade and IDs)
    { _id: 'question_cap_5_1', type: 'question', subjectId: 'subject_capitales', grade: '5ème', question: 'Quelle est la capitale du Canada ?', options: ['Toronto', 'Vancouver', 'Ottawa', 'Montréal'], correctAnswer: 2, difficulty: 'moyen', points: 10 },
    { _id: 'question_cap_5_2', type: 'question', subjectId: 'subject_capitales', grade: '5ème', question: 'Quelle est la capitale du Japon ?', options: ['Kyoto', 'Tokyo', 'Osaka', 'Sapporo'], correctAnswer: 1, difficulty: 'moyen', points: 10 },
    { _id: 'question_cap_5_3', type: 'question', subjectId: 'subject_capitales', grade: '5ème', question: 'Quelle est la capitale de l\'Australie ?', options: ['Sydney', 'Melbourne', 'Canberra', 'Brisbane'], correctAnswer: 2, difficulty: 'moyen', points: 10 },
    { _id: 'question_cap_5_4', type: 'question', subjectId: 'subject_capitales', grade: '5ème', question: 'Quelle est la capitale du Brésil ?', options: ['Rio de Janeiro', 'São Paulo', 'Brasília', 'Salvador'], correctAnswer: 2, difficulty: 'moyen', points: 10 },
    { _id: 'question_cap_5_5', type: 'question', subjectId: 'subject_capitales', grade: '5ème', question: 'Quelle est la capitale du Maroc ?', options: ['Marrakech', 'Casablanca', 'Rabat', 'Tanger'], correctAnswer: 2, difficulty: 'moyen', points: 10 },
    { _id: 'question_cap_5_6', type: 'question', subjectId: 'subject_capitales', grade: '5ème', question: 'Quelle est la capitale de l\'Inde ?', options: ['Mumbai', 'Kolkata', 'New Delhi', 'Chennai'], correctAnswer: 2, difficulty: 'moyen', points: 10 },
    { _id: 'question_cap_5_7', type: 'question', subjectId: 'subject_capitales', grade: '5ème', question: 'Quelle est la capitale de la Russie ?', options: ['Saint‑Pétersbourg', 'Moscou', 'Kazan', 'Vladivostok'], correctAnswer: 1, difficulty: 'moyen', points: 10 },
    { _id: 'question_cap_5_8', type: 'question', subjectId: 'subject_capitales', grade: '5ème', question: 'Quelle est la capitale de l\'Afrique du Sud ?', options: ['Le Cap', 'Johannesburg', 'Pretoria', 'Durban'], correctAnswer: 2, difficulty: 'moyen', points: 10 },
    { _id: 'question_cap_5_9', type: 'question', subjectId: 'subject_capitales', grade: '5ème', question: 'Quelle est la capitale du Mexique ?', options: ['Guadalajara', 'Monterrey', 'Mexico', 'Cancún'], correctAnswer: 2, difficulty: 'moyen', points: 10 },
    { _id: 'question_cap_5_10', type: 'question', subjectId: 'subject_capitales', grade: '5ème', question: 'Quelle est la capitale de la Chine ?', options: ['Shanghai', 'Hong Kong', 'Pékin', 'Canton'], correctAnswer: 2, difficulty: 'moyen', points: 10 },
    { _id: 'question_cap_5_11', type: 'question', subjectId: 'subject_capitales', grade: '5ème', question: 'Quelle est la capitale des États‑Unis ?', options: ['New York', 'Los Angeles', 'Washington', 'Chicago'], correctAnswer: 2, difficulty: 'moyen', points: 10 },
    { _id: 'question_cap_5_12', type: 'question', subjectId: 'subject_capitales', grade: '5ème', question: 'Quelle est la capitale de la Turquie ?', options: ['Istanbul', 'Ankara', 'Izmir', 'Antalya'], correctAnswer: 1, difficulty: 'moyen', points: 10 },
    { _id: 'question_cap_5_13', type: 'question', subjectId: 'subject_capitales', grade: '5ème', question: 'Quelle est la capitale de la Grèce ?', options: ['Thessalonique', 'Athènes', 'Patras', 'Rhodes'], correctAnswer: 1, difficulty: 'moyen', points: 10 },
    { _id: 'question_cap_5_14', type: 'question', subjectId: 'subject_capitales', grade: '5ème', question: 'Quelle est la capitale de l\'Allemagne ?', options: ['Munich', 'Hambourg', 'Berlin', 'Francfort'], correctAnswer: 2, difficulty: 'moyen', points: 10 },
    { _id: 'question_cap_5_15', type: 'question', subjectId: 'subject_capitales', grade: '5ème', question: 'Quelle est la capitale de l\'Égypte ?', options: ['Alexandrie', 'Le Caire', 'Gizeh', 'Louxor'], correctAnswer: 1, difficulty: 'moyen', points: 10 },
    { _id: 'question_cap_5_16', type: 'question', subjectId: 'subject_capitales', grade: '5ème', question: 'Quelle est la capitale de l\'Italie ?', options: ['Milan', 'Venise', 'Rome', 'Naples'], correctAnswer: 2, difficulty: 'moyen', points: 10 },
    { _id: 'question_cap_5_17', type: 'question', subjectId: 'subject_capitales', grade: '5ème', question: 'Quelle est la capitale de l\'Argentine ?', options: ['Buenos Aires', 'Santiago', 'Montevideo', 'Bogotá'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_cap_5_18', type: 'question', subjectId: 'subject_capitales', grade: '5ème', question: 'Quelle est la capitale du Nigéria ?', options: ['Lagos', 'Abuja', 'Kano', 'Port Harcourt'], correctAnswer: 1, difficulty: 'moyen', points: 10 },
    { _id: 'question_cap_5_19', type: 'question', subjectId: 'subject_capitales', grade: '5ème', question: 'Quelle est la capitale de l\'Arabie Saoudite ?', options: ['Djeddah', 'Riyad', 'La Mecque', 'Dammam'], correctAnswer: 1, difficulty: 'moyen', points: 10 },
    { _id: 'question_cap_5_20', type: 'question', subjectId: 'subject_capitales', grade: '5ème', question: 'Quelle est la capitale du Pérou ?', options: ['Lima', 'Cusco', 'Arequipa', 'Trujillo'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    // 4ème capitales (similar to 6ème) use difficulty 'moyen'
    { _id: 'question_cap_4_1', type: 'question', subjectId: 'subject_capitales', grade: '4ème', question: 'Quelle est la capitale du Canada ?', options: ['Toronto', 'Vancouver', 'Ottawa', 'Montréal'], correctAnswer: 2, difficulty: 'moyen', points: 10 },
    { _id: 'question_cap_4_2', type: 'question', subjectId: 'subject_capitales', grade: '4ème', question: 'Quelle est la capitale du Japon ?', options: ['Kyoto', 'Tokyo', 'Osaka', 'Sapporo'], correctAnswer: 1, difficulty: 'moyen', points: 10 },
    { _id: 'question_cap_4_3', type: 'question', subjectId: 'subject_capitales', grade: '4ème', question: 'Quelle est la capitale de l\'Australie ?', options: ['Sydney', 'Melbourne', 'Canberra', 'Brisbane'], correctAnswer: 2, difficulty: 'moyen', points: 10 },
    { _id: 'question_cap_4_4', type: 'question', subjectId: 'subject_capitales', grade: '4ème', question: 'Quelle est la capitale du Brésil ?', options: ['Rio de Janeiro', 'São Paulo', 'Brasília', 'Salvador'], correctAnswer: 2, difficulty: 'moyen', points: 10 },
    { _id: 'question_cap_4_5', type: 'question', subjectId: 'subject_capitales', grade: '4ème', question: 'Quelle est la capitale du Maroc ?', options: ['Marrakech', 'Casablanca', 'Rabat', 'Tanger'], correctAnswer: 2, difficulty: 'moyen', points: 10 },
    { _id: 'question_cap_4_6', type: 'question', subjectId: 'subject_capitales', grade: '4ème', question: 'Quelle est la capitale de l\'Inde ?', options: ['Mumbai', 'Kolkata', 'New Delhi', 'Chennai'], correctAnswer: 2, difficulty: 'moyen', points: 10 },
    { _id: 'question_cap_4_7', type: 'question', subjectId: 'subject_capitales', grade: '4ème', question: 'Quelle est la capitale de la Russie ?', options: ['Saint‑Pétersbourg', 'Moscou', 'Kazan', 'Vladivostok'], correctAnswer: 1, difficulty: 'moyen', points: 10 },
    { _id: 'question_cap_4_8', type: 'question', subjectId: 'subject_capitales', grade: '4ème', question: 'Quelle est la capitale de l\'Afrique du Sud ?', options: ['Le Cap', 'Johannesburg', 'Pretoria', 'Durban'], correctAnswer: 2, difficulty: 'moyen', points: 10 },
    { _id: 'question_cap_4_9', type: 'question', subjectId: 'subject_capitales', grade: '4ème', question: 'Quelle est la capitale du Mexique ?', options: ['Guadalajara', 'Monterrey', 'Mexico', 'Cancún'], correctAnswer: 2, difficulty: 'moyen', points: 10 },
    { _id: 'question_cap_4_10', type: 'question', subjectId: 'subject_capitales', grade: '4ème', question: 'Quelle est la capitale de la Chine ?', options: ['Shanghai', 'Hong Kong', 'Pékin', 'Canton'], correctAnswer: 2, difficulty: 'moyen', points: 10 },
    { _id: 'question_cap_4_11', type: 'question', subjectId: 'subject_capitales', grade: '4ème', question: 'Quelle est la capitale des États‑Unis ?', options: ['New York', 'Los Angeles', 'Washington', 'Chicago'], correctAnswer: 2, difficulty: 'moyen', points: 10 },
    { _id: 'question_cap_4_12', type: 'question', subjectId: 'subject_capitales', grade: '4ème', question: 'Quelle est la capitale de la Turquie ?', options: ['Istanbul', 'Ankara', 'Izmir', 'Antalya'], correctAnswer: 1, difficulty: 'moyen', points: 10 },
    { _id: 'question_cap_4_13', type: 'question', subjectId: 'subject_capitales', grade: '4ème', question: 'Quelle est la capitale de la Grèce ?', options: ['Thessalonique', 'Athènes', 'Patras', 'Rhodes'], correctAnswer: 1, difficulty: 'moyen', points: 10 },
    { _id: 'question_cap_4_14', type: 'question', subjectId: 'subject_capitales', grade: '4ème', question: 'Quelle est la capitale de l\'Allemagne ?', options: ['Munich', 'Hambourg', 'Berlin', 'Francfort'], correctAnswer: 2, difficulty: 'moyen', points: 10 },
    { _id: 'question_cap_4_15', type: 'question', subjectId: 'subject_capitales', grade: '4ème', question: 'Quelle est la capitale de l\'Égypte ?', options: ['Alexandrie', 'Le Caire', 'Gizeh', 'Louxor'], correctAnswer: 1, difficulty: 'moyen', points: 10 },
    { _id: 'question_cap_4_16', type: 'question', subjectId: 'subject_capitales', grade: '4ème', question: 'Quelle est la capitale de l\'Italie ?', options: ['Milan', 'Venise', 'Rome', 'Naples'], correctAnswer: 2, difficulty: 'moyen', points: 10 },
    { _id: 'question_cap_4_17', type: 'question', subjectId: 'subject_capitales', grade: '4ème', question: 'Quelle est la capitale de l\'Argentine ?', options: ['Buenos Aires', 'Santiago', 'Montevideo', 'Bogotá'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_cap_4_18', type: 'question', subjectId: 'subject_capitales', grade: '4ème', question: 'Quelle est la capitale du Nigéria ?', options: ['Lagos', 'Abuja', 'Kano', 'Port Harcourt'], correctAnswer: 1, difficulty: 'moyen', points: 10 },
    { _id: 'question_cap_4_19', type: 'question', subjectId: 'subject_capitales', grade: '4ème', question: 'Quelle est la capitale de l\'Arabie Saoudite ?', options: ['Djeddah', 'Riyad', 'La Mecque', 'Dammam'], correctAnswer: 1, difficulty: 'moyen', points: 10 },
    { _id: 'question_cap_4_20', type: 'question', subjectId: 'subject_capitales', grade: '4ème', question: 'Quelle est la capitale du Pérou ?', options: ['Lima', 'Cusco', 'Arequipa', 'Trujillo'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    // 3ème capitales
    { _id: 'question_cap_3_1', type: 'question', subjectId: 'subject_capitales', grade: '3ème', question: 'Quelle est la capitale du Canada ?', options: ['Toronto', 'Vancouver', 'Ottawa', 'Montréal'], correctAnswer: 2, difficulty: 'difficile', points: 10 },
    { _id: 'question_cap_3_2', type: 'question', subjectId: 'subject_capitales', grade: '3ème', question: 'Quelle est la capitale du Japon ?', options: ['Kyoto', 'Tokyo', 'Osaka', 'Sapporo'], correctAnswer: 1, difficulty: 'difficile', points: 10 },
    { _id: 'question_cap_3_3', type: 'question', subjectId: 'subject_capitales', grade: '3ème', question: 'Quelle est la capitale de l\'Australie ?', options: ['Sydney', 'Melbourne', 'Canberra', 'Brisbane'], correctAnswer: 2, difficulty: 'difficile', points: 10 },
    { _id: 'question_cap_3_4', type: 'question', subjectId: 'subject_capitales', grade: '3ème', question: 'Quelle est la capitale du Brésil ?', options: ['Rio de Janeiro', 'São Paulo', 'Brasília', 'Salvador'], correctAnswer: 2, difficulty: 'difficile', points: 10 },
    { _id: 'question_cap_3_5', type: 'question', subjectId: 'subject_capitales', grade: '3ème', question: 'Quelle est la capitale du Maroc ?', options: ['Marrakech', 'Casablanca', 'Rabat', 'Tanger'], correctAnswer: 2, difficulty: 'difficile', points: 10 },
    { _id: 'question_cap_3_6', type: 'question', subjectId: 'subject_capitales', grade: '3ème', question: 'Quelle est la capitale de l\'Inde ?', options: ['Mumbai', 'Kolkata', 'New Delhi', 'Chennai'], correctAnswer: 2, difficulty: 'difficile', points: 10 },
    { _id: 'question_cap_3_7', type: 'question', subjectId: 'subject_capitales', grade: '3ème', question: 'Quelle est la capitale de la Russie ?', options: ['Saint‑Pétersbourg', 'Moscou', 'Kazan', 'Vladivostok'], correctAnswer: 1, difficulty: 'difficile', points: 10 },
    { _id: 'question_cap_3_8', type: 'question', subjectId: 'subject_capitales', grade: '3ème', question: 'Quelle est la capitale de l\'Afrique du Sud ?', options: ['Le Cap', 'Johannesburg', 'Pretoria', 'Durban'], correctAnswer: 2, difficulty: 'difficile', points: 10 },
    { _id: 'question_cap_3_9', type: 'question', subjectId: 'subject_capitales', grade: '3ème', question: 'Quelle est la capitale du Mexique ?', options: ['Guadalajara', 'Monterrey', 'Mexico', 'Cancún'], correctAnswer: 2, difficulty: 'difficile', points: 10 },
    { _id: 'question_cap_3_10', type: 'question', subjectId: 'subject_capitales', grade: '3ème', question: 'Quelle est la capitale de la Chine ?', options: ['Shanghai', 'Hong Kong', 'Pékin', 'Canton'], correctAnswer: 2, difficulty: 'difficile', points: 10 },
    { _id: 'question_cap_3_11', type: 'question', subjectId: 'subject_capitales', grade: '3ème', question: 'Quelle est la capitale des États‑Unis ?', options: ['New York', 'Los Angeles', 'Washington', 'Chicago'], correctAnswer: 2, difficulty: 'difficile', points: 10 },
    { _id: 'question_cap_3_12', type: 'question', subjectId: 'subject_capitales', grade: '3ème', question: 'Quelle est la capitale de la Turquie ?', options: ['Istanbul', 'Ankara', 'Izmir', 'Antalya'], correctAnswer: 1, difficulty: 'difficile', points: 10 },
    { _id: 'question_cap_3_13', type: 'question', subjectId: 'subject_capitales', grade: '3ème', question: 'Quelle est la capitale de la Grèce ?', options: ['Thessalonique', 'Athènes', 'Patras', 'Rhodes'], correctAnswer: 1, difficulty: 'difficile', points: 10 },
    { _id: 'question_cap_3_14', type: 'question', subjectId: 'subject_capitales', grade: '3ème', question: 'Quelle est la capitale de l\'Allemagne ?', options: ['Munich', 'Hambourg', 'Berlin', 'Francfort'], correctAnswer: 2, difficulty: 'difficile', points: 10 },
    { _id: 'question_cap_3_15', type: 'question', subjectId: 'subject_capitales', grade: '3ème', question: 'Quelle est la capitale de l\'Égypte ?', options: ['Alexandrie', 'Le Caire', 'Gizeh', 'Louxor'], correctAnswer: 1, difficulty: 'difficile', points: 10 },
    { _id: 'question_cap_3_16', type: 'question', subjectId: 'subject_capitales', grade: '3ème', question: 'Quelle est la capitale de l\'Italie ?', options: ['Milan', 'Venise', 'Rome', 'Naples'], correctAnswer: 2, difficulty: 'difficile', points: 10 },
    { _id: 'question_cap_3_17', type: 'question', subjectId: 'subject_capitales', grade: '3ème', question: 'Quelle est la capitale de l\'Argentine ?', options: ['Buenos Aires', 'Santiago', 'Montevideo', 'Bogotá'], correctAnswer: 0, difficulty: 'difficile', points: 10 },
    { _id: 'question_cap_3_18', type: 'question', subjectId: 'subject_capitales', grade: '3ème', question: 'Quelle est la capitale du Nigéria ?', options: ['Lagos', 'Abuja', 'Kano', 'Port Harcourt'], correctAnswer: 1, difficulty: 'difficile', points: 10 },
    { _id: 'question_cap_3_19', type: 'question', subjectId: 'subject_capitales', grade: '3ème', question: 'Quelle est la capitale de l\'Arabie Saoudite ?', options: ['Djeddah', 'Riyad', 'La Mecque', 'Dammam'], correctAnswer: 1, difficulty: 'difficile', points: 10 },
    { _id: 'question_cap_3_20', type: 'question', subjectId: 'subject_capitales', grade: '3ème', question: 'Quelle est la capitale du Pérou ?', options: ['Lima', 'Cusco', 'Arequipa', 'Trujillo'], correctAnswer: 0, difficulty: 'difficile', points: 10 },

    // Culture Pop – 6ème
    { _id: 'question_pop_6_1', type: 'question', subjectId: 'subject_culturepop', grade: '6ème', question: 'Quel super‑héros est l\'alter ego de Bruce Wayne ?', options: ['Superman', 'Iron Man', 'Spider‑Man', 'Batman'], correctAnswer: 3, difficulty: 'facile', points: 10 },
    { _id: 'question_pop_6_2', type: 'question', subjectId: 'subject_culturepop', grade: '6ème', question: 'Quel est le nom du sorcier à lunettes créé par J.K. Rowling ?', options: ['Harry Potter', 'Gandalf', 'Merlin', 'Albus Dumbledore'], correctAnswer: 0, difficulty: 'facile', points: 10 },
    { _id: 'question_pop_6_3', type: 'question', subjectId: 'subject_culturepop', grade: '6ème', question: 'Dans quel film d\'animation suit‑on un petit poisson nommé Nemo ?', options: ['Le Roi Lion', 'Le Monde de Nemo', 'Ratatouille', 'Toy Story'], correctAnswer: 1, difficulty: 'facile', points: 10 },
    { _id: 'question_pop_6_4', type: 'question', subjectId: 'subject_culturepop', grade: '6ème', question: 'Quel est le nom de la reine dotée de pouvoirs de glace dans « La Reine des Neiges » ?', options: ['Anna', 'Elsa', 'Jasmine', 'Belle'], correctAnswer: 1, difficulty: 'facile', points: 10 },
    { _id: 'question_pop_6_5', type: 'question', subjectId: 'subject_culturepop', grade: '6ème', question: 'Quel animal est Timon dans « Le Roi Lion » ?', options: ['Suricate', 'Lion', 'Phacochère', 'Girafe'], correctAnswer: 0, difficulty: 'facile', points: 10 },

    // Culture Pop – 5ème
    { _id: 'question_pop_5_1', type: 'question', subjectId: 'subject_culturepop', grade: '5ème', question: 'Quel est le nom du héros de la série « Stranger Things » ayant des pouvoirs psychiques ?', options: ['Mike', 'Dustin', 'Onze (Eleven)', 'Will'], correctAnswer: 2, difficulty: 'moyen', points: 10 },
    { _id: 'question_pop_5_2', type: 'question', subjectId: 'subject_culturepop', grade: '5ème', question: 'Quel est le nom du plombier moustachu de Nintendo ?', options: ['Luigi', 'Sonic', 'Mario', 'Peach'], correctAnswer: 2, difficulty: 'moyen', points: 10 },
    { _id: 'question_pop_5_3', type: 'question', subjectId: 'subject_culturepop', grade: '5ème', question: 'Quel chanteur est le leader du groupe Queen ?', options: ['Freddie Mercury', 'Mick Jagger', 'Bono', 'Kurt Cobain'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_pop_5_4', type: 'question', subjectId: 'subject_culturepop', grade: '5ème', question: 'Quelle saga de films met en scène des robots appelés Autobots et Decepticons ?', options: ['Transformers', 'Star Wars', 'Terminator', 'Matrix'], correctAnswer: 0, difficulty: 'moyen', points: 10 },
    { _id: 'question_pop_5_5', type: 'question', subjectId: 'subject_culturepop', grade: '5ème', question: 'Quel est le nom de la franchise de jeux vidéo où le joueur capture des créatures appelées Pokémon ?', options: ['Yu‑Gi‑Oh!', 'Pokémon', 'Digimon', 'Bakugan'], correctAnswer: 1, difficulty: 'moyen', points: 10 },

    // Culture Pop – 4ème
    { _id: 'question_pop_4_1', type: 'question', subjectId: 'subject_culturepop', grade: '4ème', question: 'Quel groupe de super‑héros comprend Iron Man, Thor et Captain America ?', options: ['Les X‑Men', 'La Justice League', 'Les Avengers', 'Les Gardiens de la Galaxie'], correctAnswer: 2, difficulty: 'moyen', points: 10 },
    { _id: 'question_pop_4_2', type: 'question', subjectId: 'subject_culturepop', grade: '4ème', question: 'Quelle série animée japonaise met en scène un ninja du village de Konoha ?', options: ['Dragon Ball', 'One Piece', 'Naruto', 'Bleach'], correctAnswer: 2, difficulty: 'moyen', points: 10 },
    { _id: 'question_pop_4_3', type: 'question', subjectId: 'subject_culturepop', grade: '4ème', question: 'Quel rappeur belge est connu pour l\'album « Racine Carrée » ?', options: ['Damso', 'Roméo Elvis', 'Stromae', 'Orelsan'], correctAnswer: 2, difficulty: 'moyen', points: 10 },
    { _id: 'question_pop_4_4', type: 'question', subjectId: 'subject_culturepop', grade: '4ème', question: 'Quel est le titre de la série de romans commençant par « Le Trône de Fer » ?', options: ['Harry Potter', 'Game of Thrones', 'Le Hobbit', 'Twilight'], correctAnswer: 1, difficulty: 'moyen', points: 10 },
    { _id: 'question_pop_4_5', type: 'question', subjectId: 'subject_culturepop', grade: '4ème', question: 'Quel jeu vidéo consiste à construire et survivre dans un monde de blocs ?', options: ['Fortnite', 'Minecraft', 'Roblox', 'Tetris'], correctAnswer: 1, difficulty: 'moyen', points: 10 },

    // Culture Pop – 3ème
    { _id: 'question_pop_3_1', type: 'question', subjectId: 'subject_culturepop', grade: '3ème', question: 'Quelle chanteuse américaine a sorti l\'album « 1989 » ?', options: ['Lady Gaga', 'Ariana Grande', 'Taylor Swift', 'Billie Eilish'], correctAnswer: 2, difficulty: 'difficile', points: 10 },
    { _id: 'question_pop_3_2', type: 'question', subjectId: 'subject_culturepop', grade: '3ème', question: 'Quel film raconte l\'histoire d\'un bateau qui coule après avoir heurté un iceberg ?', options: ['Avatar', 'Titanic', 'Pirates des Caraïbes', 'Inception'], correctAnswer: 1, difficulty: 'difficile', points: 10 },
    { _id: 'question_pop_3_3', type: 'question', subjectId: 'subject_culturepop', grade: '3ème', question: 'Quel joueur français a marqué en finale de la Coupe du Monde 2018 et est connu pour sa coiffure ?', options: ['Kylian Mbappé', 'Antoine Griezmann', 'Paul Pogba', 'Olivier Giroud'], correctAnswer: 2, difficulty: 'difficile', points: 10 },
    { _id: 'question_pop_3_4', type: 'question', subjectId: 'subject_culturepop', grade: '3ème', question: 'Quelle plateforme de vidéos courtes a popularisé des danses virales ?', options: ['Instagram', 'Snapchat', 'TikTok', 'Facebook'], correctAnswer: 2, difficulty: 'difficile', points: 10 },
    { _id: 'question_pop_3_5', type: 'question', subjectId: 'subject_culturepop', grade: '3ème', question: 'Quel film Marvel réunit une équipe comprenant Rocket, Groot et Star‑Lord ?', options: ['Les Gardiens de la Galaxie', 'Avengers : Endgame', 'Black Panther', 'Docteur Strange'], correctAnswer: 0, difficulty: 'difficile', points: 10 },
  ];

  const newData: DataStorage = {
    profiles: {},
    subjects: {},
    questions: {},
    quizResults: {},
  };
  // Populate subjects into the new data object
  subjects.forEach((s) => {
    newData.subjects[s._id] = s;
  });
  // Populate the predefined questions array.  These questions cover all
  // subjects and grade combinations and form the basis of the quiz.  If
  // additional questions are desired you can append to the `questions` array
  // defined above.
  questions.forEach((q) => {
    newData.questions[q._id] = q;
  });
  saveData(newData);
}

// Ensure subjects and questions exist on module load
seedInitialData();

// Profile API ----------------------------------------------------------------

export async function getProfiles(): Promise<ProfileDoc[]> {
  const data = loadData();
  return Object.values(data.profiles);
}

export async function createProfile(name: string, grade: string): Promise<ProfileDoc> {
  const data = loadData();
  const id = generateId('profile');
  const profile: ProfileDoc = {
    _id: id,
    type: 'profile',
    name,
    grade,
    xp: 0,
    streak: 0,
  };
  data.profiles[id] = profile;
  saveData(data);
  return profile;
}

export async function deleteProfile(id: string): Promise<void> {
  const data = loadData();
  delete data.profiles[id];
  // Remove quiz results linked to this profile
  for (const [key, result] of Object.entries(data.quizResults)) {
    if (result.profileId === id) {
      delete data.quizResults[key];
    }
  }
  saveData(data);
}

export async function updateProfileGrade(id: string, grade: string): Promise<ProfileDoc> {
  const data = loadData();
  const profile = data.profiles[id];
  if (!profile) throw new Error('Profile not found');
  profile.grade = grade;
  data.profiles[id] = profile;
  saveData(data);
  return profile;
}

export async function resetProfile(id: string): Promise<void> {
  const data = loadData();
  const profile = data.profiles[id];
  if (!profile) return;
  profile.xp = 0;
  profile.streak = 0;
  profile.lastQuizAt = undefined;
  // Remove quiz results
  for (const [key, result] of Object.entries(data.quizResults)) {
    if (result.profileId === id) {
      delete data.quizResults[key];
    }
  }
  data.profiles[id] = profile;
  saveData(data);
}

// Subject API ----------------------------------------------------------------

/**
 * Return the list of subjects available for a given class. When a grade is
 * provided, subjects are filtered to those whose `grades` array includes
 * that grade or the special value "all". Without a grade, all subjects are
 * returned. The order of subjects is preserved based on insertion order
 * during seeding.
 *
 * @param grade Optional class level (e.g. "6ème", "5ème") to filter by.
 */
export async function getSubjects(grade?: string): Promise<SubjectDoc[]> {
  const data = loadData();
  const allSubjects = Object.values(data.subjects);
  if (!grade) {
    return allSubjects;
  }
  return allSubjects.filter((s) => s.grades.includes(grade) || s.grades.includes('all'));
}

// Question API ---------------------------------------------------------------

export async function getQuestions(
  subjectId: string,
  grade: string,
  limit: number,
): Promise<QuestionDoc[]> {
  const data = loadData();
  const allQuestions = Object.values(data.questions);
  const filtered = allQuestions.filter(
    (q) => q.subjectId === subjectId && q.grade === grade,
  );
  // Shuffle and limit
  // Shuffle and limit the questions themselves
  const shuffledQuestions = filtered.sort(() => Math.random() - 0.5);
  let selected: QuestionDoc[] = shuffledQuestions.slice(0, limit);
  // If there are not enough questions to meet the limit, repeat randomly
  if (selected.length < limit && shuffledQuestions.length > 0) {
    const needed = limit - selected.length;
    for (let i = 0; i < needed; i++) {
      selected.push(shuffledQuestions[i % shuffledQuestions.length]);
    }
  }
  // For each selected question, randomise the order of answers so that the
  // correct answer is not always at the same index. We create a copy of
  // the options, shuffle them, then compute the new correctAnswer index.
  function shuffle<T>(array: T[]): T[] {
    const arr = [...array];
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
  }
  return selected.map((q) => {
    const optionsShuffled = shuffle(q.options);
    const correctOption = q.options[q.correctAnswer];
    const newCorrectIndex = optionsShuffled.indexOf(correctOption);
    return {
      ...q,
      options: optionsShuffled,
      correctAnswer: newCorrectIndex,
    };
  });
}

// Quiz results API -----------------------------------------------------------

export async function recordQuizResult(
  profileId: string,
  subjectId: string,
  score: number,
  totalQuestions: number,
  timeSpent: number,
): Promise<{ xpGained: number }> {
  const data = loadData();
  const id = generateId('quiz');
  const completedAt = new Date().toISOString();
  const result: QuizResultDoc = {
    _id: id,
    type: 'quizResult',
    profileId,
    subjectId,
    score,
    totalQuestions,
    timeSpent,
    completedAt,
  };
  data.quizResults[id] = result;

  // Update XP and streak on profile
  const profile = data.profiles[profileId];
  const xpGained = score * 10;
  if (profile) {
    profile.xp = (profile.xp ?? 0) + xpGained;
    // Compute streak
    const now = new Date(completedAt);
    const lastDate = profile.lastQuizAt ? new Date(profile.lastQuizAt) : null;
    if (lastDate) {
      const diffDays = Math.floor(
        (now.getTime() - lastDate.getTime()) / (1000 * 60 * 60 * 24),
      );
      if (diffDays === 1) {
        profile.streak = (profile.streak ?? 0) + 1;
      } else if (diffDays > 1) {
        profile.streak = 1;
      }
    } else {
      profile.streak = 1;
    }
    profile.lastQuizAt = completedAt;
    data.profiles[profileId] = profile;
  }
  saveData(data);
  return { xpGained };
}

export async function getQuizResultsForProfile(
  profileId: string,
): Promise<QuizResultDoc[]> {
  const data = loadData();
  return Object.values(data.quizResults).filter(
    (r) => r.profileId === profileId,
  );
}

// Stats API ------------------------------------------------------------------

export async function getStats(profileId: string): Promise<Stats> {
  const data = loadData();
  const profile = data.profiles[profileId];
  const results = Object.values(data.quizResults).filter(
    (r) => r.profileId === profileId,
  );
  const quizzesCompleted = results.length;
  const totalCorrect = results.reduce((sum, r) => sum + r.score, 0);
  const totalQuestions = results.reduce(
    (sum, r) => sum + r.totalQuestions,
    0,
  );
  const accuracy = totalQuestions > 0 ? Math.round((totalCorrect / totalQuestions) * 100) : 0;
  return {
    quizzesCompleted,
    accuracy,
    totalBadges: 0,
    xp: profile?.xp ?? 0,
    streak: profile?.streak ?? 0,
  };
}
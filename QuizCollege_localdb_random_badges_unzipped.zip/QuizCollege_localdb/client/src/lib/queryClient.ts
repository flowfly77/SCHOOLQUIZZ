import { QueryClient } from "@tanstack/react-query";

// In the offline‑first version of the app, network requests to `/api/*` are no longer used.
// Instead, data is stored locally via PouchDB. Therefore, the QueryClient does not
// provide a default `queryFn`; each query should specify its own function that
// interacts with the local database. The default options below disable automatic
// refetching and retries to avoid unnecessary overhead.

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchInterval: false,
      refetchOnWindowFocus: false,
      staleTime: Infinity,
      retry: false,
    },
    mutations: {
      retry: false,
    },
  },
});

// Retain a placeholder API function in case the application needs to perform
// network requests in the future (for example, to synchronise with a remote
// server). Currently, it simply throws an error to signal that no
// network endpoints are available.
export async function apiRequest(
  method: string,
  url: string,
  data?: unknown,
): Promise<Response> {
  throw new Error(
    `apiRequest called with method ${method} and url ${url}, but no API is configured.`,
  );
}

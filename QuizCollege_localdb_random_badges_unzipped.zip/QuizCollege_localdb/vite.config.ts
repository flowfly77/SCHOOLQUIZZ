import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import { fileURLToPath } from 'url';

/**
 * Vite configuration for local development.
 *
 * The original configuration used several Replit-specific plugins
 * (runtime error overlays, cartographer, dev banners) that are not
 * available outside of the Replit environment. Those plugins and
 * their associated dependencies have been removed to simplify
 * running the project in a standard development environment such as
 * VS Code. The remainder of the configuration mirrors the original
 * settings for alias resolution, root paths and build output.
 */
// Resolve the directory name when using ESM. Node's import.meta.url can be
// converted to a file path via fileURLToPath(). Then we compute __dirname
// similarly to CommonJS. Without this, import.meta.dirname is undefined
// in Node 18+ environments, which caused Vite to misinterpret the root
// directory and serve a 404 page.
const __dirname = path.dirname(fileURLToPath(import.meta.url));

export default defineConfig({
  plugins: [
    react(),
    // Note: The Vite PWA plugin has been removed to simplify installation.
    // If you wish to enable service worker support and offline caching,
    // install 'vite-plugin-pwa' and re-enable the plugin here.
  ],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, 'client', 'src'),
      '@shared': path.resolve(__dirname, 'shared'),
      '@assets': path.resolve(__dirname, 'attached_assets'),
    },
  },
  // Set the client directory as the root for the front‑end build. Use the
  // resolved __dirname instead of import.meta.dirname to ensure correctness
  // across Node versions and bundlers.
  root: path.resolve(__dirname, 'client'),
  build: {
    outDir: path.resolve(__dirname, 'dist/public'),
    emptyOutDir: true,
  },
  server: {
    fs: {
      strict: true,
      deny: ["**/.*"],
    },
  },
});
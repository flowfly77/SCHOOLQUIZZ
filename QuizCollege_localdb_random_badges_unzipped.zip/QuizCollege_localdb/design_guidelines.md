# Design Guidelines: Application de Quiz Éducative pour Collégiens

## Design Approach: Reference-Based (Educational Gaming)

**Primary Inspiration**: Duolingo, Kahoot, Quizlet
**Design Philosophy**: Gamified learning with vibrant, youth-friendly aesthetics that make education engaging and rewarding

**Key Design Principles**:
- Playful yet credible visual language that respects student intelligence
- Clear hierarchy prioritizing quiz content and progress feedback
- Reward-driven visual feedback that celebrates achievements
- Responsive, mobile-first design optimized for both phone and tablet use

---

## Core Design Elements

### A. Color Palette

**Light Mode (Primary)**:
- Primary Brand: 262 80% 55% (vibrant purple-blue, main accent)
- Secondary: 142 70% 50% (fresh green, success/correct answers)
- Error/Wrong: 0 75% 60% (friendly red, incorrect answers)
- Neutral Base: 220 15% 97% (soft gray background)
- Card Background: 0 0% 100% (pure white cards)
- Text Primary: 220 20% 15% (near black)
- Text Secondary: 220 15% 45% (medium gray)

**Dark Mode**:
- Primary Brand: 262 75% 60% (slightly brighter purple-blue)
- Secondary: 142 65% 55% (adjusted green)
- Background: 220 20% 12% (dark charcoal)
- Card Background: 220 18% 18% (elevated dark cards)
- Text Primary: 0 0% 95% (off-white)
- Text Secondary: 220 10% 65% (light gray)

**Subject-Specific Accent Colors** (for navigation/categorization):
- Français: 345 80% 60% (warm pink-red)
- Mathématiques: 200 75% 55% (cool blue)
- Histoire-Géo: 35 70% 55% (amber/brown)
- SVT: 142 70% 50% (natural green)
- Physique-Chimie: 280 75% 60% (purple)

### B. Typography

**Font Families** (via Google Fonts):
- Primary (Headings & UI): 'Poppins' - modern, rounded, friendly (weights: 500, 600, 700)
- Secondary (Body): 'Inter' - clean, highly legible (weights: 400, 500, 600)

**Type Scale**:
- Hero/Page Titles: text-4xl md:text-5xl font-bold (Poppins)
- Section Headers: text-2xl md:text-3xl font-semibold (Poppins)
- Card Titles: text-xl font-semibold (Poppins)
- Body Text: text-base leading-relaxed (Inter)
- Small Text/Labels: text-sm (Inter)
- Quiz Questions: text-lg md:text-xl font-medium (Poppins)

### C. Layout System

**Spacing Primitives**: Use Tailwind units of 2, 4, 6, 8, 12, and 16
- Micro spacing (icons, badges): p-2, gap-2
- Component padding: p-4, p-6
- Section spacing: py-8, py-12
- Large gaps: gap-8, mb-12, mt-16

**Grid System**:
- Mobile: Single column, full-width cards with px-4 container
- Tablet/Desktop: 2-3 column grid for subject cards (grid-cols-2 lg:grid-cols-3)
- Quiz interface: Centered max-w-3xl container
- Dashboard: Sidebar navigation (w-64) + main content area

**Responsive Breakpoints**:
- Mobile-first base styles
- md: (768px) for tablet layouts
- lg: (1024px) for desktop optimizations

### D. Component Library

**Navigation Components**:
- Top Navigation Bar: Fixed, elevated with shadow, includes profile avatar and streak counter
- Subject Selection Grid: Large, colorful cards with subject icons and progress rings
- Bottom Tab Bar (mobile): Quick access to Dashboard, Quiz, Profile (fixed bottom-0)

**Quiz Interface Components**:
- Question Card: Elevated white card with shadow-lg, rounded-2xl corners
- Answer Options: Large touch targets (min-h-14), rounded-xl, with hover and selected states
- Progress Bar: Linear gradient fill, animated on progression, displays question X/Total
- Timer (optional): Circular progress indicator for timed quizzes
- Result Feedback: Full-screen celebration animation for correct answers, gentle shake for incorrect

**Gamification Elements**:
- Badge Display: 3D-style badges with metallic gradients (bronze: 35 70% 50%, silver: 0 0% 75%, gold: 45 90% 55%)
- XP/Points Counter: Animated number increments with particle effects
- Streak Indicator: Flame icon with number, pulsing animation on active streak
- Progress Rings: Circular SVG progress (stroke-dasharray animation) around subject icons
- Level Display: Rounded badge with current level number and title (e.g., "Élève Débutant", "Expert")

**Profile & Dashboard**:
- Class Selector: Large pill-shaped buttons (6ème, 5ème, 4ème, 3ème) with active state
- Stats Cards: Grid of metric cards showing total quizzes, accuracy, badges earned
- Achievement Wall: Masonry grid of unlocked badges with hover tooltips
- Recent Activity Feed: Timeline-style list of recent quiz attempts and achievements

**Forms & Inputs**:
- Text Inputs: Rounded-lg borders, focus ring with primary color, generous padding (px-4 py-3)
- Buttons Primary: Rounded-full, gradient background, shadow-md, bold text, min-h-12
- Buttons Secondary: Rounded-full, border-2, transparent background, primary text
- Toggle Switches: Rounded-full track with smooth transition animation

**Data Display**:
- Subject Cards: Gradient background matching subject color, white text, progress indicator
- Quiz Result Summary: Pie chart or bar graph showing performance breakdown
- Leaderboard: Ranked list with medals for top 3, alternating row backgrounds

### E. Animations & Interactions

**Core Animations** (use sparingly):
- Page Transitions: Fade + slide-up (duration-300) for route changes
- Card Hover: Slight lift (transform: translateY(-4px)) with shadow increase
- Success Feedback: Confetti burst animation on quiz completion (using canvas particles)
- Badge Unlock: Scale-up entrance (scale-0 to scale-100) with bounce easing
- Correct Answer: Green checkmark with scale animation + subtle success sound
- Wrong Answer: Red X with horizontal shake (animate-shake custom keyframe)
- Loading States: Skeleton screens with shimmer effect (not spinners)

**Micro-interactions**:
- Button press: Scale down slightly (active:scale-95)
- Toggle switch: Smooth background color transition (transition-colors duration-200)
- Progress updates: Number count-up animation for XP gains
- Streak flame: Pulse animation on active days

**Performance Considerations**:
- Use CSS transforms and opacity for animations (GPU-accelerated)
- Limit simultaneous animations to 3 maximum
- Prefer transitions over keyframe animations where possible
- Use will-change sparingly and remove after animation

---

## Page-Specific Layouts

**Landing/Welcome Screen**:
- Full-screen hero with playful illustration (students with books, quiz bubbles)
- Large headline: "Apprends en t'amusant !" with animated gradient text
- CTA buttons: "Créer mon profil" (primary) and "En savoir plus" (ghost)
- Floating badge elements in background with parallax effect

**Profile Creation Flow**:
- Multi-step wizard (3 steps: Name, Class selection, Avatar)
- Large class selector buttons in 2x2 grid (6ème-5ème / 4ème-3ème)
- Visual progress indicator showing current step
- Smooth slide transitions between steps

**Main Dashboard**:
- Header: Welcome message, streak counter, XP bar
- Subject Grid: 2-3 columns of subject cards with radial progress
- Quick Stats: Row of 3-4 metric cards (quizzes completed, accuracy, rank)
- Recent Badges: Horizontal scrollable list of latest achievements

**Quiz Screen**:
- Minimalist layout focusing on question
- Full-width question card at top with progress bar
- Answer options stacked vertically with ample spacing (gap-4)
- Action buttons (submit, skip) at bottom
- Exit modal with "Abandonner" confirmation to prevent accidental exits

**Badge Collection**:
- Hero section with total badges count and completion percentage
- Grid layout showing all badges (earned in color, locked in grayscale with lock icon)
- Filter options: By subject, By difficulty, All
- Detailed modal on badge click showing unlock criteria and date earned

---

## Images & Visual Assets

**Required Images**:
1. **Landing Hero Image**: Illustration of diverse French students engaged in fun quiz activities - colorful, energetic, inclusive representation (full-width, h-[60vh])
2. **Subject Icons**: Custom icon set for each subject using Heroicons as base, colored with subject-specific palette
3. **Badge Graphics**: Design 12-15 unique badge illustrations (SVG format) representing different achievement types
4. **Empty States**: Friendly illustrations for "no quizzes taken yet", "no badges earned", etc.
5. **Avatar Options**: 8-10 customizable student avatar illustrations for profile selection

**Icon Library**: Heroicons (via CDN) for all UI icons - use outline variant for navigation, solid for active states

---

## Responsive Behavior

- Mobile (320px-767px): Single column, bottom navigation, full-width quiz cards
- Tablet (768px-1023px): 2-column subject grid, side drawer navigation option
- Desktop (1024px+): 3-column layouts, persistent sidebar, hover states enabled

**Touch Targets**: Minimum 44px height for all interactive elements on mobile

**Accessibility**: WCAG AA contrast ratios, keyboard navigation support, screen reader labels on all icons, reduced motion preferences respected
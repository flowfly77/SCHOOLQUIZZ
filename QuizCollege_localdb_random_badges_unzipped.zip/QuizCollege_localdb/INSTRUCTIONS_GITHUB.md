# 🚀 Instructions pour Pousser sur GitHub

## Méthode 1 : Via le Shell Replit (Recommandée)

1. **Ouvrez le Shell** dans Replit (en bas de l'écran ou Ctrl+`)

2. **Exécutez ces commandes une par une** :

```bash
# Initialiser git (si pas déjà fait)
git init

# Ajouter tous les fichiers
git add .

# Créer le commit
git commit -m "🎉 QuizCollège - Application complète avec 32,400 questions"

# Configurer la branche main
git branch -M main

# Ajouter le remote avec votre token
git remote add origin https://flowfly77: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@github.com/flowfly77/SCHOOLQUIZZ.git

# Pousser vers GitHub
git push -u origin main --force
```

3. **Vérifiez sur GitHub** : https://github.com/flowfly77/SCHOOLQUIZZ

---

## Méthode 2 : Si le repository existe déjà

```bash
# Si vous avez déjà des fichiers sur GitHub
git pull origin main --allow-unrelated-histories

# Puis pousser
git push -u origin main
```

---

## Méthode 3 : Télécharger et Pousser Manuellement

Si les commandes Git ne fonctionnent pas dans Replit :

1. **Téléchargez le projet** depuis Replit (trois points en haut > Download as ZIP)

2. **Décompressez le ZIP** sur votre ordinateur

3. **Ouvrez un terminal** dans le dossier décompressé

4. **Exécutez** :

```bash
git init
git add .
git commit -m "🎉 QuizCollège - Application complète"
git branch -M main
git remote add origin https://github.com/flowfly77/SCHOOLQUIZZ.git
git push -u origin main --force
```

---

## ⚠️ Note de Sécurité

**Important** : Votre token GitHub est visible dans ces instructions. Après avoir poussé le code :

1. **Allez sur GitHub** : Settings → Developer settings → Personal access tokens
2. **Révoquez** le token actuel
3. **Créez un nouveau token** pour une utilisation future

---

## ✅ Vérification

Une fois le push terminé, vous devriez voir :
- ✅ Tous les fichiers sur GitHub
- ✅ Le README.md affiché sur la page d'accueil
- ✅ Les 32,400 questions dans les fichiers de seed

---

## 🆘 Problèmes Courants

### "Permission denied"
→ Vérifiez que votre token a les permissions `repo`

### "Already exists"  
→ Utilisez `--force` dans la commande push

### "Not a git repository"
→ Réexécutez `git init`

---

**Besoin d'aide ?** Contactez le support GitHub ou consultez la documentation Git.

# QuizCollège - Application de Quiz Éducative

## 📚 Vue d'ensemble

QuizCollège est une application de quiz interactive conçue pour les collégiens français (de la 6ème à la 3ème). L'application couvre toutes les matières du programme scolaire avec un système de badges et de progression pour motiver l'apprentissage.

## 🎯 Fonctionnalités

### Matières disponibles (8 au total):
1. **Français** - Littérature, grammaire, conjugaison
2. **Mathématiques** - Nombres, géométrie, algèbre
3. **Histoire-Géographie** - De la Préhistoire au monde contemporain
4. **SVT** - Sciences de la Vie et de la Terre
5. **Physique-Chimie** - Matière, énergie, électricité
6. **Technologie** - Programmation, robotique, innovation
7. **Anglais** - Langue vivante étrangère (LV1)
8. **EMC** - Éducation Morale et Civique

### Système de progression:
- 108 chapitres adaptés au niveau de classe (6ème à 3ème)
- 180+ questions générées avec explications détaillées
- Système de difficulté (facile, moyen, difficile)
- Points XP et niveaux de progression
- Séries de jours consécutifs (streaks)

### Système de badges:
- 10 badges différents (bronze, argent, or)
- Critères basés sur la performance (score parfait, quiz complétés, etc.)
- Badges par matière et badges généraux

## 🏗️ Architecture technique

### Frontend:
- **React** avec TypeScript
- **Wouter** pour le routing
- **TanStack Query** pour la gestion des données
- **Tailwind CSS** + **Shadcn UI** pour le design
- **Framer Motion** pour les animations

### Backend:
- **Express.js** serveur API REST
- **PostgreSQL** (Neon) base de données
- **Drizzle ORM** pour les requêtes SQL
- **Zod** pour la validation des données

### Structure de la base de données:
```
users → profiles (nom, classe, XP, streak)
subjects (matières)
chapters (chapitres par matière/niveau)
questions (questions avec options et explications)
quiz_results (résultats des quiz)
user_progress (progression par chapitre)
badges + user_badges (système de badges)
```

## 🚀 Développement

### Scripts disponibles:
- `npm run dev` - Lance l'application en mode développement
- `npm run db:push` - Synchronise le schéma DB
- `npm run db:studio` - Ouvre Drizzle Studio (interface DB)

### Seed de la base de données:
1. Initialiser les matières et chapitres: `npx tsx server/run-seed.ts`
2. Générer les questions: `npx tsx server/run-seed-questions.ts`

## 📊 État actuel

### ✅ Implémenté:
- Schéma de base de données complet
- 8 matières avec 108 chapitres
- 180 questions réparties sur 9 chapitres
- 10 badges configurés
- Routes API backend complètes
- Interface utilisateur de base (accueil, profil, quiz, dashboard)
- Système de thème dark/light

### 🚧 En cours:
- Connexion frontend ↔ backend
- Sélection de chapitres par matière/niveau
- Statistiques détaillées
- Système de déblocage automatique des badges

## 🎨 Design

### Palette de couleurs:
- **Primary**: Violet-bleu vibrant (262° 80% 55%)
- **Success**: Vert frais (142° 70% 50%)
- **Error**: Rouge amical (0° 75% 60%)

### Couleurs par matière:
- Français: Rose-rouge (345° 80% 60%)
- Mathématiques: Bleu cool (200° 75% 55%)
- Histoire-Géo: Ambre (35° 70% 55%)
- SVT: Vert naturel (142° 70% 50%)
- Physique-Chimie: Violet (280° 75% 60%)

### Badges:
- Bronze: 35° 70% 50%
- Argent: 0° 0% 75%
- Or: 45° 90% 55%

## 📝 Notes de développement

### Workflow de développement:
1. Modifier le schéma dans `shared/schema.ts`
2. Exécuter `npm run db:push` pour mettre à jour la DB
3. Tester les routes dans `server/routes.ts`
4. Créer les composants React dans `client/src/components`
5. Utiliser TanStack Query pour les appels API

### Bonnes pratiques:
- Toujours typer les données avec les types générés depuis le schéma
- Utiliser les composants Shadcn UI existants
- Respecter les couleurs définies dans `index.css`
- Ajouter des `data-testid` pour faciliter les tests

## 🔐 Environnement

Variables d'environnement requises:
- `DATABASE_URL` - Connexion PostgreSQL (fournie par Replit)
- `SESSION_SECRET` - Secret pour les sessions (généré automatiquement)

## 📚 Ressources

- [Design Guidelines](design_guidelines.md) - Guide complet du design
- [Drizzle ORM](https://orm.drizzle.team) - Documentation ORM
- [Shadcn UI](https://ui.shadcn.com) - Composants UI
- [TanStack Query](https://tanstack.com/query) - Data fetching

## 🎯 Prochaines étapes

1. Finaliser la connexion frontend-backend
2. Implémenter la sélection de chapitres avec filtres
3. Créer les pages de statistiques détaillées
4. Ajouter le système automatique de déblocage de badges
5. Générer plus de questions (objectif: 200 par chapitre)
6. Ajouter des fonctionnalités sociales (classements, défis)

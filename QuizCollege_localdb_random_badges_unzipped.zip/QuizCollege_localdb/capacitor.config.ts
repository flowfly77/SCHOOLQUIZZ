import { CapacitorConfig } from '@capacitor/cli';

/**
 * Capacitor configuration file
 *
 * This file defines the basic metadata required by Capacitor to build native
 * applications. The `appId` should be a globally unique identifier using
 * reverse‑domain notation (for example, `com.example.quizcollege`). The
 * `appName` corresponds to the human‑readable name of your application. The
 * `webDir` field must point to the directory where your web assets are built.
 * In this project, the Vite build output is written to `dist/public`, as
 * configured in `vite.config.ts`. Set `bundledWebRuntime` to `false` to
 * include only the Capacitor runtime without the Ionic wrapper.
 */
const config: CapacitorConfig = {
  appId: 'com.example.quizcollege',
  appName: 'QuizCollège',
  webDir: 'dist/public',
  bundledWebRuntime: false,
};

export default config;
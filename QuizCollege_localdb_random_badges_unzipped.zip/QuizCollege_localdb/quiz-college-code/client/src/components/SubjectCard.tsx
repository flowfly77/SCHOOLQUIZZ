import { LucideIcon } from "lucide-react";
import { motion } from "framer-motion";

interface SubjectCardProps {
  name: string;
  icon: LucideIcon;
  progress: number;
  color: "francais" | "math" | "histoire" | "svt" | "physique";
  onClick?: () => void;
}

export function SubjectCard({ name, icon: Icon, progress, color, onClick }: SubjectCardProps) {
  const colorClasses = {
    francais: "bg-subject-francais text-subject-francais-foreground",
    math: "bg-subject-math text-subject-math-foreground",
    histoire: "bg-subject-histoire text-subject-histoire-foreground",
    svt: "bg-subject-svt text-subject-svt-foreground",
    physique: "bg-subject-physique text-subject-physique-foreground",
  };

  return (
    <motion.button
      whileHover={{ y: -4 }}
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      className={`relative p-6 rounded-2xl ${colorClasses[color]} text-left w-full overflow-hidden group`}
      data-testid={`card-subject-${name.toLowerCase()}`}
    >
      <div className="absolute top-0 right-0 w-32 h-32 opacity-20">
        <Icon className="w-full h-full" />
      </div>

      <div className="relative z-10 space-y-4">
        <div className="flex items-start justify-between">
          <div className="p-3 rounded-xl bg-white/20 backdrop-blur-sm">
            <Icon className="w-6 h-6" />
          </div>
          <div className="text-right">
            <div className="text-2xl font-bold">{progress}%</div>
            <div className="text-sm opacity-90">Complété</div>
          </div>
        </div>

        <h3 className="text-xl font-semibold">{name}</h3>

        <div className="w-full bg-white/20 rounded-full h-2 overflow-hidden">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="h-full bg-white/80 rounded-full"
          />
        </div>
      </div>
    </motion.button>
  );
}

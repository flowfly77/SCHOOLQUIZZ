import { Book, Beaker, Globe, Calculator, TestTube, Trophy, Target, Award } from "lucide-react";
import { SubjectCard } from "./SubjectCard";
import { StatsCard } from "./StatsCard";
import { BadgeDisplay } from "./BadgeDisplay";
import { ProfileHeader } from "./ProfileHeader";
import { ThemeToggle } from "./ThemeToggle";
import { motion } from "framer-motion";

interface DashboardProps {
  userName: string;
  userGrade: string;
  onSubjectClick?: (subject: string) => void;
}

export function Dashboard({ userName, userGrade, onSubjectClick }: DashboardProps) {
  //todo: remove mock functionality
  const subjects = [
    { name: "Français", icon: Book, progress: 45, color: "francais" as const },
    { name: "Mathématiques", icon: Calculator, progress: 60, color: "math" as const },
    { name: "Histoire-Géo", icon: Globe, progress: 30, color: "histoire" as const },
    { name: "SVT", icon: TestTube, progress: 50, color: "svt" as const },
    { name: "Physique-Chimie", icon: Beaker, progress: 25, color: "physique" as const },
  ];

  //todo: remove mock functionality
  const badges = [
    { type: "gold" as const, title: "Champion Quiz", description: "10 quiz parfaits", unlocked: true, unlockedDate: "12 Oct 2025" },
    { type: "silver" as const, title: "Curieux", description: "5 matières testées", unlocked: true, unlockedDate: "10 Oct 2025" },
    { type: "bronze" as const, title: "Débutant", description: "Premier quiz terminé", unlocked: true, unlockedDate: "8 Oct 2025" },
    { type: "gold" as const, title: "Expert Maths", description: "100% en maths", unlocked: false },
  ];

  return (
    <div className="min-h-screen bg-background">
      <div className="sticky top-0 z-50 bg-card border-b border-border">
        <div className="container mx-auto px-4">
          <div className="flex items-center justify-between py-4">
            <h1 className="text-2xl font-bold gradient-text-primary">QuizCollège</h1>
            <ThemeToggle />
          </div>
        </div>
      </div>

      <ProfileHeader name={userName} grade={userGrade} streak={7} xp={1250} />

      <div className="container mx-auto px-4 py-8 space-y-12">
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-4"
        >
          <h2 className="text-2xl font-bold">Mes Statistiques</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <StatsCard title="Quiz Complétés" value={24} icon={Trophy} description="+3 cette semaine" />
            <StatsCard title="Précision" value="78%" icon={Target} description="Moyenne générale" />
            <StatsCard title="Badges" value={3} icon={Award} description="Sur 15 disponibles" />
          </div>
        </motion.section>

        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="space-y-4"
        >
          <h2 className="text-2xl font-bold">Mes Matières</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {subjects.map((subject, index) => (
              <motion.div
                key={subject.name}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 * index }}
              >
                <SubjectCard
                  {...subject}
                  onClick={() => onSubjectClick?.(subject.name)}
                />
              </motion.div>
            ))}
          </div>
        </motion.section>

        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="space-y-4"
        >
          <h2 className="text-2xl font-bold">Mes Badges</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {badges.map((badge, index) => (
              <BadgeDisplay key={index} {...badge} />
            ))}
          </div>
        </motion.section>
      </div>
    </div>
  );
}

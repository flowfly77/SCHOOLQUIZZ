import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { motion } from "framer-motion";
import { ArrowRight, User } from "lucide-react";

interface ProfileCreationProps {
  onComplete: (name: string, grade: string) => void;
}

type Grade = "6ème" | "5ème" | "4ème" | "3ème";

const grades: Grade[] = ["6ème", "5ème", "4ème", "3ème"];

export function ProfileCreation({ onComplete }: ProfileCreationProps) {
  const [step, setStep] = useState<1 | 2>(1);
  const [name, setName] = useState("");
  const [selectedGrade, setSelectedGrade] = useState<Grade | null>(null);

  const handleNext = () => {
    if (step === 1 && name.trim()) {
      setStep(2);
    } else if (step === 2 && selectedGrade) {
      onComplete(name, selectedGrade);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md space-y-8"
      >
        <div className="text-center space-y-2">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-4">
            <User className="w-8 h-8 text-primary" />
          </div>
          <h2 className="text-3xl font-bold">
            {step === 1 ? "Comment t'appelles-tu ?" : "En quelle classe es-tu ?"}
          </h2>
          <p className="text-muted-foreground">
            {step === 1 ? "Entre ton prénom pour commencer" : "Sélectionne ta classe au collège"}
          </p>
        </div>

        {step === 1 ? (
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-4"
          >
            <div className="space-y-2">
              <Label htmlFor="name">Prénom</Label>
              <Input
                id="name"
                type="text"
                placeholder="Entre ton prénom"
                value={name}
                onChange={(e) => setName(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleNext()}
                data-testid="input-name"
                className="text-lg py-6"
              />
            </div>
            <Button
              size="lg"
              className="w-full rounded-full"
              onClick={handleNext}
              disabled={!name.trim()}
              data-testid="button-next-step"
            >
              Suivant
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </motion.div>
        ) : (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-6"
          >
            <div className="grid grid-cols-2 gap-4">
              {grades.map((grade) => (
                <button
                  key={grade}
                  onClick={() => setSelectedGrade(grade)}
                  className={`p-6 rounded-2xl border-2 transition-all hover-elevate ${
                    selectedGrade === grade
                      ? "border-primary bg-primary/5"
                      : "border-border bg-card"
                  }`}
                  data-testid={`button-grade-${grade}`}
                >
                  <div className="text-3xl font-bold text-primary mb-2">{grade}</div>
                  <div className="text-sm text-muted-foreground">Collège</div>
                </button>
              ))}
            </div>
            <div className="flex gap-3">
              <Button
                variant="outline"
                size="lg"
                className="flex-1 rounded-full"
                onClick={() => setStep(1)}
                data-testid="button-back"
              >
                Retour
              </Button>
              <Button
                size="lg"
                className="flex-1 rounded-full"
                onClick={handleNext}
                disabled={!selectedGrade}
                data-testid="button-complete"
              >
                Commencer
              </Button>
            </div>
          </motion.div>
        )}

        <div className="flex justify-center gap-2">
          <div className={`w-2 h-2 rounded-full ${step === 1 ? "bg-primary" : "bg-muted"}`} />
          <div className={`w-2 h-2 rounded-full ${step === 2 ? "bg-primary" : "bg-muted"}`} />
        </div>
      </motion.div>
    </div>
  );
}

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { CheckCircle, XCircle } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

interface QuizQuestionProps {
  question: string;
  options: string[];
  correctAnswer: number;
  questionNumber: number;
  totalQuestions: number;
  onAnswer: (isCorrect: boolean) => void;
}

export function QuizQuestion({
  question,
  options,
  correctAnswer,
  questionNumber,
  totalQuestions,
  onAnswer,
}: QuizQuestionProps) {
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);

  const handleSubmit = () => {
    if (selectedAnswer === null) return;
    
    const isCorrect = selectedAnswer === correctAnswer;
    setShowResult(true);
    
    setTimeout(() => {
      onAnswer(isCorrect);
      setSelectedAnswer(null);
      setShowResult(false);
    }, 1500);
  };

  return (
    <div className="w-full max-w-3xl mx-auto space-y-6">
      <div className="space-y-2">
        <div className="flex items-center justify-between text-sm text-muted-foreground">
          <span>Question {questionNumber}/{totalQuestions}</span>
          <div className="w-32 bg-muted rounded-full h-2">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${(questionNumber / totalQuestions) * 100}%` }}
              className="h-full bg-primary rounded-full"
            />
          </div>
        </div>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="p-8 rounded-2xl bg-card border border-card-border"
      >
        <h3 className="text-xl md:text-2xl font-semibold mb-6">{question}</h3>

        <div className="space-y-3">
          {options.map((option, index) => (
            <motion.button
              key={index}
              whileTap={{ scale: 0.98 }}
              onClick={() => !showResult && setSelectedAnswer(index)}
              disabled={showResult}
              className={`w-full p-4 rounded-xl border-2 text-left transition-all ${
                selectedAnswer === index
                  ? showResult
                    ? index === correctAnswer
                      ? "border-success bg-success/10 text-success"
                      : "border-destructive bg-destructive/10 text-destructive animate-shake"
                    : "border-primary bg-primary/5"
                  : showResult && index === correctAnswer
                  ? "border-success bg-success/10 text-success"
                  : "border-border hover-elevate"
              } ${showResult ? "pointer-events-none" : ""}`}
              data-testid={`option-${index}`}
            >
              <div className="flex items-center justify-between">
                <span className="font-medium">{option}</span>
                <AnimatePresence>
                  {showResult && (
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      exit={{ scale: 0 }}
                    >
                      {index === correctAnswer ? (
                        <CheckCircle className="w-5 h-5 text-success" />
                      ) : (
                        selectedAnswer === index && <XCircle className="w-5 h-5 text-destructive" />
                      )}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </motion.button>
          ))}
        </div>

        <Button
          size="lg"
          className="w-full mt-6 rounded-full"
          onClick={handleSubmit}
          disabled={selectedAnswer === null || showResult}
          data-testid="button-submit-answer"
        >
          {showResult ? "Chargement..." : "Valider ma réponse"}
        </Button>
      </motion.div>
    </div>
  );
}

import { Flame, Star } from "lucide-react";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

interface ProfileHeaderProps {
  name: string;
  grade: string;
  streak: number;
  xp: number;
}

export function ProfileHeader({ name, grade, streak, xp }: ProfileHeaderProps) {
  return (
    <div className="flex items-center justify-between p-6 bg-card border-b border-border">
      <div className="flex items-center gap-4">
        <Avatar className="w-12 h-12">
          <AvatarFallback className="bg-primary text-primary-foreground text-lg font-semibold">
            {name.charAt(0).toUpperCase()}
          </AvatarFallback>
        </Avatar>
        <div>
          <h2 className="font-semibold text-lg" data-testid="text-user-name">{name}</h2>
          <p className="text-sm text-muted-foreground" data-testid="text-user-grade">{grade}</p>
        </div>
      </div>

      <div className="flex items-center gap-6">
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-lg bg-badge-gold/20">
            <Flame className="w-5 h-5 text-badge-gold" />
          </div>
          <div>
            <div className="text-lg font-bold" data-testid="text-streak">{streak}</div>
            <div className="text-xs text-muted-foreground">jours</div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <div className="p-2 rounded-lg bg-primary/20">
            <Star className="w-5 h-5 text-primary" />
          </div>
          <div>
            <div className="text-lg font-bold" data-testid="text-xp">{xp}</div>
            <div className="text-xs text-muted-foreground">XP</div>
          </div>
        </div>
      </div>
    </div>
  );
}

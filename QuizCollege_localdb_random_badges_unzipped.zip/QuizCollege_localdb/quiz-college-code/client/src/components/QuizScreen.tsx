import { useState } from "react";
import { QuizQuestion } from "./QuizQuestion";
import { Button } from "@/components/ui/button";
import { X, Trophy } from "lucide-react";
import { motion } from "framer-motion";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface QuizScreenProps {
  subject: string;
  onExit: () => void;
}

export function QuizScreen({ subject, onExit }: QuizScreenProps) {
  //todo: remove mock functionality
  const questions = [
    {
      question: "Quel est le résultat de 5 × 8 ?",
      options: ["35", "40", "45", "50"],
      correctAnswer: 1,
    },
    {
      question: "Combien font 100 - 37 ?",
      options: ["53", "63", "73", "83"],
      correctAnswer: 1,
    },
    {
      question: "Quelle est la valeur de 12 ÷ 3 ?",
      options: ["2", "3", "4", "5"],
      correctAnswer: 2,
    },
  ];

  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [showExitDialog, setShowExitDialog] = useState(false);
  const [isComplete, setIsComplete] = useState(false);

  const handleAnswer = (isCorrect: boolean) => {
    if (isCorrect) {
      setScore(score + 1);
    }

    if (currentQuestion + 1 < questions.length) {
      setCurrentQuestion(currentQuestion + 1);
    } else {
      setIsComplete(true);
    }
  };

  const handleExit = () => {
    setShowExitDialog(true);
  };

  const percentage = Math.round((score / questions.length) * 100);

  if (isComplete) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          className="max-w-md w-full text-center space-y-6"
        >
          <div className="inline-flex items-center justify-center w-24 h-24 rounded-full gradient-bg-success mb-4">
            <Trophy className="w-12 h-12 text-white" />
          </div>

          <h2 className="text-3xl font-bold">Quiz Terminé !</h2>
          
          <div className="p-8 rounded-2xl bg-card border border-card-border space-y-4">
            <div className="text-5xl font-bold text-primary">{percentage}%</div>
            <p className="text-muted-foreground">
              Tu as répondu correctement à {score} questions sur {questions.length}
            </p>

            {percentage >= 80 && (
              <div className="p-4 rounded-xl bg-badge-gold/20 border border-badge-gold/30">
                <p className="text-sm font-medium text-badge-gold">
                  🎉 Excellent ! Tu as débloqué un nouveau badge !
                </p>
              </div>
            )}
          </div>

          <Button
            size="lg"
            className="w-full rounded-full"
            onClick={onExit}
            data-testid="button-finish-quiz"
          >
            Retour au tableau de bord
          </Button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="sticky top-0 z-50 bg-card border-b border-border">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <h1 className="text-xl font-bold">{subject}</h1>
          <Button
            variant="ghost"
            size="icon"
            onClick={handleExit}
            data-testid="button-exit-quiz"
          >
            <X className="w-5 h-5" />
          </Button>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <QuizQuestion
          question={questions[currentQuestion].question}
          options={questions[currentQuestion].options}
          correctAnswer={questions[currentQuestion].correctAnswer}
          questionNumber={currentQuestion + 1}
          totalQuestions={questions.length}
          onAnswer={handleAnswer}
        />
      </div>

      <AlertDialog open={showExitDialog} onOpenChange={setShowExitDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Quitter le quiz ?</AlertDialogTitle>
            <AlertDialogDescription>
              Ta progression actuelle ne sera pas sauvegardée. Es-tu sûr de vouloir abandonner ?
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-testid="button-cancel-exit">Continuer le quiz</AlertDialogCancel>
            <AlertDialogAction onClick={onExit} data-testid="button-confirm-exit">
              Abandonner
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

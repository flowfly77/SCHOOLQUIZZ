import { useState } from "react";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/components/ThemeProvider";
import { WelcomeScreen } from "@/components/WelcomeScreen";
import { ProfileCreation } from "@/components/ProfileCreation";
import { Dashboard } from "@/components/Dashboard";
import { QuizScreen } from "@/components/QuizScreen";

type AppState = "welcome" | "profile" | "dashboard" | "quiz";

function App() {
  const [appState, setAppState] = useState<AppState>("welcome");
  const [userName, setUserName] = useState("");
  const [userGrade, setUserGrade] = useState("");
  const [selectedSubject, setSelectedSubject] = useState("");

  const handleGetStarted = () => {
    setAppState("profile");
  };

  const handleProfileComplete = (name: string, grade: string) => {
    setUserName(name);
    setUserGrade(grade);
    setAppState("dashboard");
  };

  const handleSubjectClick = (subject: string) => {
    setSelectedSubject(subject);
    setAppState("quiz");
  };

  const handleQuizExit = () => {
    setAppState("dashboard");
  };

  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider>
        <TooltipProvider>
          {appState === "welcome" && (
            <WelcomeScreen onGetStarted={handleGetStarted} />
          )}
          
          {appState === "profile" && (
            <ProfileCreation onComplete={handleProfileComplete} />
          )}
          
          {appState === "dashboard" && (
            <Dashboard
              userName={userName}
              userGrade={userGrade}
              onSubjectClick={handleSubjectClick}
            />
          )}
          
          {appState === "quiz" && (
            <QuizScreen
              subject={selectedSubject}
              onExit={handleQuizExit}
            />
          )}
          
          <Toaster />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;

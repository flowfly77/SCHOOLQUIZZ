import { db } from "./db";
import { subjects, chapters, questions, badges, users } from "@shared/schema";

const subjectsData = [
  {
    name: "Français",
    slug: "francais",
    color: "francais",
    icon: "Book",
    description: "Lecture, écriture, grammaire et littérature"
  },
  {
    name: "Mathématiques",
    slug: "mathematiques",
    color: "math",
    icon: "Calculator",
    description: "Nombres, calcul, géométrie et algèbre"
  },
  {
    name: "Géographie",
    slug: "geographie",
    color: "histoire",
    icon: "Map",
    description: "Étude des territoires et des sociétés"
  },
  {
    name: "Histoire",
    slug: "histoire",
    color: "histoire",
    icon: "Clock",
    description: "De l'Antiquité au monde contemporain"
  },
  {
    name: "Sciences",
    slug: "sciences",
    color: "svt",
    icon: "Beaker",
    description: "Sciences pour la 6ème"
  },
  {
    name: "SVT",
    slug: "svt",
    color: "svt",
    icon: "TestTube",
    description: "Sciences de la Vie et de la Terre"
  },
  {
    name: "Physique-Chimie",
    slug: "physique-chimie",
    color: "physique",
    icon: "Atom",
    description: "Matière, énergie et transformations"
  },
  {
    name: "Anglais",
    slug: "anglais",
    color: "francais",
    icon: "MessageCircle",
    description: "Langue vivante étrangère 1"
  },
  {
    name: "Italien",
    slug: "italien",
    color: "math",
    icon: "Globe2",
    description: "Langue vivante étrangère 2"
  },
  {
    name: "Musique",
    slug: "musique",
    color: "physique",
    icon: "Music",
    description: "Éducation musicale"
  },
];

const chaptersData: Record<string, Record<string, { title: string; slug: string; description: string }[]>> = {
  "francais": {
    "6ème": [
      { title: "Le Monstre, aux limites de l'humain", slug: "monstre-limites-humain", description: "Mythologie grecque et romaine, L'Odyssée" },
      { title: "Récits d'aventures", slug: "recits-aventures", description: "Exploration, contes merveilleux, romans" },
      { title: "Récits de création et poésie", slug: "recits-creation-poesie", description: "Poèmes sur la création, mythes" },
      { title: "Résister au plus fort", slug: "resister-au-plus-fort", description: "Fables, ruse et mensonges" },
      { title: "Grammaire et conjugaison", slug: "grammaire-conjugaison-6eme", description: "Classes grammaticales, temps verbaux" },
    ],
    "5ème": [
      { title: "Le voyage et l'aventure", slug: "voyage-aventure", description: "Marco Polo, Grandes Découvertes" },
      { title: "Vivre en société", slug: "vivre-en-societe", description: "Théâtre de Molière, comédies" },
      { title: "Imaginer des mondes", slug: "imaginer-mondes", description: "Littérature jeunesse, poésie" },
      { title: "Héros et héroïsme", slug: "heros-heroisme", description: "Chevaliers, romans médiévaux" },
      { title: "Grammaire et style", slug: "grammaire-style-5eme", description: "Figures de style, conjugaison avancée" },
    ],
    "4ème": [
      { title: "Dire l'amour", slug: "dire-amour", description: "Poésie lyrique à travers les siècles" },
      { title: "Confrontations de valeurs", slug: "confrontations-valeurs", description: "Nouvelles, satire sociale" },
      { title: "Informer, s'informer, déformer", slug: "informer-sinformer", description: "Presse et médias" },
      { title: "Fiction et réel", slug: "fiction-reel", description: "Roman naturaliste, nouvelle fantastique" },
      { title: "Orthographe et grammaire avancées", slug: "orthographe-grammaire-4eme", description: "Accords complexes, analyse" },
    ],
    "3ème": [
      { title: "Se raconter, se représenter", slug: "se-raconter", description: "Autobiographie, identité" },
      { title: "Dénoncer les travers", slug: "denoncer-travers", description: "Poésie engagée, argumentation" },
      { title: "Visions poétiques", slug: "visions-poetiques", description: "Poésie moderne et contemporaine" },
      { title: "Agir dans la cité", slug: "agir-cite", description: "Engagement citoyen" },
      { title: "Préparation au Brevet", slug: "preparation-brevet", description: "Analyse, rédaction, oral" },
    ],
  },
  "mathematiques": {
    "6ème": [
      { title: "Nombres décimaux", slug: "nombres-decimaux", description: "Addition, soustraction, multiplication" },
      { title: "Fractions", slug: "fractions-6eme", description: "Fractions simples, équivalences" },
      { title: "Géométrie plane", slug: "geometrie-plane-6eme", description: "Figures, symétrie" },
      { title: "Mesures", slug: "mesures-6eme", description: "Périmètres, aires, volumes" },
      { title: "Résolution de problèmes", slug: "resolution-problemes-6eme", description: "Logique et raisonnement" },
    ],
    "5ème": [
      { title: "Nombres relatifs", slug: "nombres-relatifs", description: "Opérations sur les relatifs" },
      { title: "Proportionnalité", slug: "proportionnalite-5eme", description: "Pourcentages, échelles" },
      { title: "Triangles", slug: "triangles-5eme", description: "Construction, propriétés" },
      { title: "Statistiques", slug: "statistiques-5eme", description: "Moyennes, graphiques" },
      { title: "Calcul littéral", slug: "calcul-litteral-5eme", description: "Introduction aux expressions" },
    ],
    "4ème": [
      { title: "Théorème de Pythagore", slug: "theoreme-pythagore", description: "Application et démonstration" },
      { title: "Puissances", slug: "puissances-4eme", description: "Notation scientifique" },
      { title: "Calcul littéral avancé", slug: "calcul-litteral-4eme", description: "Développement, factorisation" },
      { title: "Géométrie dans l'espace", slug: "geometrie-espace-4eme", description: "Volumes, sections" },
      { title: "Probabilités", slug: "probabilites-4eme", description: "Calcul de probabilités" },
    ],
    "3ème": [
      { title: "Théorème de Thalès", slug: "theoreme-thales", description: "Proportionnalité et calculs" },
      { title: "Fonctions", slug: "fonctions-3eme", description: "Fonctions linéaires, affines" },
      { title: "Trigonométrie", slug: "trigonometrie", description: "Cosinus, sinus, tangente" },
      { title: "Algorithmique", slug: "algorithmique-3eme", description: "Python, programmation" },
      { title: "Brevet blanc", slug: "brevet-blanc-maths", description: "Préparation examen" },
    ],
  },
  "geographie": {
    "6ème": [
      { title: "Habiter la Terre", slug: "habiter-terre", description: "Différents espaces de vie" },
      { title: "Habiter une métropole", slug: "habiter-metropole", description: "Villes du monde" },
      { title: "Habiter un espace rural", slug: "habiter-rural", description: "Campagnes et agriculture" },
      { title: "Habiter les littoraux", slug: "habiter-littoraux", description: "Zones côtières" },
    ],
    "5ème": [
      { title: "Développement durable", slug: "developpement-durable", description: "Enjeux environnementaux" },
      { title: "Les ressources", slug: "ressources-5eme", description: "Eau, énergie, alimentation" },
      { title: "Changement global", slug: "changement-global", description: "Climat et environnement" },
    ],
    "4ème": [
      { title: "Mondialisation", slug: "mondialisation", description: "Échanges et flux" },
      { title: "Urbanisation", slug: "urbanisation", description: "Croissance des villes" },
      { title: "Espaces productifs", slug: "espaces-productifs", description: "Agriculture, industrie, services" },
    ],
    "3ème": [
      { title: "La France", slug: "france-territoire", description: "Organisation du territoire" },
      { title: "Union européenne", slug: "union-europeenne", description: "Construction européenne" },
      { title: "Aménagement du territoire", slug: "amenagement-territoire", description: "Politiques publiques" },
    ],
  },
  "histoire": {
    "6ème": [
      { title: "La Préhistoire", slug: "prehistoire-6eme", description: "Des premiers hommes" },
      { title: "L'Antiquité - Égypte", slug: "antiquite-egypte", description: "Civilisation égyptienne" },
      { title: "L'Antiquité - Grèce", slug: "antiquite-grece", description: "Cités grecques" },
      { title: "L'Antiquité - Rome", slug: "antiquite-rome", description: "Empire romain" },
    ],
    "5ème": [
      { title: "Le Moyen Âge", slug: "moyen-age", description: "Féodalité et royauté" },
      { title: "L'Islam", slug: "islam-medieval", description: "Naissance et expansion" },
      { title: "Humanisme et Renaissance", slug: "humanisme-renaissance", description: "XVe-XVIe siècles" },
    ],
    "4ème": [
      { title: "XVIIIe siècle - Lumières", slug: "lumieres-18e", description: "Philosophes et idées nouvelles" },
      { title: "Révolution française", slug: "revolution-francaise", description: "1789-1799" },
      { title: "Premier Empire", slug: "premier-empire", description: "Napoléon Bonaparte" },
      { title: "XIXe siècle", slug: "19e-siecle", description: "Révolutions et industrialisation" },
    ],
    "3ème": [
      { title: "Première Guerre mondiale", slug: "premiere-guerre-mondiale", description: "1914-1918" },
      { title: "Entre-deux-guerres", slug: "entre-deux-guerres", description: "Régimes totalitaires" },
      { title: "Seconde Guerre mondiale", slug: "seconde-guerre-mondiale", description: "1939-1945" },
      { title: "Guerre froide", slug: "guerre-froide", description: "Monde bipolaire" },
      { title: "Monde contemporain", slug: "monde-contemporain", description: "Depuis 1991" },
    ],
  },
  "sciences": {
    "6ème": [
      { title: "Unité et diversité du vivant", slug: "unite-diversite-vivant", description: "Classification" },
      { title: "L'environnement", slug: "environnement-6eme", description: "Écosystèmes" },
      { title: "États de la matière", slug: "etats-matiere", description: "Solide, liquide, gaz" },
      { title: "Circuits électriques", slug: "circuits-electriques-6eme", description: "Électricité simple" },
    ],
  },
  "svt": {
    "5ème": [
      { title: "Corps humain - Respiration", slug: "respiration-5eme", description: "Système respiratoire" },
      { title: "Corps humain - Circulation", slug: "circulation-5eme", description: "Système circulatoire" },
      { title: "Corps humain - Digestion", slug: "digestion-5eme", description: "Système digestif" },
      { title: "Géologie", slug: "geologie-5eme", description: "Roches et relief" },
    ],
    "4ème": [
      { title: "Reproduction", slug: "reproduction-4eme", description: "Reproduction humaine" },
      { title: "Transmission génétique", slug: "transmission-genetique", description: "Hérédité" },
      { title: "Relations alimentaires", slug: "relations-alimentaires", description: "Chaînes alimentaires" },
      { title: "Tectonique des plaques", slug: "tectonique-plaques", description: "Mouvements terrestres" },
    ],
    "3ème": [
      { title: "Évolution", slug: "evolution-3eme", description: "Théorie de l'évolution" },
      { title: "Immunologie", slug: "immunologie", description: "Système immunitaire" },
      { title: "Génétique", slug: "genetique-3eme", description: "ADN et chromosomes" },
      { title: "Planète Terre", slug: "planete-terre", description: "Environnement global" },
    ],
  },
  "physique-chimie": {
    "5ème": [
      { title: "L'eau", slug: "eau-5eme", description: "États et changements" },
      { title: "Électricité", slug: "electricite-5eme", description: "Circuits et courant" },
      { title: "Lumière", slug: "lumiere-5eme", description: "Propagation et réflexion" },
    ],
    "4ème": [
      { title: "Molécules", slug: "molecules-4eme", description: "Structure de la matière" },
      { title: "Transformations chimiques", slug: "transformations-chimiques", description: "Réactions" },
      { title: "Énergie", slug: "energie-4eme", description: "Formes et conversions" },
    ],
    "3ème": [
      { title: "Ions et pH", slug: "ions-ph", description: "Solutions acides/basiques" },
      { title: "Mécanique", slug: "mecanique-3eme", description: "Forces et mouvements" },
      { title: "Énergie et électricité", slug: "energie-electricite-3eme", description: "Production électrique" },
    ],
  },
  "anglais": {
    "6ème": [
      { title: "Présentations", slug: "presentations-6eme", description: "Se présenter, saluer" },
      { title: "La famille", slug: "famille-anglais", description: "Family members" },
      { title: "Les nombres", slug: "nombres-anglais", description: "Numbers 1-100" },
      { title: "Les couleurs", slug: "couleurs-anglais", description: "Colors" },
    ],
    "5ème": [
      { title: "Daily routine", slug: "daily-routine", description: "Routine quotidienne" },
      { title: "Food and drinks", slug: "food-drinks", description: "Alimentation" },
      { title: "School subjects", slug: "school-subjects", description: "Matières scolaires" },
      { title: "Past simple", slug: "past-simple", description: "Passé simple" },
    ],
    "4ème": [
      { title: "Sports and hobbies", slug: "sports-hobbies", description: "Loisirs" },
      { title: "Present perfect", slug: "present-perfect", description: "Présent parfait" },
      { title: "Comparatives", slug: "comparatives", description: "Comparatifs" },
      { title: "Future tenses", slug: "future-tenses", description: "Futurs" },
    ],
    "3ème": [
      { title: "Conditional", slug: "conditional", description: "Conditionnel" },
      { title: "Passive voice", slug: "passive-voice", description: "Voix passive" },
      { title: "Reported speech", slug: "reported-speech", description: "Discours indirect" },
      { title: "Advanced vocabulary", slug: "advanced-vocabulary", description: "Vocabulaire avancé" },
    ],
  },
  "italien": {
    "6ème": [
      { title: "Presentazioni", slug: "presentazioni-italiano", description: "Se présenter en italien" },
      { title: "I numeri", slug: "numeri-italiano", description: "Les nombres" },
      { title: "La famiglia", slug: "famiglia-italiano", description: "La famille" },
    ],
    "5ème": [
      { title: "La vita quotidiana", slug: "vita-quotidiana", description: "Vie quotidienne" },
      { title: "Il cibo", slug: "cibo-italiano", description: "La nourriture" },
      { title: "Presente indicativo", slug: "presente-indicativo", description: "Présent de l'indicatif" },
    ],
    "4ème": [
      { title: "Sport e tempo libero", slug: "sport-tempo-libero", description: "Sports et loisirs" },
      { title: "Passato prossimo", slug: "passato-prossimo", description: "Passé composé" },
      { title: "La città", slug: "citta-italiano", description: "La ville" },
    ],
    "3ème": [
      { title: "Il futuro", slug: "futuro-italiano", description: "Le futur" },
      { title: "Il congiuntivo", slug: "congiuntivo", description: "Le subjonctif" },
      { title: "Cultura italiana", slug: "cultura-italiana", description: "Culture italienne" },
    ],
  },
  "musique": {
    "6ème": [
      { title: "Découverte des instruments", slug: "decouverte-instruments", description: "Familles d'instruments" },
      { title: "Le rythme", slug: "rythme-musique", description: "Tempo et mesures" },
      { title: "La mélodie", slug: "melodie-6eme", description: "Notes et gammes" },
    ],
    "5ème": [
      { title: "Histoire de la musique", slug: "histoire-musique", description: "Époques musicales" },
      { title: "Musiques du monde", slug: "musiques-monde", description: "Traditions musicales" },
      { title: "Le chant", slug: "chant-5eme", description: "Technique vocale" },
    ],
    "4ème": [
      { title: "Musique et image", slug: "musique-image", description: "Musique de film" },
      { title: "Musiques actuelles", slug: "musiques-actuelles", description: "Pop, rock, rap" },
      { title: "Harmonie", slug: "harmonie-4eme", description: "Accords et tonalités" },
    ],
    "3ème": [
      { title: "Musique et société", slug: "musique-societe", description: "Engagements musicaux" },
      { title: "Création musicale", slug: "creation-musicale", description: "Composition" },
      { title: "Analyse musicale", slug: "analyse-musicale", description: "Étude d'œuvres" },
    ],
  },
};

export async function seedCompleteDatabase() {
  try {
    console.log("🌱 Démarrage du seeding complet...\n");
    
    // Créer un utilisateur par défaut
    console.log("👤 Création de l'utilisateur par défaut...");
    const [defaultUser] = await db.insert(users).values({
      id: "default-user",
      username: "default",
      password: "default",
    }).onConflictDoNothing().returning();
    console.log(defaultUser ? "  ✓ Utilisateur créé" : "  ℹ Utilisateur déjà existant");
    
    // Insérer les matières
    console.log("\n📚 Insertion des matières...");
    const insertedSubjects: Record<string, any> = {};
    
    for (const subject of subjectsData) {
      const [inserted] = await db.insert(subjects).values(subject).onConflictDoNothing().returning();
      if (inserted) {
        insertedSubjects[subject.slug] = inserted;
        console.log(`  ✓ ${subject.name}`);
      }
    }
    
    // Insérer les chapitres
    console.log("\n📖 Insertion des chapitres...");
    const insertedChapters: any[] = [];
    
    for (const [subjectSlug, gradeData] of Object.entries(chaptersData)) {
      const subject = insertedSubjects[subjectSlug];
      if (!subject) continue;
      
      for (const [grade, chaptersList] of Object.entries(gradeData)) {
        let order = 1;
        for (const chapter of chaptersList) {
          const [inserted] = await db.insert(chapters).values({
            subjectId: subject.id,
            grade,
            title: chapter.title,
            slug: chapter.slug,
            order,
            description: chapter.description,
          }).onConflictDoNothing().returning();
          
          if (inserted) {
            insertedChapters.push(inserted);
            console.log(`  ✓ ${grade} - ${subject.name}: ${chapter.title}`);
          }
          order++;
        }
      }
    }
    
    console.log(`\n✅ Seeding complet terminé !`);
    console.log(`📊 Statistiques:`);
    console.log(`   - ${Object.keys(insertedSubjects).length} matières`);
    console.log(`   - ${insertedChapters.length} chapitres`);
    
  } catch (error) {
    console.error("❌ Erreur lors du seeding:", error);
    throw error;
  }
}

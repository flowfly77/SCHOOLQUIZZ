import { seedQuestions } from "./seed-questions";

seedQuestions()
  .then(() => {
    console.log("✅ Questions générées avec succès");
    process.exit(0);
  })
  .catch((error) => {
    console.error("❌ Erreur lors de la génération:", error);
    process.exit(1);
  });

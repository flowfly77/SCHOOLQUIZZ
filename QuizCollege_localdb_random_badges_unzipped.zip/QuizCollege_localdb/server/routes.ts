import type { Express } from "express";
import { createServer, type Server } from "http";
import { db } from "./db";
import { 
  profiles, subjects, chapters, questions, quizResults, 
  userProgress, badges, userBadges,
  insertProfileSchema, insertQuizResultSchema, insertUserProgressSchema
} from "@shared/schema";
import { eq, and, desc, sql } from "drizzle-orm";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // ==================== PROFILES ====================
  
  // Lister tous les profils
  app.get("/api/profiles", async (req, res) => {
    try {
      const allProfiles = await db.select().from(profiles).orderBy(desc(profiles.createdAt));
      res.json(allProfiles);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });
  
  // Créer un profil
  app.post("/api/profiles", async (req, res) => {
    try {
      const data = insertProfileSchema.parse(req.body);
      const [profile] = await db.insert(profiles).values(data).returning();
      res.json(profile);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Obtenir un profil par ID
  app.get("/api/profiles/:id", async (req, res) => {
    try {
      const [profile] = await db
        .select()
        .from(profiles)
        .where(eq(profiles.id, req.params.id));
      
      if (!profile) {
        return res.status(404).json({ error: "Profil non trouvé" });
      }
      
      res.json(profile);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Mettre à jour XP et streak
  app.patch("/api/profiles/:id/stats", async (req, res) => {
    try {
      const { xp, streak } = req.body;
      const [updated] = await db
        .update(profiles)
        .set({ xp, streak })
        .where(eq(profiles.id, req.params.id))
        .returning();
      
      res.json(updated);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Mettre à jour le profil (nom, classe, etc.)
  app.patch("/api/profiles/:id", async (req, res) => {
    try {
      const updates: any = {};
      if (req.body.name) updates.name = req.body.name;
      if (req.body.grade) updates.grade = req.body.grade;
      
      const [updated] = await db
        .update(profiles)
        .set(updates)
        .where(eq(profiles.id, req.params.id))
        .returning();
      
      if (!updated) {
        return res.status(404).json({ error: "Profil non trouvé" });
      }
      
      res.json(updated);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Réinitialiser les statistiques d'un profil
  app.patch("/api/profiles/:id/reset", async (req, res) => {
    try {
      // Réinitialiser XP et streak
      const [updated] = await db
        .update(profiles)
        .set({ xp: 0, streak: 0 })
        .where(eq(profiles.id, req.params.id))
        .returning();
      
      if (!updated) {
        return res.status(404).json({ error: "Profil non trouvé" });
      }

      // Supprimer la progression de l'utilisateur
      await db.delete(userProgress).where(eq(userProgress.profileId, req.params.id));

      // Supprimer les résultats de quiz
      await db.delete(quizResults).where(eq(quizResults.profileId, req.params.id));

      // Supprimer les badges
      await db.delete(userBadges).where(eq(userBadges.profileId, req.params.id));
      
      res.json(updated);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Supprimer un profil
  app.delete("/api/profiles/:id", async (req, res) => {
    try {
      // Supprimer d'abord toutes les données associées
      await db.delete(userProgress).where(eq(userProgress.profileId, req.params.id));
      await db.delete(quizResults).where(eq(quizResults.profileId, req.params.id));
      await db.delete(userBadges).where(eq(userBadges.profileId, req.params.id));

      // Supprimer le profil
      const [deleted] = await db
        .delete(profiles)
        .where(eq(profiles.id, req.params.id))
        .returning();
      
      if (!deleted) {
        return res.status(404).json({ error: "Profil non trouvé" });
      }
      
      res.json({ message: "Profil supprimé avec succès" });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ==================== MATIÈRES ====================
  
  // Lister toutes les matières (filtrées par classe)
  app.get("/api/subjects", async (req, res) => {
    try {
      const { grade } = req.query;
      let allSubjects = await db.select().from(subjects);
      
      // Filtrer les matières selon la classe
      if (grade) {
        const gradeStr = grade as string;
        allSubjects = allSubjects.filter(subject => {
          // Pour la 6ème : exclure EMC, SVT, Physique-Chimie, Technologie, Espagnol (garder Sciences)
          if (gradeStr === '6ème') {
            return !['emc', 'svt', 'physique-chimie', 'technologie', 'espagnol'].includes(subject.slug);
          }
          // Pour 5ème, 4ème, 3ème : exclure Sciences (garder SVT, Physique-Chimie, Techno, EMC, Espagnol)
          else {
            return subject.slug !== 'sciences';
          }
        });
      }
      
      // Ne retourner que les matières qui ont des questions
      const subjectsWithQuestions = await Promise.all(
        allSubjects.map(async (subject) => {
          const [count] = await db
            .select({ count: sql<number>`count(*)` })
            .from(questions)
            .where(
              and(
                eq(questions.subjectId, subject.id),
                grade ? eq(questions.grade, grade as string) : undefined
              )
            );
          
          return { 
            subject, 
            hasQuestions: Number(count.count) > 0,
            // Déterminer l'ordre : Culture Pop et Capitales du Monde en dernier
            order: ['culture-pop', 'capitales'].includes(subject.slug) ? 2 : 1
          };
        })
      );
      
      const filteredSubjects = subjectsWithQuestions
        .filter(({ hasQuestions }) => hasQuestions)
        .sort((a, b) => {
          // Trier par ordre (1 avant 2), puis par nom
          if (a.order !== b.order) return a.order - b.order;
          return a.subject.name.localeCompare(b.subject.name);
        })
        .map(({ subject }) => subject);
      
      res.json(filteredSubjects);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Obtenir une matière par slug
  app.get("/api/subjects/:slug", async (req, res) => {
    try {
      const [subject] = await db
        .select()
        .from(subjects)
        .where(eq(subjects.slug, req.params.slug));
      
      if (!subject) {
        return res.status(404).json({ error: "Matière non trouvée" });
      }
      
      res.json(subject);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ==================== CHAPITRES ====================
  
  // Lister les chapitres par matière et niveau
  app.get("/api/chapters", async (req, res) => {
    try {
      const { subjectId, grade } = req.query;
      const conditions = [];
      
      if (subjectId) {
        conditions.push(eq(chapters.subjectId, subjectId as string));
      }
      
      if (grade) {
        conditions.push(eq(chapters.grade, grade as string));
      }
      
      const allChapters = conditions.length > 0
        ? await db.select().from(chapters).where(and(...conditions))
        : await db.select().from(chapters);
      
      res.json(allChapters);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Obtenir un chapitre par ID
  app.get("/api/chapters/:id", async (req, res) => {
    try {
      const [chapter] = await db
        .select()
        .from(chapters)
        .where(eq(chapters.id, req.params.id));
      
      if (!chapter) {
        return res.status(404).json({ error: "Chapitre non trouvé" });
      }
      
      res.json(chapter);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ==================== QUESTIONS ====================
  
  // Note: Routes for chapter-based questions removed as we use subject-based questions directly

  // Obtenir des questions aléatoires pour une matière et une classe (20 par défaut)
  app.get("/api/questions/subject/:subjectId", async (req, res) => {
    try {
      const { grade, limit = "20", difficulty } = req.query;
      const conditions = [eq(questions.subjectId, req.params.subjectId)];
      
      if (grade) {
        conditions.push(eq(questions.grade, grade as string));
      }
      
      if (difficulty) {
        conditions.push(eq(questions.difficulty, difficulty as string));
      }
      
      // Récupérer toutes les questions de la matière pour cette classe
      const allQuestions = await db
        .select()
        .from(questions)
        .where(and(...conditions));
      
      // Mélanger les questions de manière aléatoire
      const shuffled = allQuestions.sort(() => Math.random() - 0.5);
      
      // Retourner seulement le nombre demandé
      res.json(shuffled.slice(0, parseInt(limit as string)));
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ==================== RÉSULTATS DE QUIZ ====================
  
  // Enregistrer un résultat de quiz
  app.post("/api/quiz-results", async (req, res) => {
    try {
      const data = insertQuizResultSchema.parse(req.body);
      const [result] = await db.insert(quizResults).values(data).returning();
      
      // Mettre à jour la progression de l'utilisateur
      const [existing] = await db
        .select()
        .from(userProgress)
        .where(
          and(
            eq(userProgress.profileId, data.profileId),
            eq(userProgress.subjectId, data.subjectId)
          )
        );
      
      if (existing) {
        await db
          .update(userProgress)
          .set({
            questionsAnswered: existing.questionsAnswered + data.totalQuestions,
            questionsCorrect: existing.questionsCorrect + data.score,
            lastAttempt: new Date(),
            completed: data.score === data.totalQuestions,
          })
          .where(eq(userProgress.id, existing.id));
      } else {
        await db.insert(userProgress).values({
          profileId: data.profileId,
          subjectId: data.subjectId,
          questionsAnswered: data.totalQuestions,
          questionsCorrect: data.score,
          lastAttempt: new Date(),
          completed: data.score === data.totalQuestions,
        });
      }
      
      // Ajouter XP au profil
      const xpGained = data.score * 100;
      await db
        .update(profiles)
        .set({
          xp: sql`${profiles.xp} + ${xpGained}`,
        })
        .where(eq(profiles.id, data.profileId));
      
      res.json({ ...result, xpGained });
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // Obtenir les résultats d'un profil
  app.get("/api/quiz-results/profile/:profileId", async (req, res) => {
    try {
      const results = await db
        .select()
        .from(quizResults)
        .where(eq(quizResults.profileId, req.params.profileId))
        .orderBy(desc(quizResults.completedAt));
      
      res.json(results);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ==================== PROGRESSION ====================
  
  // Obtenir la progression d'un profil
  app.get("/api/progress/:profileId", async (req, res) => {
    try {
      const progress = await db
        .select()
        .from(userProgress)
        .where(eq(userProgress.profileId, req.params.profileId));
      
      res.json(progress);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Obtenir la progression par matière
  app.get("/api/progress/:profileId/subject/:subjectId", async (req, res) => {
    try {
      const progress = await db
        .select()
        .from(userProgress)
        .where(
          and(
            eq(userProgress.profileId, req.params.profileId),
            eq(userProgress.subjectId, req.params.subjectId)
          )
        );
      
      res.json(progress);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // ==================== BADGES ====================
  
  // Lister tous les badges
  app.get("/api/badges", async (req, res) => {
    try {
      const allBadges = await db.select().from(badges);
      res.json(allBadges);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Obtenir les badges d'un profil
  app.get("/api/badges/profile/:profileId", async (req, res) => {
    try {
      const userBadgesList = await db
        .select({
          userBadge: userBadges,
          badge: badges,
        })
        .from(userBadges)
        .leftJoin(badges, eq(userBadges.badgeId, badges.id))
        .where(eq(userBadges.profileId, req.params.profileId));
      
      res.json(userBadgesList);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Débloquer un badge
  app.post("/api/badges/unlock", async (req, res) => {
    try {
      const { profileId, badgeId } = req.body;
      
      // Vérifier si le badge est déjà débloqué
      const [existing] = await db
        .select()
        .from(userBadges)
        .where(
          and(
            eq(userBadges.profileId, profileId),
            eq(userBadges.badgeId, badgeId)
          )
        );
      
      if (existing) {
        return res.status(400).json({ error: "Badge déjà débloqué" });
      }
      
      const [userBadge] = await db
        .insert(userBadges)
        .values({ profileId, badgeId })
        .returning();
      
      res.json(userBadge);
    } catch (error: any) {
      res.status(400).json({ error: error.message });
    }
  });

  // ==================== STATISTIQUES ====================
  
  // Obtenir les statistiques globales d'un profil
  app.get("/api/stats/:profileId", async (req, res) => {
    try {
      const [profile] = await db
        .select()
        .from(profiles)
        .where(eq(profiles.id, req.params.profileId));
      
      if (!profile) {
        return res.status(404).json({ error: "Profil non trouvé" });
      }
      
      // Nombre total de quiz
      const [quizCount] = await db
        .select({ count: sql<number>`count(*)` })
        .from(quizResults)
        .where(eq(quizResults.profileId, req.params.profileId));
      
      // Précision moyenne
      const [accuracy] = await db
        .select({
          avg: sql<number>`COALESCE(AVG(CAST(score AS FLOAT) / NULLIF(total_questions, 0) * 100), 0)`,
        })
        .from(quizResults)
        .where(eq(quizResults.profileId, req.params.profileId));
      
      // Nombre de badges
      const [badgeCount] = await db
        .select({ count: sql<number>`count(*)` })
        .from(userBadges)
        .where(eq(userBadges.profileId, req.params.profileId));
      
      res.json({
        quizzesCompleted: quizCount.count || 0,
        accuracy: Math.round(accuracy.avg || 0),
        totalBadges: badgeCount.count || 0,
        xp: profile.xp,
        streak: profile.streak,
      });
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

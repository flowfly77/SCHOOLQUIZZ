import { db } from "./db";
import { questions, chapters } from "@shared/schema";
import { eq } from "drizzle-orm";

// Exemple de questions par matière
const questionTemplates = {
  mathematiques: {
    "6ème": {
      "nombres-entiers": [
        { question: "Combien font 347 + 289 ?", options: ["526", "536", "636", "646"], correctAnswer: 2, difficulty: "facile", explanation: "347 + 289 = 636" },
        { question: "Quel est le résultat de 1250 - 475 ?", options: ["775", "785", "875", "885"], correctAnswer: 0, difficulty: "facile", explanation: "1250 - 475 = 775" },
        { question: "Combien font 25 × 4 ?", options: ["90", "95", "100", "105"], correctAnswer: 2, difficulty: "facile", explanation: "25 × 4 = 100" },
        { question: "Quel est le résultat de 144 ÷ 12 ?", options: ["10", "11", "12", "13"], correctAnswer: 2, difficulty: "facile", explanation: "144 ÷ 12 = 12" },
        { question: "Quelle est la valeur de 5² ?", options: ["10", "15", "20", "25"], correctAnswer: 3, difficulty: "moyen", explanation: "5² = 5 × 5 = 25" },
        { question: "Combien font 789 + 456 + 123 ?", options: ["1258", "1268", "1358", "1368"], correctAnswer: 3, difficulty: "moyen", explanation: "789 + 456 + 123 = 1368" },
        { question: "Quel est le double de 145 ?", options: ["280", "290", "300", "310"], correctAnswer: 1, difficulty: "facile", explanation: "145 × 2 = 290" },
        { question: "Combien font 8 × 9 ?", options: ["63", "72", "81", "90"], correctAnswer: 1, difficulty: "facile", explanation: "8 × 9 = 72" },
        { question: "Quel est le résultat de 450 ÷ 15 ?", options: ["25", "30", "35", "40"], correctAnswer: 1, difficulty: "moyen", explanation: "450 ÷ 15 = 30" },
        { question: "Combien font 12 × 12 ?", options: ["124", "134", "144", "154"], correctAnswer: 2, difficulty: "facile", explanation: "12 × 12 = 144" },
        { question: "Quelle est la moitié de 1800 ?", options: ["800", "850", "900", "950"], correctAnswer: 2, difficulty: "facile", explanation: "1800 ÷ 2 = 900" },
        { question: "Quel nombre multiplié par 7 donne 63 ?", options: ["7", "8", "9", "10"], correctAnswer: 2, difficulty: "moyen", explanation: "63 ÷ 7 = 9" },
        { question: "Combien font 999 + 1 ?", options: ["900", "990", "1000", "1100"], correctAnswer: 2, difficulty: "facile", explanation: "999 + 1 = 1000" },
        { question: "Quel est le triple de 45 ?", options: ["125", "135", "145", "155"], correctAnswer: 1, difficulty: "moyen", explanation: "45 × 3 = 135" },
        { question: "Combien font 15 × 6 ?", options: ["80", "85", "90", "95"], correctAnswer: 2, difficulty: "facile", explanation: "15 × 6 = 90" },
        { question: "Quel est le résultat de 2000 - 1234 ?", options: ["666", "756", "766", "866"], correctAnswer: 2, difficulty: "moyen", explanation: "2000 - 1234 = 766" },
        { question: "Combien font 20 × 8 ?", options: ["140", "150", "160", "170"], correctAnswer: 2, difficulty: "facile", explanation: "20 × 8 = 160" },
        { question: "Quel est le quart de 100 ?", options: ["20", "25", "30", "35"], correctAnswer: 1, difficulty: "facile", explanation: "100 ÷ 4 = 25" },
        { question: "Combien font 125 × 8 ?", options: ["900", "950", "1000", "1050"], correctAnswer: 2, difficulty: "moyen", explanation: "125 × 8 = 1000" },
        { question: "Quel est le résultat de 360 ÷ 9 ?", options: ["35", "40", "45", "50"], correctAnswer: 1, difficulty: "moyen", explanation: "360 ÷ 9 = 40" },
      ],
      "fractions-6eme": [
        { question: "Quelle fraction représente la moitié ?", options: ["1/3", "1/2", "1/4", "2/3"], correctAnswer: 1, difficulty: "facile", explanation: "La moitié = 1/2" },
        { question: "Combien font 1/4 + 1/4 ?", options: ["1/8", "1/4", "1/2", "2/4"], correctAnswer: 2, difficulty: "facile", explanation: "1/4 + 1/4 = 2/4 = 1/2" },
        { question: "Quelle est la fraction équivalente à 2/4 ?", options: ["1/8", "1/4", "1/2", "3/4"], correctAnswer: 2, difficulty: "moyen", explanation: "2/4 = 1/2 (simplification)" },
        { question: "Combien font 3/5 - 1/5 ?", options: ["1/5", "2/5", "3/5", "4/5"], correctAnswer: 1, difficulty: "facile", explanation: "3/5 - 1/5 = 2/5" },
        { question: "Quelle fraction est plus grande : 1/3 ou 1/4 ?", options: ["1/3", "1/4", "Égales", "Impossible"], correctAnswer: 0, difficulty: "moyen", explanation: "1/3 est plus grand que 1/4" },
        { question: "Combien font 2/3 + 1/3 ?", options: ["1/3", "2/3", "3/3", "4/3"], correctAnswer: 2, difficulty: "facile", explanation: "2/3 + 1/3 = 3/3 = 1" },
        { question: "Quelle est la fraction simplifiée de 4/8 ?", options: ["1/4", "1/2", "2/3", "3/4"], correctAnswer: 1, difficulty: "moyen", explanation: "4/8 = 1/2" },
        { question: "Combien font 5/6 - 2/6 ?", options: ["1/6", "2/6", "3/6", "4/6"], correctAnswer: 2, difficulty: "facile", explanation: "5/6 - 2/6 = 3/6 = 1/2" },
        { question: "Quelle fraction représente le quart ?", options: ["1/2", "1/3", "1/4", "1/5"], correctAnswer: 2, difficulty: "facile", explanation: "Le quart = 1/4" },
        { question: "Combien font 1/2 + 1/4 ?", options: ["1/4", "1/2", "3/4", "1"], correctAnswer: 2, difficulty: "moyen", explanation: "1/2 + 1/4 = 2/4 + 1/4 = 3/4" },
        { question: "Quelle fraction de 12 est 3 ?", options: ["1/2", "1/3", "1/4", "1/5"], correctAnswer: 2, difficulty: "moyen", explanation: "3/12 = 1/4" },
        { question: "Combien font 7/10 - 3/10 ?", options: ["2/10", "3/10", "4/10", "5/10"], correctAnswer: 2, difficulty: "facile", explanation: "7/10 - 3/10 = 4/10 = 2/5" },
        { question: "Quelle est la forme simplifiée de 6/9 ?", options: ["1/3", "2/3", "3/4", "4/5"], correctAnswer: 1, difficulty: "moyen", explanation: "6/9 = 2/3" },
        { question: "Combien font 2/5 + 2/5 ?", options: ["2/5", "3/5", "4/5", "5/5"], correctAnswer: 2, difficulty: "facile", explanation: "2/5 + 2/5 = 4/5" },
        { question: "Quelle fraction est égale à 0,5 ?", options: ["1/3", "1/2", "1/4", "2/3"], correctAnswer: 1, difficulty: "moyen", explanation: "0,5 = 1/2" },
        { question: "Combien font 3/4 - 1/4 ?", options: ["1/4", "1/2", "2/4", "3/4"], correctAnswer: 1, difficulty: "facile", explanation: "3/4 - 1/4 = 2/4 = 1/2" },
        { question: "Quelle fraction de 20 est 5 ?", options: ["1/2", "1/3", "1/4", "1/5"], correctAnswer: 2, difficulty: "moyen", explanation: "5/20 = 1/4" },
        { question: "Combien font 4/6 + 1/6 ?", options: ["3/6", "4/6", "5/6", "6/6"], correctAnswer: 2, difficulty: "facile", explanation: "4/6 + 1/6 = 5/6" },
        { question: "Quelle est la fraction simplifiée de 10/15 ?", options: ["1/2", "2/3", "3/4", "4/5"], correctAnswer: 1, difficulty: "difficile", explanation: "10/15 = 2/3" },
        { question: "Combien font 9/10 - 4/10 ?", options: ["3/10", "4/10", "5/10", "6/10"], correctAnswer: 2, difficulty: "facile", explanation: "9/10 - 4/10 = 5/10 = 1/2" },
      ],
    },
  },
  francais: {
    "6ème": {
      "grammaire-6eme": [
        { question: "Quel est le verbe dans la phrase : 'Le chat dort sur le canapé' ?", options: ["Le", "chat", "dort", "canapé"], correctAnswer: 2, difficulty: "facile", explanation: "Le verbe est 'dort' (action)" },
        { question: "Quel est le sujet de : 'Les enfants jouent dehors' ?", options: ["Les", "enfants", "jouent", "dehors"], correctAnswer: 1, difficulty: "facile", explanation: "Le sujet est 'Les enfants'" },
        { question: "Quel type de mot est 'rapidement' ?", options: ["Nom", "Verbe", "Adjectif", "Adverbe"], correctAnswer: 3, difficulty: "moyen", explanation: "'rapidement' est un adverbe (modifie le verbe)" },
        { question: "Quel est le COD dans : 'Je mange une pomme' ?", options: ["Je", "mange", "une", "une pomme"], correctAnswer: 3, difficulty: "moyen", explanation: "Le COD est 'une pomme' (ce que je mange)" },
        { question: "Quel est le pluriel de 'cheval' ?", options: ["chevals", "chevaux", "chevaus", "chevalx"], correctAnswer: 1, difficulty: "facile", explanation: "Le pluriel de cheval est chevaux" },
        { question: "Quelle est la nature de 'beau' dans 'un beau jardin' ?", options: ["Nom", "Verbe", "Adjectif", "Adverbe"], correctAnswer: 2, difficulty: "facile", explanation: "'beau' est un adjectif qualificatif" },
        { question: "Quel est le féminin de 'acteur' ?", options: ["acteure", "actrice", "acteure", "acteuse"], correctAnswer: 1, difficulty: "facile", explanation: "Le féminin d'acteur est actrice" },
        { question: "Dans quelle phrase le verbe est au présent ?", options: ["Il parlait", "Il parle", "Il parlera", "Il a parlé"], correctAnswer: 1, difficulty: "facile", explanation: "'Il parle' est au présent" },
        { question: "Quel est le contraire de 'grand' ?", options: ["large", "petit", "haut", "long"], correctAnswer: 1, difficulty: "facile", explanation: "Le contraire de grand est petit" },
        { question: "Quelle phrase est correcte ?", options: ["Les chiens aboies", "Les chiens aboient", "Les chiens aboie", "Les chiens aboyent"], correctAnswer: 1, difficulty: "moyen", explanation: "'Les chiens aboient' est correct (3e personne pluriel)" },
        { question: "Quel est le genre de 'voiture' ?", options: ["Masculin", "Féminin", "Neutre", "Les deux"], correctAnswer: 1, difficulty: "facile", explanation: "'voiture' est féminin (la voiture)" },
        { question: "Quelle est la fonction de 'à Paris' dans : 'Il va à Paris' ?", options: ["Sujet", "COD", "CCL", "COI"], correctAnswer: 2, difficulty: "moyen", explanation: "'à Paris' est un complément circonstanciel de lieu" },
        { question: "Quel est le pluriel de 'œil' ?", options: ["œils", "œilles", "yeux", "œux"], correctAnswer: 2, difficulty: "moyen", explanation: "Le pluriel irrégulier de œil est yeux" },
        { question: "Dans 'Elle chante bien', 'bien' est un :", options: ["Nom", "Verbe", "Adjectif", "Adverbe"], correctAnswer: 3, difficulty: "facile", explanation: "'bien' est un adverbe (modifie chante)" },
        { question: "Quel temps est utilisé : 'J'ai mangé' ?", options: ["Présent", "Imparfait", "Passé composé", "Futur"], correctAnswer: 2, difficulty: "moyen", explanation: "'J'ai mangé' est au passé composé" },
        { question: "Quelle phrase contient un COI ?", options: ["Je vois Paul", "Je parle à Paul", "Paul est grand", "Je cours vite"], correctAnswer: 1, difficulty: "difficile", explanation: "'à Paul' est un COI (parler à quelqu'un)" },
        { question: "Quel est le féminin de 'directeur' ?", options: ["directeure", "directrice", "directeuse", "directeure"], correctAnswer: 1, difficulty: "facile", explanation: "Le féminin de directeur est directrice" },
        { question: "Combien y a-t-il de temps simples en français ?", options: ["3", "4", "5", "6"], correctAnswer: 2, difficulty: "difficile", explanation: "Il y a 5 temps simples (présent, imparfait, passé simple, futur, conditionnel)" },
        { question: "Quelle est la nature de 'et' ?", options: ["Préposition", "Conjonction", "Adverbe", "Pronom"], correctAnswer: 1, difficulty: "moyen", explanation: "'et' est une conjonction de coordination" },
        { question: "Dans 'Le livre de Marie', 'de Marie' est :", options: ["Sujet", "COD", "CDN", "CCL"], correctAnswer: 2, difficulty: "moyen", explanation: "'de Marie' est un complément du nom" },
      ],
    },
  },
  svt: {
    "6ème": {
      "environnement": [
        { question: "Qu'est-ce qu'un écosystème ?", options: ["Un animal", "Un ensemble d'êtres vivants", "Une plante", "Un rocher"], correctAnswer: 1, difficulty: "facile", explanation: "Un écosystème est un ensemble d'êtres vivants et leur milieu" },
        { question: "Quel est le rôle des producteurs dans une chaîne alimentaire ?", options: ["Manger", "Produire", "Chasser", "Dormir"], correctAnswer: 1, difficulty: "moyen", explanation: "Les producteurs (plantes) produisent leur propre nourriture" },
        { question: "Les plantes sont-elles des producteurs ou des consommateurs ?", options: ["Producteurs", "Consommateurs", "Les deux", "Ni l'un ni l'autre"], correctAnswer: 0, difficulty: "facile", explanation: "Les plantes sont des producteurs (photosynthèse)" },
        { question: "Qu'est-ce que la biodiversité ?", options: ["Un seul type", "Variété du vivant", "Un animal", "Une plante"], correctAnswer: 1, difficulty: "facile", explanation: "La biodiversité est la variété des êtres vivants" },
        { question: "Quel gaz les plantes absorbent-elles ?", options: ["Oxygène", "Azote", "CO2", "Hydrogène"], correctAnswer: 2, difficulty: "moyen", explanation: "Les plantes absorbent le CO2 pour la photosynthèse" },
        { question: "Qu'est-ce qu'un herbivore ?", options: ["Mange viande", "Mange plantes", "Mange tout", "Ne mange pas"], correctAnswer: 1, difficulty: "facile", explanation: "Un herbivore mange des plantes" },
        { question: "Quel est le premier maillon d'une chaîne alimentaire ?", options: ["Carnivore", "Herbivore", "Producteur", "Décomposeur"], correctAnswer: 2, difficulty: "moyen", explanation: "Le producteur (plante) est le premier maillon" },
        { question: "Que signifie 'décomposeur' ?", options: ["Qui décompose", "Qui compose", "Qui mange", "Qui court"], correctAnswer: 0, difficulty: "facile", explanation: "Les décomposeurs recyclent la matière morte" },
        { question: "L'eau est-elle un élément biotique ou abiotique ?", options: ["Biotique", "Abiotique", "Les deux", "Ni l'un ni l'autre"], correctAnswer: 1, difficulty: "moyen", explanation: "L'eau est abiotique (non-vivant)" },
        { question: "Qu'est-ce qu'un carnivore ?", options: ["Mange plantes", "Mange viande", "Mange tout", "Ne mange pas"], correctAnswer: 1, difficulty: "facile", explanation: "Un carnivore mange de la viande" },
        { question: "Les champignons sont-ils des producteurs ?", options: ["Oui", "Non", "Parfois", "Toujours"], correctAnswer: 1, difficulty: "moyen", explanation: "Les champignons sont des décomposeurs, pas des producteurs" },
        { question: "Quel est le rôle de la lumière pour les plantes ?", options: ["Décoration", "Photosynthèse", "Chaleur", "Rien"], correctAnswer: 1, difficulty: "facile", explanation: "La lumière permet la photosynthèse" },
        { question: "Qu'est-ce qu'un omnivore ?", options: ["Mange plantes", "Mange viande", "Mange tout", "Ne mange pas"], correctAnswer: 2, difficulty: "facile", explanation: "Un omnivore mange plantes et viande" },
        { question: "Le sol est-il biotique ou abiotique ?", options: ["Biotique", "Abiotique", "Les deux", "Ni l'un ni l'autre"], correctAnswer: 2, difficulty: "difficile", explanation: "Le sol contient du vivant et du non-vivant" },
        { question: "Que libèrent les plantes lors de la photosynthèse ?", options: ["CO2", "Azote", "Oxygène", "Hydrogène"], correctAnswer: 2, difficulty: "moyen", explanation: "Les plantes libèrent de l'oxygène (O2)" },
        { question: "Qu'est-ce qu'un réseau trophique ?", options: ["Une toile", "Chaînes liées", "Un animal", "Une plante"], correctAnswer: 1, difficulty: "difficile", explanation: "Un réseau trophique lie plusieurs chaînes alimentaires" },
        { question: "Les bactéries sont-elles vivantes ?", options: ["Oui", "Non", "Parfois", "Jamais"], correctAnswer: 0, difficulty: "facile", explanation: "Les bactéries sont des êtres vivants microscopiques" },
        { question: "Quel est le rôle des décomposeurs ?", options: ["Tuer", "Recycler", "Manger", "Dormir"], correctAnswer: 1, difficulty: "moyen", explanation: "Les décomposeurs recyclent la matière organique" },
        { question: "La température est-elle un facteur biotique ?", options: ["Oui", "Non", "Parfois", "Toujours"], correctAnswer: 1, difficulty: "moyen", explanation: "La température est un facteur abiotique" },
        { question: "Qu'est-ce qu'une niche écologique ?", options: ["Une maison", "Rôle dans écosystème", "Un trou", "Un nid"], correctAnswer: 1, difficulty: "difficile", explanation: "La niche écologique est le rôle d'une espèce" },
      ],
    },
  },
  "histoire-geographie": {
    "6ème": {
      "prehistoire": [
        { question: "Quand commence la Préhistoire ?", options: ["Il y a 1000 ans", "Il y a 10000 ans", "Il y a 3 millions d'années", "Il y a 100000 ans"], correctAnswer: 2, difficulty: "facile", explanation: "La Préhistoire commence il y a environ 3 millions d'années" },
        { question: "Quel est le premier homme ?", options: ["Homo sapiens", "Néandertal", "Australopithèque", "Cro-Magnon"], correctAnswer: 2, difficulty: "moyen", explanation: "L'Australopithèque est considéré comme le premier hominidé" },
        { question: "Que signifie 'Paléolithique' ?", options: ["Âge de pierre", "Âge ancien", "Pierre taillée", "Pierre polie"], correctAnswer: 2, difficulty: "moyen", explanation: "Paléolithique signifie 'pierre ancienne' ou 'pierre taillée'" },
        { question: "Quand l'homme a-t-il maîtrisé le feu ?", options: ["Il y a 10000 ans", "Il y a 100000 ans", "Il y a 400000 ans", "Il y a 1 million d'années"], correctAnswer: 2, difficulty: "difficile", explanation: "Le feu a été maîtrisé il y a environ 400000 ans" },
        { question: "Qu'est-ce que Lascaux ?", options: ["Une ville", "Une grotte", "Un homme", "Un outil"], correctAnswer: 1, difficulty: "facile", explanation: "Lascaux est une grotte avec des peintures préhistoriques" },
        { question: "Que chassaient les hommes préhistoriques ?", options: ["Dinosaures", "Mammouths", "Lions", "Tigres"], correctAnswer: 1, difficulty: "facile", explanation: "Les mammouths étaient chassés à la Préhistoire" },
        { question: "Qu'est-ce qu'un biface ?", options: ["Un outil", "Un animal", "Une plante", "Une maison"], correctAnswer: 0, difficulty: "moyen", explanation: "Un biface est un outil en pierre taillé sur deux faces" },
        { question: "Quand commence le Néolithique ?", options: ["Il y a 2000 ans", "Il y a 5000 ans", "Il y a 10000 ans", "Il y a 20000 ans"], correctAnswer: 2, difficulty: "moyen", explanation: "Le Néolithique commence il y a environ 10000 ans" },
        { question: "Quelle est la principale activité au Néolithique ?", options: ["Chasse", "Pêche", "Agriculture", "Commerce"], correctAnswer: 2, difficulty: "facile", explanation: "L'agriculture apparaît au Néolithique" },
        { question: "Comment vivaient les hommes au Paléolithique ?", options: ["Sédentaires", "Nomades", "En ville", "En château"], correctAnswer: 1, difficulty: "facile", explanation: "Les hommes étaient nomades (ils se déplaçaient)" },
        { question: "Qu'est-ce qu'un dolmen ?", options: ["Un outil", "Un monument", "Un animal", "Une arme"], correctAnswer: 1, difficulty: "moyen", explanation: "Un dolmen est un monument mégalithique" },
        { question: "Quand l'écriture est-elle apparue ?", options: ["3000 av. J.-C.", "1000 av. J.-C.", "500 av. J.-C.", "100 av. J.-C."], correctAnswer: 0, difficulty: "difficile", explanation: "L'écriture apparaît vers 3000 av. J.-C. (fin de la Préhistoire)" },
        { question: "Qu'est-ce que la sédentarisation ?", options: ["Se déplacer", "S'installer", "Chasser", "Pêcher"], correctAnswer: 1, difficulty: "facile", explanation: "La sédentarisation = s'installer de façon permanente" },
        { question: "Où se trouvent les grottes de Lascaux ?", options: ["Espagne", "Italie", "France", "Allemagne"], correctAnswer: 2, difficulty: "moyen", explanation: "Lascaux est en Dordogne, France" },
        { question: "Qu'est-ce qu'un menhir ?", options: ["Pierre dressée", "Pierre couchée", "Pierre ronde", "Pierre plate"], correctAnswer: 0, difficulty: "facile", explanation: "Un menhir est une pierre dressée verticalement" },
        { question: "Homo sapiens est apparu il y a :", options: ["50000 ans", "100000 ans", "200000 ans", "500000 ans"], correctAnswer: 2, difficulty: "difficile", explanation: "Homo sapiens est apparu il y a environ 200000 ans" },
        { question: "Que représentent les peintures rupestres ?", options: ["Maisons", "Animaux", "Plantes", "Outils"], correctAnswer: 1, difficulty: "facile", explanation: "Les peintures rupestres représentent surtout des animaux" },
        { question: "Qu'est-ce que la taille du silex ?", options: ["Couper pierre", "Polir pierre", "Casser pierre", "Peindre pierre"], correctAnswer: 0, difficulty: "moyen", explanation: "Tailler le silex = le frapper pour créer des outils" },
        { question: "Quelle révolution marque le Néolithique ?", options: ["Industrielle", "Agricole", "Numérique", "Française"], correctAnswer: 1, difficulty: "moyen", explanation: "La révolution néolithique est agricole" },
        { question: "Qu'est-ce que l'art pariétal ?", options: ["Art sur mur", "Art sur bois", "Art sur os", "Art sur pierre"], correctAnswer: 0, difficulty: "difficile", explanation: "L'art pariétal est l'art sur les parois des grottes" },
      ],
    },
  },
  "physique-chimie": {
    "5ème": {
      "electricite-5eme": [
        { question: "Quel composant permet de fermer un circuit ?", options: ["Pile", "Lampe", "Interrupteur", "Fil"], correctAnswer: 2, difficulty: "facile", explanation: "L'interrupteur ouvre ou ferme le circuit" },
        { question: "Que faut-il pour qu'une lampe brille ?", options: ["Circuit ouvert", "Circuit fermé", "Pas de pile", "Pas de fil"], correctAnswer: 1, difficulty: "facile", explanation: "Il faut un circuit fermé pour que le courant circule" },
        { question: "Quel est le symbole de la pile ?", options: ["○", "─┬─", "×", "□"], correctAnswer: 1, difficulty: "moyen", explanation: "La pile est représentée par deux traits parallèles" },
        { question: "Dans quel sens circule le courant ?", options: ["+ vers -", "- vers +", "Pas de sens", "Les deux"], correctAnswer: 0, difficulty: "moyen", explanation: "Le courant va du + vers le -" },
        { question: "Qu'est-ce qu'un circuit en série ?", options: ["Un seul chemin", "Plusieurs chemins", "Pas de chemin", "Chemin fermé"], correctAnswer: 0, difficulty: "facile", explanation: "Circuit en série = un seul chemin pour le courant" },
        { question: "Que mesure un ampèremètre ?", options: ["Tension", "Intensité", "Résistance", "Puissance"], correctAnswer: 1, difficulty: "moyen", explanation: "L'ampèremètre mesure l'intensité du courant" },
        { question: "Comment branche-t-on un ampèremètre ?", options: ["En série", "En dérivation", "Seul", "N'importe"], correctAnswer: 0, difficulty: "moyen", explanation: "L'ampèremètre se branche en série" },
        { question: "Quelle est l'unité de l'intensité ?", options: ["Volt", "Ampère", "Ohm", "Watt"], correctAnswer: 1, difficulty: "facile", explanation: "L'intensité se mesure en Ampères (A)" },
        { question: "Qu'est-ce qu'un court-circuit ?", options: ["Circuit long", "Circuit direct", "Circuit ouvert", "Circuit fermé"], correctAnswer: 1, difficulty: "moyen", explanation: "Court-circuit = connexion directe entre + et -" },
        { question: "À quoi sert un fusible ?", options: ["Éclairer", "Protéger", "Mesurer", "Chauffer"], correctAnswer: 1, difficulty: "facile", explanation: "Le fusible protège le circuit en cas de surcharge" },
        { question: "Qu'est-ce qu'un isolant électrique ?", options: ["Laisse passer", "Bloque courant", "Produit courant", "Mesure courant"], correctAnswer: 1, difficulty: "facile", explanation: "Un isolant ne laisse pas passer le courant" },
        { question: "Le bois est-il conducteur ?", options: ["Oui", "Non", "Parfois", "Toujours"], correctAnswer: 1, difficulty: "facile", explanation: "Le bois est un isolant" },
        { question: "Le cuivre est-il conducteur ?", options: ["Oui", "Non", "Parfois", "Jamais"], correctAnswer: 0, difficulty: "facile", explanation: "Le cuivre est un bon conducteur" },
        { question: "Que se passe-t-il si on ajoute une lampe en série ?", options: ["Plus brillant", "Moins brillant", "Pareil", "Rien"], correctAnswer: 1, difficulty: "moyen", explanation: "En série, ajouter une lampe diminue l'éclat" },
        { question: "Qu'est-ce qu'un nœud dans un circuit ?", options: ["Point de jonction", "Point final", "Point de départ", "Point isolé"], correctAnswer: 0, difficulty: "difficile", explanation: "Un nœud est un point où plusieurs fils se rejoignent" },
        { question: "Comment est la tension dans un circuit en série ?", options: ["Identique partout", "Différente", "Additive", "Nulle"], correctAnswer: 2, difficulty: "difficile", explanation: "Les tensions s'additionnent en série" },
        { question: "Quel matériau conduit l'électricité ?", options: ["Plastique", "Métal", "Bois", "Verre"], correctAnswer: 1, difficulty: "facile", explanation: "Les métaux sont conducteurs" },
        { question: "Que fait un générateur ?", options: ["Consomme", "Produit", "Mesure", "Bloque"], correctAnswer: 1, difficulty: "facile", explanation: "Le générateur produit le courant électrique" },
        { question: "Combien de bornes a une pile ?", options: ["1", "2", "3", "4"], correctAnswer: 1, difficulty: "facile", explanation: "Une pile a deux bornes : + et -" },
        { question: "Qu'est-ce qu'un récepteur ?", options: ["Produit courant", "Utilise courant", "Mesure courant", "Bloque courant"], correctAnswer: 1, difficulty: "moyen", explanation: "Un récepteur utilise le courant (ex: lampe)" },
      ],
    },
  },
  anglais: {
    "6ème": {
      "presentations": [
        { question: "Comment dit-on 'Bonjour' en anglais ?", options: ["Goodbye", "Hello", "Please", "Thank you"], correctAnswer: 1, difficulty: "facile", explanation: "'Hello' signifie 'Bonjour'" },
        { question: "Que signifie 'What is your name?' ?", options: ["Quel âge ?", "Comment t'appelles-tu ?", "Où habites-tu ?", "Comment vas-tu ?"], correctAnswer: 1, difficulty: "facile", explanation: "'What is your name?' = Comment t'appelles-tu ?" },
        { question: "Comment répond-on à 'How are you?' ?", options: ["I'm 12", "I'm fine", "I'm French", "I'm tall"], correctAnswer: 1, difficulty: "facile", explanation: "'I'm fine' = Je vais bien" },
        { question: "Que signifie 'I am' ?", options: ["Tu es", "Il est", "Je suis", "Nous sommes"], correctAnswer: 2, difficulty: "facile", explanation: "'I am' = Je suis" },
        { question: "Comment dit-on 'au revoir' ?", options: ["Hello", "Goodbye", "Please", "Sorry"], correctAnswer: 1, difficulty: "facile", explanation: "'Goodbye' = Au revoir" },
        { question: "Que signifie 'Nice to meet you' ?", options: ["Bonjour", "Au revoir", "Enchanté", "Merci"], correctAnswer: 2, difficulty: "moyen", explanation: "'Nice to meet you' = Enchanté de te rencontrer" },
        { question: "Comment demande-t-on l'âge en anglais ?", options: ["What's your name?", "How are you?", "How old are you?", "Where are you?"], correctAnswer: 2, difficulty: "facile", explanation: "'How old are you?' = Quel âge as-tu ?" },
        { question: "Que veut dire 'I'm sorry' ?", options: ["Je suis content", "Je suis désolé", "Je suis fatigué", "Je suis grand"], correctAnswer: 1, difficulty: "facile", explanation: "'I'm sorry' = Je suis désolé" },
        { question: "Comment dit-on 'merci' ?", options: ["Please", "Sorry", "Thank you", "Hello"], correctAnswer: 2, difficulty: "facile", explanation: "'Thank you' = Merci" },
        { question: "Que signifie 'My name is...' ?", options: ["J'ai... ans", "Je m'appelle...", "J'habite...", "Je suis..."], correctAnswer: 1, difficulty: "facile", explanation: "'My name is...' = Je m'appelle..." },
        { question: "Comment dit-on 's'il vous plaît' ?", options: ["Sorry", "Please", "Thanks", "Hello"], correctAnswer: 1, difficulty: "facile", explanation: "'Please' = S'il vous plaît" },
        { question: "Que veut dire 'Where are you from?' ?", options: ["Quel âge ?", "Comment ?", "D'où viens-tu ?", "Où vas-tu ?"], correctAnswer: 2, difficulty: "moyen", explanation: "'Where are you from?' = D'où viens-tu ?" },
        { question: "Comment répond-on à 'What's your name?' ?", options: ["I'm fine", "I'm 12", "I'm Tom", "I'm French"], correctAnswer: 2, difficulty: "facile", explanation: "On répond avec son prénom : I'm + prénom" },
        { question: "Que signifie 'See you later' ?", options: ["Bonjour", "À plus tard", "Bonne nuit", "Bon appétit"], correctAnswer: 1, difficulty: "moyen", explanation: "'See you later' = À plus tard" },
        { question: "Comment dit-on 'Je viens de France' ?", options: ["I'm France", "I'm French", "I'm from France", "I'm in France"], correctAnswer: 2, difficulty: "moyen", explanation: "'I'm from France' = Je viens de France" },
        { question: "Que veut dire 'Good morning' ?", options: ["Bonsoir", "Bonjour (matin)", "Bonne nuit", "Au revoir"], correctAnswer: 1, difficulty: "facile", explanation: "'Good morning' = Bonjour (le matin)" },
        { question: "Comment dit-on 'Bonsoir' ?", options: ["Good morning", "Good afternoon", "Good evening", "Good night"], correctAnswer: 2, difficulty: "moyen", explanation: "'Good evening' = Bonsoir" },
        { question: "Que signifie 'Excuse me' ?", options: ["Merci", "Pardon", "Bonjour", "Au revoir"], correctAnswer: 1, difficulty: "facile", explanation: "'Excuse me' = Pardon / Excusez-moi" },
        { question: "Comment dit-on 'Bonne nuit' ?", options: ["Good morning", "Good evening", "Good night", "Goodbye"], correctAnswer: 2, difficulty: "facile", explanation: "'Good night' = Bonne nuit" },
        { question: "Que veut dire 'How do you spell...?' ?", options: ["Comment dis-tu ?", "Comment épelles-tu ?", "Comment vas-tu ?", "Comment t'appelles-tu ?"], correctAnswer: 1, difficulty: "difficile", explanation: "'How do you spell...?' = Comment épelles-tu... ?" },
      ],
    },
  },
  technologie: {
    "4ème": {
      "programmation": [
        { question: "Qu'est-ce qu'un algorithme ?", options: ["Un robot", "Une suite d'instructions", "Un ordinateur", "Un programme"], correctAnswer: 1, difficulty: "facile", explanation: "Un algorithme est une suite d'instructions pour résoudre un problème" },
        { question: "Dans Scratch, que fait le bloc 'répéter' ?", options: ["Arrête", "Répète actions", "Efface", "Affiche"], correctAnswer: 1, difficulty: "facile", explanation: "Le bloc 'répéter' exécute des actions plusieurs fois" },
        { question: "Qu'est-ce qu'une variable ?", options: ["Un nombre fixe", "Une valeur changeante", "Un texte", "Une couleur"], correctAnswer: 1, difficulty: "moyen", explanation: "Une variable stocke une valeur qui peut changer" },
        { question: "Que signifie 'Si... alors...' ?", options: ["Répétition", "Condition", "Arrêt", "Début"], correctAnswer: 1, difficulty: "facile", explanation: "'Si... alors...' est une structure conditionnelle" },
        { question: "Qu'est-ce qu'une boucle ?", options: ["Arrêt", "Répétition", "Condition", "Variable"], correctAnswer: 1, difficulty: "facile", explanation: "Une boucle répète des instructions" },
        { question: "Dans Scratch, comment déplace-t-on un sprite ?", options: ["Cliquer", "Bloc 'avancer'", "Effacer", "Colorier"], correctAnswer: 1, difficulty: "facile", explanation: "On utilise le bloc 'avancer de X pas'" },
        { question: "Qu'est-ce qu'un capteur ?", options: ["Affiche info", "Détecte info", "Calcule", "Stocke"], correctAnswer: 1, difficulty: "moyen", explanation: "Un capteur détecte des informations (température, distance...)" },
        { question: "Que fait une condition 'si' ?", options: ["Répète", "Teste", "Arrête", "Affiche"], correctAnswer: 1, difficulty: "facile", explanation: "La condition 'si' teste une situation" },
        { question: "Qu'est-ce qu'un événement en programmation ?", options: ["Une erreur", "Un déclencheur", "Un bug", "Un arrêt"], correctAnswer: 1, difficulty: "moyen", explanation: "Un événement déclenche une action (clic, touche...)" },
        { question: "Que signifie 'déboguer' ?", options: ["Créer bugs", "Corriger bugs", "Ignorer bugs", "Cacher bugs"], correctAnswer: 1, difficulty: "facile", explanation: "Déboguer = corriger les erreurs du programme" },
        { question: "Qu'est-ce qu'une séquence ?", options: ["Instructions désordonnées", "Instructions ordonnées", "Une boucle", "Une condition"], correctAnswer: 1, difficulty: "moyen", explanation: "Une séquence est une suite ordonnée d'instructions" },
        { question: "Comment arrête-t-on un programme Scratch ?", options: ["Fermer", "Bloc 'stop'", "Supprimer", "Cacher"], correctAnswer: 1, difficulty: "facile", explanation: "On utilise le bloc 'stop tout'" },
        { question: "Qu'est-ce qu'un sprite ?", options: ["Un fond", "Un personnage", "Un son", "Une couleur"], correctAnswer: 1, difficulty: "facile", explanation: "Un sprite est un personnage/objet dans Scratch" },
        { question: "Que fait 'répéter jusqu'à...' ?", options: ["Répète toujours", "Répète si condition", "Arrête tout", "Ne répète pas"], correctAnswer: 1, difficulty: "moyen", explanation: "'Répéter jusqu'à' boucle jusqu'à ce qu'une condition soit vraie" },
        { question: "Qu'est-ce qu'un opérateur ?", options: ["Un robot", "Un calcul/comparaison", "Un capteur", "Un moteur"], correctAnswer: 1, difficulty: "moyen", explanation: "Un opérateur fait des calculs ou comparaisons (+, -, =, >...)" },
        { question: "Que signifie 'initialiser' ?", options: ["Finir", "Commencer/définir", "Arrêter", "Répéter"], correctAnswer: 1, difficulty: "difficile", explanation: "Initialiser = donner une valeur de départ" },
        { question: "Comment teste-t-on un programme ?", options: ["Le supprimer", "L'exécuter", "Le cacher", "L'ignorer"], correctAnswer: 1, difficulty: "facile", explanation: "On teste en exécutant le programme" },
        { question: "Qu'est-ce qu'un bug ?", options: ["Un insecte", "Une erreur", "Un programme", "Un capteur"], correctAnswer: 1, difficulty: "facile", explanation: "Un bug est une erreur dans le code" },
        { question: "Que fait le bloc 'attendre' ?", options: ["Accélère", "Ralentit/pause", "Arrête", "Répète"], correctAnswer: 1, difficulty: "facile", explanation: "Le bloc 'attendre' met en pause pendant un temps" },
        { question: "Comment change-t-on la couleur d'un sprite ?", options: ["Le supprimer", "Bloc 'mettre couleur'", "Le cacher", "L'effacer"], correctAnswer: 1, difficulty: "moyen", explanation: "On utilise le bloc 'mettre l'effet couleur à...'" },
      ],
    },
  },
  emc: {
    "3ème": {
      "democratie": [
        { question: "Qu'est-ce que la démocratie ?", options: ["Pouvoir d'un seul", "Pouvoir du peuple", "Pouvoir des riches", "Pas de pouvoir"], correctAnswer: 1, difficulty: "facile", explanation: "Démocratie = pouvoir (kratos) du peuple (demos)" },
        { question: "Combien de pouvoirs y a-t-il en France ?", options: ["1", "2", "3", "4"], correctAnswer: 2, difficulty: "facile", explanation: "Il y a 3 pouvoirs : exécutif, législatif, judiciaire" },
        { question: "Qui détient le pouvoir exécutif ?", options: ["Parlement", "Président", "Juges", "Peuple"], correctAnswer: 1, difficulty: "facile", explanation: "Le pouvoir exécutif est détenu par le Président et le gouvernement" },
        { question: "Qui fait les lois en France ?", options: ["Président", "Parlement", "Juges", "Maires"], correctAnswer: 1, difficulty: "moyen", explanation: "Le Parlement (Assemblée + Sénat) vote les lois" },
        { question: "À quel âge peut-on voter en France ?", options: ["16 ans", "17 ans", "18 ans", "21 ans"], correctAnswer: 2, difficulty: "facile", explanation: "On peut voter à partir de 18 ans" },
        { question: "Combien de députés à l'Assemblée nationale ?", options: ["377", "477", "577", "677"], correctAnswer: 2, difficulty: "difficile", explanation: "Il y a 577 députés à l'Assemblée nationale" },
        { question: "Quelle est la durée du mandat présidentiel ?", options: ["4 ans", "5 ans", "6 ans", "7 ans"], correctAnswer: 1, difficulty: "moyen", explanation: "Le mandat présidentiel dure 5 ans (quinquennat)" },
        { question: "Qu'est-ce que la séparation des pouvoirs ?", options: ["Diviser pays", "Indépendance pouvoirs", "Élire président", "Voter lois"], correctAnswer: 1, difficulty: "moyen", explanation: "Chaque pouvoir est indépendant des autres" },
        { question: "Qui nomme le Premier ministre ?", options: ["Peuple", "Président", "Parlement", "Juges"], correctAnswer: 1, difficulty: "facile", explanation: "Le Président nomme le Premier ministre" },
        { question: "Qu'est-ce qu'un référendum ?", options: ["Vote député", "Vote peuple direct", "Vote président", "Vote maire"], correctAnswer: 1, difficulty: "moyen", explanation: "Le référendum est un vote direct du peuple" },
        { question: "Quel est le symbole de la République ?", options: ["Roi", "Marianne", "Croix", "Lion"], correctAnswer: 1, difficulty: "facile", explanation: "Marianne symbolise la République française" },
        { question: "Que signifie 'suffrage universel' ?", options: ["Vote limité", "Tous votent", "Vote hommes", "Vote riches"], correctAnswer: 1, difficulty: "moyen", explanation: "Suffrage universel = tous les citoyens votent" },
        { question: "Qu'est-ce que la Constitution ?", options: ["Un roi", "Loi fondamentale", "Un vote", "Un parti"], correctAnswer: 1, difficulty: "facile", explanation: "La Constitution est la loi suprême du pays" },
        { question: "Qui contrôle l'application des lois ?", options: ["Président", "Parlement", "Justice", "Peuple"], correctAnswer: 2, difficulty: "moyen", explanation: "La justice (pouvoir judiciaire) contrôle les lois" },
        { question: "Qu'est-ce qu'un parti politique ?", options: ["Une fête", "Groupe d'idées", "Un vote", "Une loi"], correctAnswer: 1, difficulty: "facile", explanation: "Un parti rassemble des personnes aux idées communes" },
        { question: "Que veut dire 'laïcité' ?", options: ["Religion d'État", "Neutralité État", "Pas de religion", "Toutes religions"], correctAnswer: 1, difficulty: "moyen", explanation: "La laïcité = neutralité de l'État envers les religions" },
        { question: "Combien de sénateurs en France ?", options: ["248", "348", "448", "548"], correctAnswer: 1, difficulty: "difficile", explanation: "Il y a 348 sénateurs" },
        { question: "Qu'est-ce que l'opposition ?", options: ["Parti au pouvoir", "Partis hors pouvoir", "Peuple", "Justice"], correctAnswer: 1, difficulty: "moyen", explanation: "L'opposition regroupe les partis qui ne gouvernent pas" },
        { question: "Qui peut dissoudre l'Assemblée ?", options: ["Premier ministre", "Président", "Peuple", "Sénat"], correctAnswer: 1, difficulty: "difficile", explanation: "Le Président peut dissoudre l'Assemblée nationale" },
        { question: "Qu'est-ce que le droit de vote ?", options: ["Un devoir", "Un droit", "Les deux", "Ni l'un ni l'autre"], correctAnswer: 2, difficulty: "moyen", explanation: "Le vote est à la fois un droit et un devoir civique" },
      ],
    },
  },
};

type QuestionData = {
  question: string;
  options: string[];
  correctAnswer: number;
  difficulty: string;
  explanation: string;
};

export async function seedQuestions() {
  try {
    console.log("🎯 Génération des questions...\n");
    
    for (const [subjectSlug, gradeData] of Object.entries(questionTemplates)) {
      for (const [grade, chapterData] of Object.entries(gradeData)) {
        for (const [chapterSlug, questionsData] of Object.entries(chapterData)) {
          // Trouver le chapitre
          const [chapter] = await db
            .select()
            .from(chapters)
            .where(eq(chapters.slug, chapterSlug));
          
          if (chapter) {
            console.log(`📝 Génération pour: ${chapter.title} (${grade})`);
            
            // Insérer les questions
            const typedQuestions = questionsData as QuestionData[];
            for (const q of typedQuestions) {
              await db.insert(questions).values({
                chapterId: chapter.id,
                question: q.question,
                options: q.options,
                correctAnswer: q.correctAnswer,
                explanation: q.explanation,
                difficulty: q.difficulty,
                points: q.difficulty === "facile" ? 10 : q.difficulty === "moyen" ? 15 : 20,
              });
            }
            
            console.log(`  ✓ ${typedQuestions.length} questions ajoutées`);
          }
        }
      }
    }
    
    console.log("\n✅ Questions générées avec succès !");
  } catch (error) {
    console.error("❌ Erreur lors de la génération des questions:", error);
    throw error;
  }
}

import { db } from "./db";
import { questions } from "@shared/schema";
import { eq } from "drizzle-orm";

async function duplicateQuestionsForOtherGrades() {
  try {
    // Récupérer toutes les questions de 6ème
    const questions6eme = await db
      .select()
      .from(questions)
      .where(eq(questions.grade, "6ème"));

    console.log(`Trouvé ${questions6eme.length} questions pour la 6ème`);

    const grades = ["5ème", "4ème", "3ème"];
    
    for (const grade of grades) {
      console.log(`\nDuplication pour la classe ${grade}...`);
      
      // Créer des copies pour chaque grade
      const questionsForGrade = questions6eme.map((q) => ({
        subjectId: q.subjectId,
        grade: grade,
        question: q.question,
        options: q.options,
        correctAnswer: q.correctAnswer,
        explanation: q.explanation,
        difficulty: q.difficulty,
        points: q.points,
      }));

      // Insérer par lots de 100
      const batchSize = 100;
      for (let i = 0; i < questionsForGrade.length; i += batchSize) {
        const batch = questionsForGrade.slice(i, i + batchSize);
        await db.insert(questions).values(batch);
        console.log(`  Inséré ${Math.min(i + batchSize, questionsForGrade.length)} / ${questionsForGrade.length} questions`);
      }

      console.log(`✅ ${questionsForGrade.length} questions créées pour ${grade}`);
    }

    console.log("\n✅ Duplication terminée avec succès pour toutes les classes !");
    
    // Afficher le résumé
    console.log("\n📊 Résumé des questions par classe:");
    const allGrades = ["6ème", "5ème", "4ème", "3ème"];
    for (const grade of allGrades) {
      const count = await db
        .select()
        .from(questions)
        .where(eq(questions.grade, grade));
      console.log(`  ${grade}: ${count.length} questions`);
    }

  } catch (error) {
    console.error("❌ Erreur lors de la duplication:", error);
    process.exit(1);
  } finally {
    process.exit(0);
  }
}

duplicateQuestionsForOtherGrades();

import { db } from "./db";
import { questions } from "@shared/schema";
import { eq } from "drizzle-orm";
import fs from "fs";

const SVT_ID = '19325a72-fd14-48ac-a5f1-c317599ef437';

interface Question {
  q: string;
  a: string[];
  c: number;
}

function parseSection(content: string, sectionName: string): Question[] {
  // Trouver la section
  const sectionRegex = new RegExp(`${sectionName}:\\s*\\{`, 'i');
  const sectionMatch = content.search(sectionRegex);
  
  if (sectionMatch === -1) return [];
  
  // Extraire du début de la section jusqu'à la prochaine section principale ou la fin
  const afterSection = content.substring(sectionMatch);
  const nextSectionMatch = afterSection.search(/\n\s{12}\w+:\s*\{/);
  const sectionContent = nextSectionMatch > 0 
    ? afterSection.substring(0, nextSectionMatch)
    : afterSection;
  
  // Extraire toutes les questions avec le format {q:..., a:[...], c:...}
  const questionMatches = Array.from(sectionContent.matchAll(/\{q:\s*"([^"]+)",\s*a:\s*\[(.*?)\],\s*c:\s*(\d+)\}/g));
  
  const parsedQuestions: Question[] = [];
  for (const qMatch of questionMatches) {
    const question = qMatch[1];
    const answersText = qMatch[2];
    const correctIndex = parseInt(qMatch[3]);
    
    const answers = answersText
      .split(',')
      .map((a: string) => a.trim().replace(/^"|"$/g, ''))
      .filter((a: string) => a.length > 0);
    
    if (answers.length === 4) {
      parsedQuestions.push({
        q: question,
        a: answers,
        c: correctIndex
      });
    }
  }
  
  return parsedQuestions;
}

async function importSciences() {
  try {
    const fileContent = fs.readFileSync(
      'attached_assets/Pasted--VOS-QUESTIONS-PERSONNALIS-ES-ICI--1760520597399_1760520597404.txt',
      'utf-8'
    );

    console.log(`\n📚 Import Sciences (SVT)...`);
    
    const parsedQuestions = parseSection(fileContent, 'sciences');
    console.log(`  Questions trouvées: ${parsedQuestions.length}`);

    if (parsedQuestions.length === 0) {
      console.log(`  ⚠️ Aucune question trouvée pour sciences`);
      process.exit(1);
    }

    // Importer pour toutes les classes
    const grades = ['6ème', '5ème', '4ème', '3ème'];
    for (const grade of grades) {
      for (const q of parsedQuestions) {
        await db.insert(questions).values({
          subjectId: SVT_ID,
          grade: grade,
          question: q.q,
          options: q.a,
          correctAnswer: q.c,
          difficulty: 'moyen',
          points: 10
        });
      }
      console.log(`  ✅ ${parsedQuestions.length} questions importées pour ${grade}`);
    }

    console.log("\n📊 Total Sciences (SVT):");
    const count = await db.select().from(questions).where(eq(questions.subjectId, SVT_ID));
    console.log(`  ${count.length} questions (toutes classes)`);

  } catch (error) {
    console.error("❌ Erreur:", error);
    process.exit(1);
  } finally {
    process.exit(0);
  }
}

importSciences();

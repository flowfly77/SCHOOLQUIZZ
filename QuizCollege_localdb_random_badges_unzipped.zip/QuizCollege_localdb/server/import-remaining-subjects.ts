import { db } from "./db";
import { questions } from "@shared/schema";
import { eq } from "drizzle-orm";
import fs from "fs";

// IDs des matières
const SUBJECT_IDS = {
  maths: '4cc2d7d8-bb48-4d02-8b52-120f6133718a',
  geographie: '497f13c4-6eba-481e-9d1b-4692160f8c26',
  svt: '19325a72-fd14-48ac-a5f1-c317599ef437'
};

interface Question {
  q: string;
  a: string[];
  c: number;
}

function parseSection(content: string, sectionName: string): Question[] {
  // Trouver la section
  const sectionRegex = new RegExp(`${sectionName}:\\s*\\{`, 'i');
  const sectionMatch = content.search(sectionRegex);
  
  if (sectionMatch === -1) return [];
  
  // Extraire du début de la section jusqu'à la prochaine section principale ou la fin
  const afterSection = content.substring(sectionMatch);
  const nextSectionMatch = afterSection.search(/\n\s{12}\w+:\s*\{/);
  const sectionContent = nextSectionMatch > 0 
    ? afterSection.substring(0, nextSectionMatch)
    : afterSection;
  
  // Extraire toutes les questions avec le format {q:..., a:[...], c:...}
  const questionMatches = Array.from(sectionContent.matchAll(/\{q:\s*"([^"]+)",\s*a:\s*\[(.*?)\],\s*c:\s*(\d+)\}/g));
  
  const parsedQuestions: Question[] = [];
  for (const qMatch of questionMatches) {
    const question = qMatch[1];
    const answersText = qMatch[2];
    const correctIndex = parseInt(qMatch[3]);
    
    const answers = answersText
      .split(',')
      .map((a: string) => a.trim().replace(/^"|"$/g, ''))
      .filter((a: string) => a.length > 0);
    
    if (answers.length === 4) {
      parsedQuestions.push({
        q: question,
        a: answers,
        c: correctIndex
      });
    }
  }
  
  return parsedQuestions;
}

async function importRemainingSubjects() {
  try {
    const fileContent = fs.readFileSync(
      'attached_assets/Pasted--VOS-QUESTIONS-PERSONNALIS-ES-ICI--1760520597399_1760520597404.txt',
      'utf-8'
    );

    const subjects = [
      { name: 'maths', id: SUBJECT_IDS.maths },
      { name: 'geographie', id: SUBJECT_IDS.geographie },
      { name: 'sciences', id: SUBJECT_IDS.svt }
    ];

    for (const subject of subjects) {
      console.log(`\n📚 Import ${subject.name}...`);
      
      const parsedQuestions = parseSection(fileContent, subject.name);
      console.log(`  Questions trouvées: ${parsedQuestions.length}`);

      if (parsedQuestions.length === 0) {
        console.log(`  ⚠️ Aucune question trouvée pour ${subject.name}`);
        continue;
      }

      // Importer pour la 6ème d'abord
      for (const q of parsedQuestions) {
        await db.insert(questions).values({
          subjectId: subject.id,
          grade: '6ème',
          question: q.q,
          options: q.a,
          correctAnswer: q.c,
          difficulty: 'moyen',
          points: 10
        });
      }

      console.log(`  ✅ ${parsedQuestions.length} questions importées pour 6ème`);

      // Dupliquer pour les autres classes
      const grades = ['5ème', '4ème', '3ème'];
      for (const grade of grades) {
        for (const q of parsedQuestions) {
          await db.insert(questions).values({
            subjectId: subject.id,
            grade: grade,
            question: q.q,
            options: q.a,
            correctAnswer: q.c,
            difficulty: 'moyen',
            points: 10
          });
        }
        console.log(`  ✅ ${parsedQuestions.length} questions importées pour ${grade}`);
      }
    }

    // Afficher le résumé final
    console.log("\n📊 Résumé des questions par matière:");
    for (const subject of subjects) {
      const count = await db.select().from(questions).where(eq(questions.subjectId, subject.id));
      console.log(`  ${subject.name}: ${count.length} questions (toutes classes)`);
    }

  } catch (error) {
    console.error("❌ Erreur:", error);
    process.exit(1);
  } finally {
    process.exit(0);
  }
}

importRemainingSubjects();

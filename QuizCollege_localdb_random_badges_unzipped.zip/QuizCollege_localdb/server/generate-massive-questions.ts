import { db } from "./db";
import { questions, chapters } from "@shared/schema";
import { eq } from "drizzle-orm";

// Générateur de questions automatique basé sur des templates
const questionGenerators: Record<string, (chapterTitle: string, index: number) => any> = {
  "mathematiques": (title, i) => ({
    question: `Question ${i + 1} sur ${title.toLowerCase()} : ${generateMathQuestion(i)}`,
    options: generateMathOptions(i),
    correctAnswer: i % 4,
    difficulty: i % 3 === 0 ? "difficile" : i % 2 === 0 ? "moyen" : "facile",
    explanation: `Explication détaillée pour la question ${i + 1}`,
    points: i % 3 === 0 ? 20 : i % 2 === 0 ? 15 : 10,
  }),
  "francais": (title, i) => ({
    question: `Question ${i + 1} : ${generateFrenchQuestion(title, i)}`,
    options: generateOptions(["Option A", "Option B", "Option C", "Option D"], i),
    correctAnswer: (i + 1) % 4,
    difficulty: i % 3 === 0 ? "difficile" : i % 2 === 0 ? "moyen" : "facile",
    explanation: `Réponse : ${['Option A', 'Option B', 'Option C', 'Option D'][(i + 1) % 4]}`,
    points: i % 3 === 0 ? 20 : i % 2 === 0 ? 15 : 10,
  }),
  "histoire": (title, i) => ({
    question: `${title} - Question ${i + 1} : ${generateHistoryQuestion(title, i)}`,
    options: generateHistoryOptions(i),
    correctAnswer: i % 4,
    difficulty: i % 3 === 0 ? "difficile" : i % 2 === 0 ? "moyen" : "facile",
    explanation: `Contexte historique et explication pour la question ${i + 1}`,
    points: i % 3 === 0 ? 20 : i % 2 === 0 ? 15 : 10,
  }),
  "geographie": (title, i) => ({
    question: `Géographie - ${title} : ${generateGeoQuestion(i)}`,
    options: generateOptions(["Réponse 1", "Réponse 2", "Réponse 3", "Réponse 4"], i),
    correctAnswer: (i + 2) % 4,
    difficulty: i % 3 === 0 ? "difficile" : i % 2 === 0 ? "moyen" : "facile",
    explanation: `Explication géographique détaillée ${i + 1}`,
    points: i % 3 === 0 ? 20 : i % 2 === 0 ? 15 : 10,
  }),
  "svt": (title, i) => ({
    question: `SVT - ${title} : ${generateSVTQuestion(i)}`,
    options: generateOptions(["Vrai", "Faux", "Partiellement", "Impossible à dire"], i),
    correctAnswer: i % 4,
    difficulty: i % 3 === 0 ? "difficile" : i % 2 === 0 ? "moyen" : "facile",
    explanation: `Explication scientifique pour la question ${i + 1}`,
    points: i % 3 === 0 ? 20 : i % 2 === 0 ? 15 : 10,
  }),
  "physique-chimie": (title, i) => ({
    question: `Physique-Chimie - ${title} : ${generatePhysicsQuestion(i)}`,
    options: generateOptions(["Réponse A", "Réponse B", "Réponse C", "Réponse D"], i),
    correctAnswer: (i + 3) % 4,
    difficulty: i % 3 === 0 ? "difficile" : i % 2 === 0 ? "moyen" : "facile",
    explanation: `Principe physique/chimique expliqué ${i + 1}`,
    points: i % 3 === 0 ? 20 : i % 2 === 0 ? 15 : 10,
  }),
  "anglais": (title, i) => ({
    question: `English - ${title}: ${generateEnglishQuestion(i)}`,
    options: generateOptions(["Choice A", "Choice B", "Choice C", "Choice D"], i),
    correctAnswer: i % 4,
    difficulty: i % 3 === 0 ? "difficile" : i % 2 === 0 ? "moyen" : "facile",
    explanation: `Explanation in English for question ${i + 1}`,
    points: i % 3 === 0 ? 20 : i % 2 === 0 ? 15 : 10,
  }),
  "italien": (title, i) => ({
    question: `Italiano - ${title}: ${generateItalianQuestion(i)}`,
    options: generateOptions(["Risposta A", "Risposta B", "Risposta C", "Risposta D"], i),
    correctAnswer: (i + 1) % 4,
    difficulty: i % 3 === 0 ? "difficile" : i % 2 === 0 ? "moyen" : "facile",
    explanation: `Spiegazione in italiano ${i + 1}`,
    points: i % 3 === 0 ? 20 : i % 2 === 0 ? 15 : 10,
  }),
  "musique": (title, i) => ({
    question: `Musique - ${title} : ${generateMusicQuestion(i)}`,
    options: generateOptions(["Option 1", "Option 2", "Option 3", "Option 4"], i),
    correctAnswer: (i + 2) % 4,
    difficulty: i % 3 === 0 ? "difficile" : i % 2 === 0 ? "moyen" : "facile",
    explanation: `Explication musicale ${i + 1}`,
    points: i % 3 === 0 ? 20 : i % 2 === 0 ? 15 : 10,
  }),
  "sciences": (title, i) => ({
    question: `Sciences - ${title} : ${generateScienceQuestion(i)}`,
    options: generateOptions(["Réponse A", "Réponse B", "Réponse C", "Réponse D"], i),
    correctAnswer: i % 4,
    difficulty: i % 3 === 0 ? "difficile" : i % 2 === 0 ? "moyen" : "facile",
    explanation: `Explication scientifique ${i + 1}`,
    points: i % 3 === 0 ? 20 : i % 2 === 0 ? 15 : 10,
  }),
};

function generateMathQuestion(i: number): string {
  const questions = [
    `Calculez ${10 + i} × ${5 + i % 10} = ?`,
    `Quelle est la valeur de ${i}² ?`,
    `Résolvez l'équation ${i}x + ${i + 5} = ${i * 3}`,
    `Calculez le périmètre d'un carré de côté ${i + 1} cm`,
    `Trouvez ${i + 10}% de ${(i + 1) * 100}`,
  ];
  return questions[i % questions.length];
}

function generateMathOptions(i: number): string[] {
  const base = (10 + i) * (5 + i % 10);
  return [
    `${base}`,
    `${base + 5}`,
    `${base - 5}`,
    `${base + 10}`,
  ];
}

function generateFrenchQuestion(title: string, i: number): string {
  const questions = [
    `Quelle est la nature du mot souligné dans la phrase ${i + 1} ?`,
    `Identifiez la figure de style utilisée dans l'extrait ${i + 1}`,
    `Conjuguez le verbe à la forme appropriée (question ${i + 1})`,
    `Analysez la structure de cette phrase`,
    `Identifiez le temps verbal employé`,
  ];
  return questions[i % questions.length];
}

function generateHistoryQuestion(title: string, i: number): string {
  const questions = [
    `Quelle est la date de cet événement historique ?`,
    `Qui était le personnage principal de cette période ?`,
    `Quelles sont les causes de cet événement ?`,
    `Quelles sont les conséquences de cette période ?`,
    `Identifiez le contexte historique`,
  ];
  return questions[i % questions.length];
}

function generateGeoQuestion(i: number): string {
  const questions = [
    `Quelle est la caractéristique principale de cet espace géographique ?`,
    `Identifiez le continent ou la région concernée`,
    `Quels sont les enjeux de cet espace ?`,
    `Comment se caractérise ce territoire ?`,
    `Quel est le climat dominant ?`,
  ];
  return questions[i % questions.length];
}

function generateSVTQuestion(i: number): string {
  const questions = [
    `Quelle est la fonction de cet organe ?`,
    `Identifiez cette espèce ou ce système`,
    `Quel est le processus biologique en jeu ?`,
    `Comment se caractérise ce phénomène naturel ?`,
    `Quelle est la relation entre ces éléments ?`,
  ];
  return questions[i % questions.length];
}

function generatePhysicsQuestion(i: number): string {
  const questions = [
    `Quelle est la formule de cette loi physique ?`,
    `Identifiez le phénomène physique`,
    `Calculez cette grandeur physique`,
    `Quelle est la transformation chimique ?`,
    `Identifiez l'état de la matière`,
  ];
  return questions[i % questions.length];
}

function generateEnglishQuestion(i: number): string {
  const questions = [
    `Translate this sentence to English`,
    `Which tense is used in this sentence?`,
    `Complete the sentence with the correct word`,
    `What is the meaning of this expression?`,
    `Choose the correct preposition`,
  ];
  return questions[i % questions.length];
}

function generateItalianQuestion(i: number): string {
  const questions = [
    `Traduci questa frase in italiano`,
    `Quale tempo verbale è usato?`,
    `Completa la frase con la parola corretta`,
    `Qual è il significato di questa espressione?`,
    `Scegli la preposizione corretta`,
  ];
  return questions[i % questions.length];
}

function generateMusicQuestion(i: number): string {
  const questions = [
    `Identifiez cet instrument de musique`,
    `Quel est le tempo de ce morceau ?`,
    `Quelle est la tonalité de cette œuvre ?`,
    `Identifiez le compositeur`,
    `Quelle est l'époque musicale ?`,
  ];
  return questions[i % questions.length];
}

function generateScienceQuestion(i: number): string {
  const questions = [
    `Quel est ce phénomène scientifique ?`,
    `Identifiez cette expérience`,
    `Quelle est la conclusion de cette observation ?`,
    `Comment fonctionne ce système ?`,
    `Quelle est la propriété de cet élément ?`,
  ];
  return questions[i % questions.length];
}

function generateOptions(base: string[], i: number): string[] {
  return base.map((opt, idx) => `${opt} (variante ${i + idx})`);
}

function generateHistoryOptions(i: number): string[] {
  const dates = [(1800 + i * 10).toString(), (1850 + i * 5).toString(), (1900 + i * 3).toString(), (1950 + i).toString()];
  return dates;
}

export async function generateMassiveQuestions() {
  try {
    console.log("🎯 Génération massive de questions (200 par chapitre)...\n");
    
    const allChapters = await db.select().from(chapters);
    let totalGenerated = 0;
    
    for (const chapter of allChapters) {
      console.log(`📝 Chapitre: ${chapter.title} (${chapter.grade})`);
      
      // Trouver le générateur approprié
      const subjectData = await db.query.subjects.findFirst({
        where: (subjects, { eq }) => eq(subjects.id, chapter.subjectId)
      });
      
      if (!subjectData) continue;
      
      const generator = questionGenerators[subjectData.slug] || questionGenerators["francais"];
      
      // Générer 200 questions par chapitre
      const questionsToInsert = [];
      for (let i = 0; i < 200; i++) {
        const questionData = generator(chapter.title, i);
        questionsToInsert.push({
          chapterId: chapter.id,
          ...questionData,
        });
      }
      
      // Insérer en batch
      await db.insert(questions).values(questionsToInsert).onConflictDoNothing();
      totalGenerated += 200;
      
      console.log(`  ✓ 200 questions ajoutées`);
    }
    
    console.log(`\n✅ Génération terminée !`);
    console.log(`📊 Total: ${totalGenerated} questions générées`);
    
  } catch (error) {
    console.error("❌ Erreur lors de la génération:", error);
    throw error;
  }
}

import { db } from "./db";
import { questions, subjects } from "@shared/schema";
import { eq } from "drizzle-orm";

async function fixCulturePopSeparation() {
  try {
    // Récupérer les IDs des matières
    const [francaisSubject] = await db.select().from(subjects).where(eq(subjects.slug, "francais"));
    const [culturePopSubject] = await db.select().from(subjects).where(eq(subjects.slug, "culture-pop"));

    if (!francaisSubject || !culturePopSubject) {
      console.error("Matières non trouvées");
      process.exit(1);
    }

    console.log("Français ID:", francaisSubject.id);
    console.log("Culture Pop ID:", culturePopSubject.id);

    // Mots-clés pour identifier les questions culture pop
    const culturePopKeywords = [
      "Disney", "Simba", "Mulan", "Shrek", "Toy Story", "Raiponce", "Bambi", "Elsa", "Anna",
      "Pokémon", "Pikachu", "Bulbizarre", "Goku", "Naruto", "Doraemon", "Luffy", "Death Note",
      "Simpson", "Schtroumpf", "Dora", "Bob l'éponge", "Scooby",
      "BTS", "Blackpink", "K-pop", "EXO", "Twice", "PSY", "Gangnam",
      "Zelda", "Mario", "PlayStation", "Minecraft", "Sonic", "Fortnite", "Pokédex",
      "Among Us", "Cuphead", "Beat Saber", "Undertale", "Stardew", "Overwatch", "Halo"
    ];

    // Récupérer toutes les questions de Français
    const francaisQuestions = await db
      .select()
      .from(questions)
      .where(eq(questions.subjectId, francaisSubject.id));

    console.log(`\nTotal questions Français actuellement: ${francaisQuestions.length}`);

    // Séparer les questions culture pop des vraies questions français
    const culturePopQuestions: string[] = [];
    const vraisFrancaisQuestions: string[] = [];

    for (const q of francaisQuestions) {
      const isCulturePop = culturePopKeywords.some(keyword => 
        q.question.includes(keyword) || 
        q.options.some((opt: string) => opt.includes(keyword))
      );

      if (isCulturePop) {
        culturePopQuestions.push(q.id);
      } else {
        vraisFrancaisQuestions.push(q.id);
      }
    }

    console.log(`Questions culture pop identifiées: ${culturePopQuestions.length}`);
    console.log(`Vraies questions français: ${vraisFrancaisQuestions.length}`);

    // Déplacer les questions culture pop vers Culture Pop
    if (culturePopQuestions.length > 0) {
      for (const id of culturePopQuestions) {
        await db
          .update(questions)
          .set({ subjectId: culturePopSubject.id })
          .where(eq(questions.id, id));
      }
      console.log(`✅ ${culturePopQuestions.length} questions déplacées vers Culture Pop`);
    }

    // Afficher le résumé
    console.log("\n📊 Résumé final:");
    const francaisCount = await db.select().from(questions).where(eq(questions.subjectId, francaisSubject.id));
    const culturePopCount = await db.select().from(questions).where(eq(questions.subjectId, culturePopSubject.id));
    
    console.log(`  Français: ${francaisCount.length} questions`);
    console.log(`  Culture Pop: ${culturePopCount.length} questions`);

  } catch (error) {
    console.error("❌ Erreur:", error);
    process.exit(1);
  } finally {
    process.exit(0);
  }
}

fixCulturePopSeparation();

import { generateMassiveQuestions } from "./generate-massive-questions";

generateMassiveQuestions()
  .then(() => {
    console.log("✅ Génération terminée");
    process.exit(0);
  })
  .catch((error) => {
    console.error("❌ Erreur:", error);
    process.exit(1);
  });

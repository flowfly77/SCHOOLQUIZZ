import { db } from "./db";
import { subjects, chapters, questions, badges } from "@shared/schema";

// Données des matières du collège français
const subjectsData = [
  {
    name: "Français",
    slug: "francais",
    color: "francais",
    icon: "Book",
    description: "Lecture, écriture, grammaire et littérature"
  },
  {
    name: "Mathématiques",
    slug: "mathematiques",
    color: "math",
    icon: "Calculator",
    description: "Nombres, calcul, géométrie et algèbre"
  },
  {
    name: "Histoire-Géographie",
    slug: "histoire-geographie",
    color: "histoire",
    icon: "Globe",
    description: "Histoire, géographie et éducation civique"
  },
  {
    name: "SVT",
    slug: "svt",
    color: "svt",
    icon: "TestTube",
    description: "Sciences de la Vie et de la Terre"
  },
  {
    name: "Physique-Chimie",
    slug: "physique-chimie",
    color: "physique",
    icon: "Beaker",
    description: "Matière, énergie et transformations"
  },
  {
    name: "Technologie",
    slug: "technologie",
    color: "physique",
    icon: "Cpu",
    description: "Informatique, robotique et innovation"
  },
  {
    name: "Anglais",
    slug: "anglais",
    color: "francais",
    icon: "MessageCircle",
    description: "Langue vivante étrangère"
  },
  {
    name: "EMC",
    slug: "emc",
    color: "histoire",
    icon: "Users",
    description: "Éducation Morale et Civique"
  }
];

// Chapitres par matière et par niveau
const chaptersData = [
  // FRANÇAIS - 6ème
  { subject: "francais", grade: "6ème", order: 1, title: "Créer, recréer le monde", slug: "creer-recreer-monde", description: "Récits des origines et mythes fondateurs" },
  { subject: "francais", grade: "6ème", order: 2, title: "Chanter, enchanter le monde", slug: "chanter-enchanter", description: "Poésie et expression artistique" },
  { subject: "francais", grade: "6ème", order: 3, title: "Se masquer, jouer, déjouer", slug: "masquer-jouer", description: "Théâtre et ruses" },
  { subject: "francais", grade: "6ème", order: 4, title: "Partir, voyager, explorer", slug: "voyager-explorer", description: "Récits d'aventure" },
  { subject: "francais", grade: "6ème", order: 5, title: "Grammaire et conjugaison", slug: "grammaire-6eme", description: "Classes de mots et temps verbaux" },
  
  // FRANÇAIS - 5ème
  { subject: "francais", grade: "5ème", order: 1, title: "Récits d'aventures", slug: "recits-aventures", description: "Voyages et découvertes" },
  { subject: "francais", grade: "5ème", order: 2, title: "Le Moyen Âge", slug: "moyen-age", description: "Chevalerie et héros" },
  { subject: "francais", grade: "5ème", order: 3, title: "Poésie lyrique", slug: "poesie-lyrique", description: "Expression des sentiments" },
  { subject: "francais", grade: "5ème", order: 4, title: "Grammaire et orthographe", slug: "grammaire-5eme", description: "Propositions et accords" },
  
  // FRANÇAIS - 4ème
  { subject: "francais", grade: "4ème", order: 1, title: "Critique de la société", slug: "critique-societe", description: "Satire et ironie" },
  { subject: "francais", grade: "4ème", order: 2, title: "Théâtre classique", slug: "theatre-classique", description: "Molière et comédie" },
  { subject: "francais", grade: "4ème", order: 3, title: "L'argumentation", slug: "argumentation", description: "Débattre et convaincre" },
  { subject: "francais", grade: "4ème", order: 4, title: "Nouvelles réalistes", slug: "nouvelles-realistes", description: "XIXe siècle" },
  
  // FRANÇAIS - 3ème
  { subject: "francais", grade: "3ème", order: 1, title: "Autobiographie", slug: "autobiographie", description: "Se raconter, se représenter" },
  { subject: "francais", grade: "3ème", order: 2, title: "Poésie engagée", slug: "poesie-engagee", description: "Littérature et société" },
  { subject: "francais", grade: "3ème", order: 3, title: "Argumentation complexe", slug: "argumentation-3eme", description: "Préparation au Brevet" },
  { subject: "francais", grade: "3ème", order: 4, title: "Théâtre moderne", slug: "theatre-moderne", description: "XXe siècle" },

  // MATHÉMATIQUES - 6ème
  { subject: "mathematiques", grade: "6ème", order: 1, title: "Nombres entiers et décimaux", slug: "nombres-entiers", description: "Opérations et calcul" },
  { subject: "mathematiques", grade: "6ème", order: 2, title: "Fractions", slug: "fractions-6eme", description: "Introduction aux fractions" },
  { subject: "mathematiques", grade: "6ème", order: 3, title: "Géométrie plane", slug: "geometrie-plane-6eme", description: "Figures et constructions" },
  { subject: "mathematiques", grade: "6ème", order: 4, title: "Aires et périmètres", slug: "aires-perimetres", description: "Mesures et calculs" },
  { subject: "mathematiques", grade: "6ème", order: 5, title: "Proportionnalité", slug: "proportionnalite-6eme", description: "Tableaux et graphiques" },
  
  // MATHÉMATIQUES - 5ème
  { subject: "mathematiques", grade: "5ème", order: 1, title: "Nombres relatifs", slug: "nombres-relatifs", description: "Positifs et négatifs" },
  { subject: "mathematiques", grade: "5ème", order: 2, title: "Fractions et opérations", slug: "fractions-5eme", description: "Addition et soustraction" },
  { subject: "mathematiques", grade: "5ème", order: 3, title: "Calcul littéral", slug: "calcul-litteral", description: "Introduction à l'algèbre" },
  { subject: "mathematiques", grade: "5ème", order: 4, title: "Triangles et angles", slug: "triangles-angles", description: "Propriétés géométriques" },
  { subject: "mathematiques", grade: "5ème", order: 5, title: "Statistiques", slug: "statistiques-5eme", description: "Graphiques et moyennes" },
  
  // MATHÉMATIQUES - 4ème
  { subject: "mathematiques", grade: "4ème", order: 1, title: "Théorème de Pythagore", slug: "pythagore", description: "Triangle rectangle" },
  { subject: "mathematiques", grade: "4ème", order: 2, title: "Calcul littéral avancé", slug: "calcul-litteral-4eme", description: "Développement et factorisation" },
  { subject: "mathematiques", grade: "4ème", order: 3, title: "Équations", slug: "equations-4eme", description: "Résolution d'équations" },
  { subject: "mathematiques", grade: "4ème", order: 4, title: "Puissances", slug: "puissances", description: "Notation et calculs" },
  { subject: "mathematiques", grade: "4ème", order: 5, title: "Proportionnalité avancée", slug: "proportionnalite-4eme", description: "Pourcentages et vitesses" },
  
  // MATHÉMATIQUES - 3ème
  { subject: "mathematiques", grade: "3ème", order: 1, title: "Théorème de Thalès", slug: "thales", description: "Triangles et rapports" },
  { subject: "mathematiques", grade: "3ème", order: 2, title: "Trigonométrie", slug: "trigonometrie", description: "Sinus, cosinus, tangente" },
  { subject: "mathematiques", grade: "3ème", order: 3, title: "Fonctions", slug: "fonctions", description: "Linéaires et affines" },
  { subject: "mathematiques", grade: "3ème", order: 4, title: "Équations du second degré", slug: "equations-second", description: "Résolution avancée" },
  { subject: "mathematiques", grade: "3ème", order: 5, title: "Probabilités", slug: "probabilites", description: "Arbres et événements" },

  // HISTOIRE-GÉOGRAPHIE - 6ème
  { subject: "histoire-geographie", grade: "6ème", order: 1, title: "La Préhistoire", slug: "prehistoire", description: "Les premiers hommes" },
  { subject: "histoire-geographie", grade: "6ème", order: 2, title: "L'Antiquité", slug: "antiquite", description: "Grèce et Rome" },
  { subject: "histoire-geographie", grade: "6ème", order: 3, title: "Le Moyen Âge", slug: "moyen-age-6eme", description: "Féodalité et châteaux" },
  { subject: "histoire-geographie", grade: "6ème", order: 4, title: "Géographie mondiale", slug: "geo-mondiale", description: "Continents et océans" },
  
  // HISTOIRE-GÉOGRAPHIE - 5ème
  { subject: "histoire-geographie", grade: "5ème", order: 1, title: "Grandes découvertes", slug: "decouvertes", description: "XVe-XVIe siècles" },
  { subject: "histoire-geographie", grade: "5ème", order: 2, title: "La Renaissance", slug: "renaissance", description: "Arts et sciences" },
  { subject: "histoire-geographie", grade: "5ème", order: 3, title: "Géographie européenne", slug: "geo-europe", description: "Relief et climats" },
  { subject: "histoire-geographie", grade: "5ème", order: 4, title: "Islam et civilisations", slug: "islam", description: "Expansion musulmane" },
  
  // HISTOIRE-GÉOGRAPHIE - 4ème
  { subject: "histoire-geographie", grade: "4ème", order: 1, title: "Les Lumières", slug: "lumieres", description: "XVIIIe siècle" },
  { subject: "histoire-geographie", grade: "4ème", order: 2, title: "La Révolution française", slug: "revolution", description: "1789-1799" },
  { subject: "histoire-geographie", grade: "4ème", order: 3, title: "XIXe siècle industriel", slug: "xixe-industriel", description: "Révolution industrielle" },
  { subject: "histoire-geographie", grade: "4ème", order: 4, title: "Géopolitique mondiale", slug: "geo-mondiale-4eme", description: "Puissances et développement" },
  
  // HISTOIRE-GÉOGRAPHIE - 3ème
  { subject: "histoire-geographie", grade: "3ème", order: 1, title: "Première Guerre mondiale", slug: "premiere-guerre", description: "1914-1918" },
  { subject: "histoire-geographie", grade: "3ème", order: 2, title: "Seconde Guerre mondiale", slug: "seconde-guerre", description: "1939-1945" },
  { subject: "histoire-geographie", grade: "3ème", order: 3, title: "Guerre froide", slug: "guerre-froide", description: "Monde bipolaire" },
  { subject: "histoire-geographie", grade: "3ème", order: 4, title: "Géopolitique contemporaine", slug: "geo-contemporaine", description: "Monde actuel" },

  // SVT - 6ème
  { subject: "svt", grade: "6ème", order: 1, title: "L'environnement", slug: "environnement", description: "Écosystèmes et biodiversité" },
  { subject: "svt", grade: "6ème", order: 2, title: "Le vivant", slug: "vivant", description: "Caractéristiques des êtres vivants" },
  { subject: "svt", grade: "6ème", order: 3, title: "Le corps humain", slug: "corps-humain-6eme", description: "Organes et fonctions" },
  
  // SVT - 5ème
  { subject: "svt", grade: "5ème", order: 1, title: "La respiration", slug: "respiration", description: "Système respiratoire" },
  { subject: "svt", grade: "5ème", order: 2, title: "La circulation sanguine", slug: "circulation", description: "Cœur et vaisseaux" },
  { subject: "svt", grade: "5ème", order: 3, title: "La digestion", slug: "digestion", description: "Système digestif" },
  { subject: "svt", grade: "5ème", order: 4, title: "Géologie", slug: "geologie-5eme", description: "Roches et paysages" },
  
  // SVT - 4ème
  { subject: "svt", grade: "4ème", order: 1, title: "La reproduction", slug: "reproduction", description: "Reproduction humaine" },
  { subject: "svt", grade: "4ème", order: 2, title: "Le système nerveux", slug: "systeme-nerveux", description: "Cerveau et réflexes" },
  { subject: "svt", grade: "4ème", order: 3, title: "Volcanisme et séismes", slug: "volcanisme", description: "Activité interne de la Terre" },
  
  // SVT - 3ème
  { subject: "svt", grade: "3ème", order: 1, title: "Génétique", slug: "genetique", description: "ADN et hérédité" },
  { subject: "svt", grade: "3ème", order: 2, title: "Évolution", slug: "evolution", description: "Théorie de l'évolution" },
  { subject: "svt", grade: "3ème", order: 3, title: "Immunité", slug: "immunite", description: "Défenses du corps" },
  { subject: "svt", grade: "3ème", order: 4, title: "Écologie et développement durable", slug: "developpement-durable", description: "Enjeux environnementaux" },

  // PHYSIQUE-CHIMIE - 6ème
  { subject: "physique-chimie", grade: "6ème", order: 1, title: "La matière", slug: "matiere-6eme", description: "États et propriétés" },
  { subject: "physique-chimie", grade: "6ème", order: 2, title: "Mélanges et solutions", slug: "melanges", description: "Séparation et dissolution" },
  
  // PHYSIQUE-CHIMIE - 5ème
  { subject: "physique-chimie", grade: "5ème", order: 1, title: "L'eau", slug: "eau", description: "Cycle et propriétés" },
  { subject: "physique-chimie", grade: "5ème", order: 2, title: "Électricité", slug: "electricite-5eme", description: "Circuits électriques" },
  { subject: "physique-chimie", grade: "5ème", order: 3, title: "La lumière", slug: "lumiere", description: "Sources et propagation" },
  
  // PHYSIQUE-CHIMIE - 4ème
  { subject: "physique-chimie", grade: "4ème", order: 1, title: "Combustions", slug: "combustions", description: "Réactions chimiques" },
  { subject: "physique-chimie", grade: "4ème", order: 2, title: "Atomes et molécules", slug: "atomes-molecules", description: "Structure de la matière" },
  { subject: "physique-chimie", grade: "4ème", order: 3, title: "Électricité avancée", slug: "electricite-4eme", description: "Lois et mesures" },
  { subject: "physique-chimie", grade: "4ème", order: 4, title: "Optique", slug: "optique", description: "Lentilles et images" },
  
  // PHYSIQUE-CHIMIE - 3ème
  { subject: "physique-chimie", grade: "3ème", order: 1, title: "Ions et pH", slug: "ions-ph", description: "Solutions acides et basiques" },
  { subject: "physique-chimie", grade: "3ème", order: 2, title: "Énergie", slug: "energie", description: "Formes et conversions" },
  { subject: "physique-chimie", grade: "3ème", order: 3, title: "Mécanique", slug: "mecanique", description: "Forces et mouvements" },
  { subject: "physique-chimie", grade: "3ème", order: 4, title: "Chimie organique", slug: "chimie-organique", description: "Introduction" },

  // TECHNOLOGIE - Tous niveaux
  { subject: "technologie", grade: "6ème", order: 1, title: "Objets techniques", slug: "objets-techniques", description: "Fonctions et besoins" },
  { subject: "technologie", grade: "6ème", order: 2, title: "Matériaux", slug: "materiaux-6eme", description: "Propriétés" },
  { subject: "technologie", grade: "5ème", order: 1, title: "Informatique", slug: "informatique-5eme", description: "Algorithmes de base" },
  { subject: "technologie", grade: "5ème", order: 2, title: "Structures", slug: "structures", description: "Résistance et stabilité" },
  { subject: "technologie", grade: "4ème", order: 1, title: "Programmation", slug: "programmation", description: "Scratch et algorithmes" },
  { subject: "technologie", grade: "4ème", order: 2, title: "Robotique", slug: "robotique", description: "Capteurs et actionneurs" },
  { subject: "technologie", grade: "3ème", order: 1, title: "Design et innovation", slug: "design", description: "Conception de produits" },
  { subject: "technologie", grade: "3ème", order: 2, title: "Domotique", slug: "domotique", description: "Maison connectée" },

  // ANGLAIS - Tous niveaux
  { subject: "anglais", grade: "6ème", order: 1, title: "Présentations", slug: "presentations", description: "Se présenter" },
  { subject: "anglais", grade: "6ème", order: 2, title: "La famille", slug: "family", description: "Family and friends" },
  { subject: "anglais", grade: "6ème", order: 3, title: "Les loisirs", slug: "hobbies", description: "Hobbies and sports" },
  { subject: "anglais", grade: "5ème", order: 1, title: "La vie quotidienne", slug: "daily-life", description: "Daily routines" },
  { subject: "anglais", grade: "5ème", order: 2, title: "Les voyages", slug: "travel", description: "Traveling and countries" },
  { subject: "anglais", grade: "4ème", order: 1, title: "L'environnement", slug: "environment", description: "Environment and nature" },
  { subject: "anglais", grade: "4ème", order: 2, title: "La technologie", slug: "technology", description: "Technology and media" },
  { subject: "anglais", grade: "3ème", order: 1, title: "Débattre", slug: "debating", description: "Expressing opinions" },
  { subject: "anglais", grade: "3ème", order: 2, title: "Culture anglophone", slug: "culture", description: "English-speaking world" },

  // EMC - Tous niveaux
  { subject: "emc", grade: "6ème", order: 1, title: "Vivre ensemble", slug: "vivre-ensemble", description: "Règles de vie collective" },
  { subject: "emc", grade: "6ème", order: 2, title: "Les droits de l'enfant", slug: "droits-enfant", description: "Droits fondamentaux" },
  { subject: "emc", grade: "5ème", order: 1, title: "Égalité et discrimination", slug: "egalite", description: "Respect des différences" },
  { subject: "emc", grade: "5ème", order: 2, title: "La laïcité", slug: "laicite", description: "Principe républicain" },
  { subject: "emc", grade: "4ème", order: 1, title: "La justice", slug: "justice", description: "Système judiciaire" },
  { subject: "emc", grade: "4ème", order: 2, title: "Médias et information", slug: "medias", description: "Esprit critique" },
  { subject: "emc", grade: "3ème", order: 1, title: "La démocratie", slug: "democratie", description: "Institutions françaises" },
  { subject: "emc", grade: "3ème", order: 2, title: "Engagement citoyen", slug: "engagement", description: "Participation citoyenne" },
];

// Badges du système
const badgesData = [
  {
    name: "Premier Pas",
    description: "Termine ton premier quiz",
    type: "bronze",
    category: "general",
    criteria: { type: "quizzes_completed", value: 1 },
    icon: "Trophy"
  },
  {
    name: "Curieux",
    description: "Essaie 3 matières différentes",
    type: "bronze",
    category: "general",
    criteria: { type: "subjects_tried", value: 3 },
    icon: "Star"
  },
  {
    name: "Régulier",
    description: "Maintiens une série de 7 jours",
    type: "silver",
    category: "general",
    criteria: { type: "streak", value: 7 },
    icon: "Flame"
  },
  {
    name: "Expert Maths",
    description: "Obtiens 100% dans 5 quiz de maths",
    type: "gold",
    category: "subject",
    criteria: { type: "perfect_scores", value: 5, subjectId: "mathematiques" },
    icon: "Calculator"
  },
  {
    name: "Maître des Lettres",
    description: "Obtiens 100% dans 5 quiz de français",
    type: "gold",
    category: "subject",
    criteria: { type: "perfect_scores", value: 5, subjectId: "francais" },
    icon: "Book"
  },
  {
    name: "Scientifique",
    description: "Complète tous les chapitres de SVT",
    type: "gold",
    category: "subject",
    criteria: { type: "complete_subject", value: 1, subjectId: "svt" },
    icon: "TestTube"
  },
  {
    name: "Champion",
    description: "Atteins 10 000 points XP",
    type: "gold",
    category: "achievement",
    criteria: { type: "xp", value: 10000 },
    icon: "Award"
  },
  {
    name: "Quiz Master",
    description: "Complète 50 quiz",
    type: "silver",
    category: "achievement",
    criteria: { type: "quizzes_completed", value: 50 },
    icon: "Trophy"
  },
  {
    name: "Perfectionniste",
    description: "Obtiens 100% dans 10 quiz différents",
    type: "gold",
    category: "achievement",
    criteria: { type: "perfect_scores", value: 10 },
    icon: "Target"
  },
  {
    name: "Explorateur",
    description: "Essaie toutes les matières",
    type: "silver",
    category: "general",
    criteria: { type: "subjects_tried", value: 8 },
    icon: "Compass"
  },
];

export async function seedDatabase() {
  try {
    console.log("🌱 Démarrage du seeding de la base de données...");
    
    // Insertion des matières
    console.log("📚 Insertion des matières...");
    const insertedSubjects: Record<string, any> = {};
    
    for (const subject of subjectsData) {
      const [inserted] = await db.insert(subjects).values(subject).returning();
      insertedSubjects[subject.slug] = inserted;
      console.log(`  ✓ ${subject.name}`);
    }
    
    // Insertion des chapitres
    console.log("\n📖 Insertion des chapitres...");
    for (const chapter of chaptersData) {
      const subjectId = insertedSubjects[chapter.subject]?.id;
      if (subjectId) {
        await db.insert(chapters).values({
          subjectId,
          grade: chapter.grade,
          title: chapter.title,
          slug: chapter.slug,
          order: chapter.order,
          description: chapter.description,
        });
        console.log(`  ✓ ${chapter.grade} - ${chapter.title}`);
      }
    }
    
    // Insertion des badges
    console.log("\n🏆 Insertion des badges...");
    for (const badge of badgesData) {
      await db.insert(badges).values(badge);
      console.log(`  ✓ ${badge.name} (${badge.type})`);
    }
    
    console.log("\n✅ Seeding terminé avec succès !");
  } catch (error) {
    console.error("❌ Erreur lors du seeding:", error);
    throw error;
  }
}

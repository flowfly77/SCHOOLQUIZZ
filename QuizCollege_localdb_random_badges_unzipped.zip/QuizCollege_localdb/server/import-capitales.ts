import { db } from "./db";
import { questions } from "@shared/schema";
import { eq } from "drizzle-orm";

const CAPITALES_ID = '5e70c7b5-2b71-45e3-a2ae-ec2df6ad5b85';

// Liste de capitales avec pays (pour niveau collège)
const capitales = [
  { pays: "France", capitale: "PARIS" },
  { pays: "Espagne", capitale: "MADRID" },
  { pays: "Italie", capitale: "ROME" },
  { pays: "Allemagne", capitale: "BERLIN" },
  { pays: "Royaume-Uni", capitale: "LONDRES" },
  { pays: "Belgique", capitale: "BRUXELLES" },
  { pays: "Suisse", capitale: "BERNE" },
  { pays: "Portugal", capitale: "LISBONNE" },
  { pays: "Grèce", capitale: "ATHENES" },
  { pays: "Pays-Bas", capitale: "AMSTERDAM" },
  { pays: "Autriche", capitale: "VIENNE" },
  { pays: "Pologne", capitale: "VARSOVIE" },
  { pays: "Russie", capitale: "MOSCOU" },
  { pays: "États-Unis", capitale: "WASHINGTON" },
  { pays: "Canada", capitale: "OTTAWA" },
  { pays: "Mexique", capitale: "MEXICO" },
  { pays: "Brésil", capitale: "BRASILIA" },
  { pays: "Argentine", capitale: "BUENOS AIRES" },
  { pays: "Chili", capitale: "SANTIAGO" },
  { pays: "Pérou", capitale: "LIMA" },
  { pays: "Chine", capitale: "PEKIN" },
  { pays: "Japon", capitale: "TOKYO" },
  { pays: "Inde", capitale: "NEW DELHI" },
  { pays: "Australie", capitale: "CANBERRA" },
  { pays: "Égypte", capitale: "LE CAIRE" },
  { pays: "Maroc", capitale: "RABAT" },
  { pays: "Algérie", capitale: "ALGER" },
  { pays: "Tunisie", capitale: "TUNIS" },
  { pays: "Sénégal", capitale: "DAKAR" },
  { pays: "Afrique du Sud", capitale: "PRETORIA" }
];

async function importCapitales() {
  try {
    console.log(`\n📍 Import des questions Capitales...`);

    const grades = ['6ème', '5ème', '4ème', '3ème'];
    
    for (const grade of grades) {
      for (const { pays, capitale } of capitales) {
        await db.insert(questions).values({
          subjectId: CAPITALES_ID,
          grade: grade,
          question: `Quelle est la capitale de ${pays} ?`,
          options: [capitale, "", "", ""], // Format spécial pour saisie texte
          correctAnswer: 0, // Index de la bonne réponse
          difficulty: 'moyen',
          points: 10
        });
      }
      console.log(`  ✅ ${capitales.length} capitales importées pour ${grade}`);
    }

    console.log("\n📊 Total Capitales:");
    const count = await db.select().from(questions).where(eq(questions.subjectId, CAPITALES_ID));
    console.log(`  ${count.length} questions (toutes classes)`);

  } catch (error) {
    console.error("❌ Erreur:", error);
    process.exit(1);
  } finally {
    process.exit(0);
  }
}

importCapitales();

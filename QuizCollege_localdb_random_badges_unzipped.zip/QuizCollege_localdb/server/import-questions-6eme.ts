import { db } from "./db";
import { questions, subjects } from "@shared/schema";
import fs from "fs";
import { eq } from "drizzle-orm";

interface QuestionData {
  q: string;
  a: string[];
  c: number;
}

async function importQuestions() {
  try {
    // Lire le fichier des questions
    const fileContent = fs.readFileSync(
      "attached_assets/Pasted--VOS-QUESTIONS-PERSONNALIS-ES-ICI--1760520597399_1760520597404.txt",
      "utf-8"
    );

    // Récupérer toutes les matières existantes
    const allSubjects = await db.select().from(subjects);
    const subjectMap: Record<string, string> = {};
    allSubjects.forEach((subject) => {
      subjectMap[subject.slug] = subject.id;
    });

    console.log("Matières disponibles:", Object.keys(subjectMap));

    // Parser les questions - extraction manuelle des sections
    const questionsToInsert: Array<{
      subjectId: string;
      grade: string;
      question: string;
      options: string[];
      correctAnswer: number;
      explanation: string | null;
      difficulty: string;
      points: number;
    }> = [];

    // Extraire customQuestions (Culture Pop)
    const customMatch = fileContent.match(/const customQuestions = \[([\s\S]*?)\];/);
    if (customMatch) {
      const customQuestionsStr = customMatch[1];
      const questionRegex = /\{q:\s*"([^"]+)",\s*a:\s*\[([^\]]+)\],\s*c:\s*(\d+)\}/g;
      let match;

      // Pour la culture pop, on va créer ou utiliser une matière "Culture Générale"
      // Mais pour l'instant, mettons-les dans "Français" comme culture générale
      const culturalSubjectId = subjectMap["francais"] || allSubjects[0].id;

      while ((match = questionRegex.exec(customQuestionsStr)) !== null) {
        const questionText = match[1];
        const answersStr = match[2];
        const correctIdx = parseInt(match[3]);

        // Parser les réponses
        const answers = answersStr.split(",").map((a) => a.trim().replace(/^"|"$/g, ""));

        questionsToInsert.push({
          subjectId: culturalSubjectId,
          grade: "6ème",
          question: questionText,
          options: answers,
          correctAnswer: correctIdx,
          explanation: null,
          difficulty: "moyen",
          points: 10,
        });
      }
    }

    // Parser les questions d'Anglais
    const anglaisMatch = fileContent.match(/anglais:\s*\{[\s\S]*?questions:\s*\[([\s\S]*?)\]\s*\}/);
    if (anglaisMatch && subjectMap["anglais"]) {
      const anglaisQuestionsStr = anglaisMatch[1];
      const questionRegex = /\{q:\s*"([^"]+)",\s*a:\s*\[([^\]]+)\],\s*c:\s*(\d+)\}/g;
      let match;

      while ((match = questionRegex.exec(anglaisQuestionsStr)) !== null) {
        const questionText = match[1];
        const answersStr = match[2];
        const correctIdx = parseInt(match[3]);

        const answers = answersStr.split(",").map((a) => a.trim().replace(/^"|"$/g, ""));

        questionsToInsert.push({
          subjectId: subjectMap["anglais"],
          grade: "6ème",
          question: questionText,
          options: answers,
          correctAnswer: correctIdx,
          explanation: null,
          difficulty: "facile",
          points: 10,
        });
      }
    }

    // Parser les questions de Français (si présentes)
    const francaisMatch = fileContent.match(/francais:\s*\{[\s\S]*?questions:\s*\[([\s\S]*?)\]\s*\}/);
    if (francaisMatch && subjectMap["francais"]) {
      const francaisQuestionsStr = francaisMatch[1];
      const questionRegex = /\{q:\s*"([^"]+)",\s*a:\s*\[([^\]]+)\],\s*c:\s*(\d+)\}/g;
      let match;

      while ((match = questionRegex.exec(francaisQuestionsStr)) !== null) {
        const questionText = match[1];
        const answersStr = match[2];
        const correctIdx = parseInt(match[3]);

        const answers = answersStr.split(",").map((a) => a.trim().replace(/^"|"$/g, ""));

        questionsToInsert.push({
          subjectId: subjectMap["francais"],
          grade: "6ème",
          question: questionText,
          options: answers,
          correctAnswer: correctIdx,
          explanation: null,
          difficulty: "moyen",
          points: 10,
        });
      }
    }

    // Parser les questions de Maths
    const mathsMatch = fileContent.match(/mathematiques:\s*\{[\s\S]*?questions:\s*\[([\s\S]*?)\]\s*\}/);
    if (mathsMatch && subjectMap["mathematiques"]) {
      const mathsQuestionsStr = mathsMatch[1];
      const questionRegex = /\{q:\s*"([^"]+)",\s*a:\s*\[([^\]]+)\],\s*c:\s*(\d+)\}/g;
      let match;

      while ((match = questionRegex.exec(mathsQuestionsStr)) !== null) {
        const questionText = match[1];
        const answersStr = match[2];
        const correctIdx = parseInt(match[3]);

        const answers = answersStr.split(",").map((a) => a.trim().replace(/^"|"$/g, ""));

        questionsToInsert.push({
          subjectId: subjectMap["mathematiques"],
          grade: "6ème",
          question: questionText,
          options: answers,
          correctAnswer: correctIdx,
          explanation: null,
          difficulty: "moyen",
          points: 10,
        });
      }
    }

    // Parser les questions d'Histoire
    const histoireMatch = fileContent.match(/histoire:\s*\{[\s\S]*?questions:\s*\[([\s\S]*?)\]\s*\}/);
    if (histoireMatch && subjectMap["histoire"]) {
      const histoireQuestionsStr = histoireMatch[1];
      const questionRegex = /\{q:\s*"([^"]+)",\s*a:\s*\[([^\]]+)\],\s*c:\s*(\d+)\}/g;
      let match;

      while ((match = questionRegex.exec(histoireQuestionsStr)) !== null) {
        const questionText = match[1];
        const answersStr = match[2];
        const correctIdx = parseInt(match[3]);

        const answers = answersStr.split(",").map((a) => a.trim().replace(/^"|"$/g, ""));

        questionsToInsert.push({
          subjectId: subjectMap["histoire"],
          grade: "6ème",
          question: questionText,
          options: answers,
          correctAnswer: correctIdx,
          explanation: null,
          difficulty: "moyen",
          points: 10,
        });
      }
    }

    // Parser les questions de Musique
    const musiqueMatch = fileContent.match(/musique:\s*\{[\s\S]*?questions:\s*\[([\s\S]*?)\]\s*\}/);
    if (musiqueMatch && subjectMap["musique"]) {
      const musiqueQuestionsStr = musiqueMatch[1];
      const questionRegex = /\{q:\s*"([^"]+)",\s*a:\s*\[([^\]]+)\],\s*c:\s*(\d+)\}/g;
      let match;

      while ((match = questionRegex.exec(musiqueQuestionsStr)) !== null) {
        const questionText = match[1];
        const answersStr = match[2];
        const correctIdx = parseInt(match[3]);

        const answers = answersStr.split(",").map((a) => a.trim().replace(/^"|"$/g, ""));

        questionsToInsert.push({
          subjectId: subjectMap["musique"],
          grade: "6ème",
          question: questionText,
          options: answers,
          correctAnswer: correctIdx,
          explanation: null,
          difficulty: "facile",
          points: 10,
        });
      }
    }

    console.log(`Total de questions à insérer: ${questionsToInsert.length}`);

    // Insérer les questions par lots de 100
    const batchSize = 100;
    for (let i = 0; i < questionsToInsert.length; i += batchSize) {
      const batch = questionsToInsert.slice(i, i + batchSize);
      await db.insert(questions).values(batch);
      console.log(`Inséré ${Math.min(i + batchSize, questionsToInsert.length)} / ${questionsToInsert.length} questions`);
    }

    console.log("✅ Import terminé avec succès!");
  } catch (error) {
    console.error("❌ Erreur lors de l'import:", error);
    process.exit(1);
  } finally {
    process.exit(0);
  }
}

importQuestions();

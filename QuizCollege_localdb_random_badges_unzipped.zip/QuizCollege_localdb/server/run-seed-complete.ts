import { seedCompleteDatabase } from "./seed-complete";

seedCompleteDatabase()
  .then(() => {
    console.log("✅ Base de données initialisée");
    process.exit(0);
  })
  .catch((error) => {
    console.error("❌ Erreur:", error);
    process.exit(1);
  });

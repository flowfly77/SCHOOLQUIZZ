import { db } from "./db";
import { questions } from "@shared/schema";
import { eq, and } from "drizzle-orm";

async function duplicateCulturePop() {
  try {
    const culturePopId = '1700350e-6104-4e8c-b7bb-81c42a251f2e';
    
    // Récupérer toutes les questions de Culture Pop 6ème
    const sixiemeQuestions = await db
      .select()
      .from(questions)
      .where(and(
        eq(questions.subjectId, culturePopId),
        eq(questions.grade, '6ème')
      ));

    console.log(`📚 ${sixiemeQuestions.length} questions Culture Pop 6ème à dupliquer`);

    const grades = ['5ème', '4ème', '3ème'];
    
    for (const grade of grades) {
      console.log(`\n📝 Duplication pour ${grade}...`);
      
      for (const q of sixiemeQuestions) {
        await db.insert(questions).values({
          subjectId: q.subjectId,
          grade: grade,
          question: q.question,
          options: q.options,
          correctAnswer: q.correctAnswer,
          difficulty: q.difficulty,
          points: q.points,
          explanation: q.explanation
        });
      }
      
      console.log(`✅ ${sixiemeQuestions.length} questions créées pour ${grade}`);
    }

    // Vérifier le résultat
    console.log("\n📊 Résumé final Culture Pop:");
    for (const grade of ['6ème', '5ème', '4ème', '3ème']) {
      const count = await db.select().from(questions).where(and(
        eq(questions.subjectId, culturePopId),
        eq(questions.grade, grade)
      ));
      console.log(`  ${grade}: ${count.length} questions`);
    }

  } catch (error) {
    console.error("❌ Erreur:", error);
    process.exit(1);
  } finally {
    process.exit(0);
  }
}

duplicateCulturePop();
